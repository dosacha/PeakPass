import json, subprocess, sys, time
from pathlib import Path

out = Path(__file__).parent

def run(run_id, rate, users, stock, warmup, seats=None, preflight=False):
    assert not (Path('load-test/results/flash-sale') / run_id).exists(), 'Never reuse an executed run ID'
    for attempt in range(10):
        ready = True
        for sample in range(3):
            free = int(subprocess.check_output(['node', '-p', "require('node:os').freemem()"], text=True))
            with (out / 'memory-checks.jsonl').open('a', encoding='utf8') as log:
                log.write(json.dumps({'runId': run_id, 'atEpoch': time.time(), 'freeBytes': free, 'attempt': attempt, 'sample': sample}) + '\n')
            if free < 2 * 1073741824:
                ready = False
                print(f'WAIT {run_id}: freeBytes={free}; no provisioning', flush=True)
                break
            if sample < 2:
                time.sleep(5)
        if ready:
            break
        if attempt < 9:
            time.sleep(30)
    assert ready, 'Host memory below preregistered 2GiB start margin; no provisioning'
    args = ['node', 'load-test/flash-sale-fixture.mjs', '--run-id', run_id, '--rate', str(rate), '--users', str(users), '--stock', stock,
            '--warmup-seconds', str(warmup), '--drain-seconds', '30', '--pre-vus', '10' if preflight else '100',
            '--max-vus', '20' if preflight else '100', '--limiter-max', '1000000']
    if seats is not None:
        args += ['--seats', str(seats)]
    print('START ' + run_id, flush=True)
    with (out / f'{run_id}.txt').open('w', encoding='utf8') as log:
        process = subprocess.run(args, stdout=log, stderr=subprocess.STDOUT)
    directory = Path('load-test/results/flash-sale') / run_id
    analysis = json.loads((directory / 'analysis.json').read_text(encoding='utf8'))
    manifest = json.loads((directory / 'manifest.json').read_text(encoding='utf8'))
    print(json.dumps({'run': run_id, 'exit': process.returncode, 'class': analysis['classification'], 'smoke': manifest['smokePassed'],
                      'paid': analysis.get('all', {}).get('sqlPaid'), 'invalid': analysis.get('invalidReasons'), 'source': manifest['commit']}), flush=True)
    assert not manifest['workingTree'], 'Dirty measurement source'
    assert manifest['revision'] == 'flash-sale-v2.6'
    assert analysis['classification'] in ['valid-stable', 'valid-overload', 'valid-limited'], 'Stop: invalid/integrity evidence preserved'
    if preflight:
        assert manifest['smokePassed'], 'Stop: preflight failed'
    elif stock == 'ample':
        assert analysis['cohort']['completionFraction'] > .8 and analysis['cohort']['paidJourneyMs']['p99'] <= 5000, 'Stop: fixed performance boundary'

assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip(), 'Commit before measuring'
if sys.argv[1] == 'preflight':
    run('p2-v26-preflight-ample-01', 2, 24, 'ample', 0, preflight=True)
    run('p2-v26-preflight-limited-01', 2, 24, 'limited', 0, 6, preflight=True)
elif sys.argv[1] == 'formal':
    for name in ['ample', 'limited']:
        manifest = json.loads((Path('load-test/results/flash-sale') / f'p2-v26-preflight-{name}-01' / 'manifest.json').read_text(encoding='utf8'))
        analysis = json.loads((Path('load-test/results/flash-sale') / f'p2-v26-preflight-{name}-01' / 'analysis.json').read_text(encoding='utf8'))
        assert manifest['smokePassed'] and manifest['revision'] == 'flash-sale-v2.6' and analysis['classification'] in ['valid-stable', 'valid-limited'], 'Preflight must pass first'
    counts = {2: 0, 10: 0, 25: 0}
    for rate in [2, 10, 25, 25, 10, 2, 2, 10, 25]:
        counts[rate] += 1
        run(f'p2-v26-ample-r{rate}-{counts[rate]:02}', rate, rate * 40, 'ample', 10)
    for repeat in range(1, 4):
        run(f'p2-v26-limited-{repeat:02}', 10, 300, 'limited', 0, 60)
elif sys.argv[1] == 'resume':
    for rate in [2, 10, 25]:
        for repeat in [1, 2]:
            prior = json.loads((Path('load-test/results/flash-sale') / f'p2-v26-ample-r{rate}-{repeat:02}' / 'analysis.json').read_text(encoding='utf8'))
            assert prior['revision'] == 'flash-sale-v2.6' and prior['classification'] in ['valid-stable', 'valid-overload']
    for rate in [2, 10, 25]:
        run_id = f'p2-v26-ample-r{rate}-03'
        prior_path = Path('load-test/results/flash-sale') / run_id / 'analysis.json'
        if prior_path.exists():
            prior = json.loads(prior_path.read_text(encoding='utf8'))
            assert prior['revision'] == 'flash-sale-v2.6' and prior['classification'] in ['valid-stable', 'valid-overload']
            print('ALREADY COMPLETE ' + run_id, flush=True)
        else:
            run(run_id, rate, rate * 40, 'ample', 10)
    for repeat in range(1, 4):
        run(f'p2-v26-limited-{repeat:02}', 10, 300, 'limited', 0, 60)
elif sys.argv[1] == 'remaining-limited':
    prior = json.loads((Path('load-test/results/flash-sale/p2-v26-limited-01') / 'analysis.json').read_text(encoding='utf8'))
    assert prior['revision'] == 'flash-sale-v2.6' and prior['classification'] == 'valid-limited'
    for repeat in [2, 3]:
        run(f'p2-v26-limited-{repeat:02}', 10, 300, 'limited', 0, 60)
else:
    raise ValueError('preflight, formal, resume or remaining-limited required')
