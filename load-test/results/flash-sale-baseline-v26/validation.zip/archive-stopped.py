"""Preserve stopped v2.6 attempts without claiming a complete accepted matrix."""
import hashlib,json,re,subprocess,zipfile
from pathlib import Path

dest=Path('load-test/results/flash-sale-baseline-v26')
assert not dest.exists(),'Do not overwrite evidence'
dest.mkdir()
digest=lambda data:hashlib.sha256(data).hexdigest()
secret=re.compile(rb'eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+|-----BEGIN [A-Z ]*PRIVATE KEY-----|(?:postgres(?:ql)?|redis)://[^\s:"/]+:[^\s@]+@')
index={'format':1,'candidateRevision':'flash-sale-v2.6','acceptedRevision':None,'acceptedRunIds':[],
       'matrixComplete':False,'state':'blocked-before-provisioning-host-memory','analysisRevision':'flash-sale-analysis-v2.6',
       'analysisCommit':subprocess.check_output(['git','log','-1','--format=%H','--','load-test/flash-sale-analysis.mjs'],text=True).strip(),
       'stopReason':'Limited02 did not start: fewer than three consecutive >=2GiB pre-provisioning samples after ten attempts. All executed runs remain valid; no measurement threshold changed.',
       'priorEvidence':'All v2.3/v2.4 raw and v2.5 validation archives/index bytes unchanged; not reused as v2.6 evidence.',
       'secretScan':'JWT, private-key, credential-URL patterns; synthetic UUIDs retained','runs':[]}
for folder in sorted(Path('load-test/results/flash-sale').glob('p2-v26-*')):
    if not (folder/'manifest.json').exists():continue
    original={p.name:p.read_bytes() for p in folder.iterdir() if p.is_file()}
    assert all(not secret.search(data) for data in original.values())
    m=json.loads(original['manifest.json']);a=json.loads(original['analysis.json'])
    reanalysis=json.loads(subprocess.check_output(['node','load-test/flash-sale-analysis.mjs',str(folder)]))
    assert reanalysis==a, 'Stored analysis differs from offline reanalysis'
    for name,expected in m['artifactHashes'].items():assert digest(original[name])==expected
    sources={name:digest(subprocess.check_output(['git','show',f'{m["commit"]}:{name}']).replace(b'\r\n',b'\n'))==expected for name,expected in m['sourceHashes'].items()}
    assert all(sources.values()) and not m['workingTree']
    zpath=dest/f'{folder.name}.zip'
    with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,data in sorted(original.items()):z.writestr(name,data)
    with zipfile.ZipFile(zpath) as z:assert all(z.read(name)==data for name,data in original.items())
    index['runs'].append({'runId':folder.name,'revision':m['revision'],'commit':m['commit'],'acceptedFormal':False,'startedAt':m['startedAt'],'settings':m['settings'],
        'validFormalObservation':'preflight' not in folder.name and a['classification'] in ['valid-stable','valid-overload','valid-limited'],
        'exclusion':'Incomplete stopped matrix; no complete P2 tuple accepted' if 'preflight' not in folder.name else 'Preflight, not a formal replicate',
        'archive':zpath.name,'sha256':digest(zpath.read_bytes()),'files':len(original),'verifiedArtifactHashes':len(m['artifactHashes']),
        'canonicalSourcesMatchCommit':sources,'sourceHashes':m['sourceHashes'],'originalClassification':a['classification'],'analysis':a})
assert len(index['runs'])==12
index['observedMeasurementCommits']=sorted({r['commit'] for r in index['runs']})
index['observedFormalCounts']={f'ample-{rate}':sum(r['validFormalObservation'] and f'-r{rate}-' in r['runId'] for r in index['runs']) for rate in [2,10,25]}
index['observedFormalCounts']['limited-10']=sum(r['validFormalObservation'] and r['settings']['stock']=='limited' for r in index['runs'])
assert index['observedFormalCounts']=={'ample-2':3,'ample-10':3,'ample-25':3,'limited-10':1}
index['remainingFormalRunIds']=['p2-v26-limited-02','p2-v26-limited-03']
index['startMemoryChecks']=[json.loads(line) for line in (Path(__file__).parent/'memory-checks.jsonl').read_text(encoding='utf8').splitlines()]
index['executedOrder']=[r['runId'] for r in sorted(index['runs'],key=lambda r:r['startedAt'])]
(dest/'index.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf8')
(dest/'archives.sha256').write_text(''.join(f'{r["sha256"]}  {r["archive"]}\n' for r in index['runs']),encoding='utf8')
print(json.dumps({'runs':len(index['runs']),'accepted':0,'observedFormal':index['observedFormalCounts'],
                 'files':sum(r['files'] for r in index['runs']),'artifactHashes':sum(r['verifiedArtifactHashes'] for r in index['runs'])}))
