$ErrorActionPreference = 'Stop'
$out = $PSScriptRoot
$owner = [guid]::NewGuid().ToString('N')
$pgId = $null; $redisId = $null; $originalId = $null; $backup = $null
$pgName = "peakpass-p2-tests-$owner"; $redisName = 'peakpass-wave3-0928-redis'
$results = [ordered]@{ owner=$owner; startedAt=[DateTime]::UtcNow.ToString('o'); checks=@() }
function RunCheck($name, $binary, $arguments) {
  $timer = [Diagnostics.Stopwatch]::StartNew()
  & $binary @arguments *> "$out/$name.txt"
  $code = $LASTEXITCODE
  $script:results.checks += @{ name=$name; exitCode=$code; seconds=$timer.Elapsed.TotalSeconds; command="$binary $($arguments -join ' ')" }
  Write-Output "$name exit=$code seconds=$([math]::Round($timer.Elapsed.TotalSeconds,1))"
  if ($code -ne 0) { Get-Content "$out/$name.txt" -Tail 30; throw "$name failed" }
}
try {
  $candidate = docker ps -aq --filter 'name=^/peakpass-wave3-0928-redis$'
  if ($candidate) {
    $original = docker inspect $candidate | ConvertFrom-Json
    if ($original.State.Running -or $original.State.Paused) { throw 'Existing Wave3 resource is active; refuse to alter it' }
    $originalId = $original.Id; $backup = "peakpass-wave3-preserved-$owner"
    docker rename $originalId $backup
    if ($LASTEXITCODE -ne 0) { throw 'Preservation rename failed' }
    $results.originalPreserved = @{ id=$originalId; name='peakpass-wave3-0928-redis'; running=$false; temporaryName=$backup }
  }
  $env:POSTGRES_PASSWORD = [guid]::NewGuid().ToString('N')
  $pgId = docker run -d --label "peakpass.owner=$owner" --name $pgName -e POSTGRES_PASSWORD -e POSTGRES_USER=flash_sale -e POSTGRES_DB=issue11_tests -p '127.0.0.1::5432' postgres:16-alpine
  if ($LASTEXITCODE -ne 0) { throw 'Dedicated PG creation failed' }
  $redisId = docker run -d --label "peakpass.owner=$owner" --label peakpass.task=wave3 --name $redisName -p '127.0.0.1::6379' redis:7-alpine
  if ($LASTEXITCODE -ne 0) { throw 'Dedicated Redis creation failed' }
  $results.resources = @{ postgresId=$pgId; redisId=$redisId }
  $ready = $false
  for ($i=0; $i -lt 60; $i++) {
    docker exec $pgId pg_isready -h 127.0.0.1 -U flash_sale -d issue11_tests *> $null
    if ($LASTEXITCODE -eq 0) { $ready=$true; break }
    Start-Sleep -Milliseconds 500
  }
  if (!$ready) { throw 'PG not ready' }
  Remove-Item Env:DATABASE_URL,Env:REDIS_URL,Env:REDIS_PASSWORD -ErrorAction SilentlyContinue
  $env:DB_HOST='127.0.0.1'; $env:DB_PORT=(docker port $pgId 5432/tcp).Split(':')[-1]
  $env:DB_USER='flash_sale'; $env:DB_PASSWORD=$env:POSTGRES_PASSWORD; $env:DB_NAME='issue11_tests'
  $env:REDIS_HOST='127.0.0.1'; $env:REDIS_PORT=(docker port $redisId 6379/tcp).Split(':')[-1]; $env:NODE_ENV='test'; $env:LOG_LEVEL='fatal'
  $env:IMAGE_DB_HOST='host.docker.internal'; $env:IMAGE_REDIS_HOST='host.docker.internal'
  $env:WAVE3_REDIS_DESTRUCTIVE='0'; $env:WAVE3_REDIS_CONTAINER='peakpass-wave3-0928-redis'; $env:WAVE3_REDIS_CONTAINER_ID=$redisId
  $env:WAVE4_TEST_IMAGE='peakpass:fs-p2-v23-ample-r2-01'
  RunCheck 'production-image' 'node' @('.github/scripts/production-image-check.mjs',$env:WAVE4_TEST_IMAGE)
  RunCheck 'harness' 'npm.cmd' @('run','test:flash-sale')
  RunCheck 'callback-harness' 'node' @('--experimental-vm-modules','load-test/payment-callback-check.mjs')
  RunCheck 'unit' 'npm.cmd' @('test','--','--runInBand','--coverage','--json',"--outputFile=$out/unit.json")
  RunCheck 'integration' 'npx.cmd' @('--no-install','jest','--runInBand','--config','jest.integration.cjs','--json',"--outputFile=$out/integration.json")
  RunCheck 'build' 'npm.cmd' @('run','build')
  RunCheck 'typecheck' 'npx.cmd' @('--no-install','tsc','--noEmit')
  RunCheck 'lint' 'npm.cmd' @('run','lint')
  RunCheck 'diff-check' 'git' @('diff','--check')
} catch { $results.error=$_.Exception.Message; Write-Output $results.error }
finally {
  $results.cleanupErrors=@()
  foreach ($name in @($redisName,$pgName)) {
    try {
      $raw = docker inspect $name 2>&1
      if ($LASTEXITCODE -ne 0) {
        if (($raw -join ' ') -match 'No such (object|container)') { continue }
        throw "Test resource inspection failed: $name"
      }
      $metadata = $raw | ConvertFrom-Json
      if ($metadata.Config.Labels.'peakpass.owner' -ne $owner) { throw "Test cleanup ownership mismatch: $name" }
      $id=$metadata.Id
      if ($metadata.State.Paused) { docker unpause $id | Out-Null; if ($LASTEXITCODE -ne 0) { throw "Unpause failed: $id" } }
      docker rm -f -v $id | Out-Null
      if ($LASTEXITCODE -ne 0) { throw "Test resource removal failed: $id" }
    } catch { $results.cleanupErrors += $_.Exception.Message }
  }
  if ($originalId) {
    try {
      $metadata = docker inspect $originalId | ConvertFrom-Json
      if ($metadata.Name -ne "/$backup" -or $metadata.State.Running) { throw 'Original resource preservation changed unexpectedly' }
      docker rename $originalId peakpass-wave3-0928-redis
      if ($LASTEXITCODE -ne 0) { throw 'Original resource rename failed' }
      $restored = docker inspect $originalId | ConvertFrom-Json
      $results.originalRestored = ($restored.Name -eq '/peakpass-wave3-0928-redis' -and !$restored.State.Running)
      if (!$results.originalRestored) { throw 'Original resource restoration failed' }
    } catch { $results.cleanupErrors += $_.Exception.Message }
  }
  $results.finishedAt=[DateTime]::UtcNow.ToString('o')
  $results | ConvertTo-Json -Depth 8 | Set-Content "$out/results.json" -Encoding utf8
}
if ($results.error -or $results.cleanupErrors.Count) { exit 1 }
