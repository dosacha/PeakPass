import json, subprocess, zipfile, tempfile, hashlib
from pathlib import Path
out=Path(__file__).parent
original=Path('load-test/results/flash-sale-baseline-v26')
results=[]
for archive in sorted(original.glob('p2-*.zip')):
    with tempfile.TemporaryDirectory(prefix='peakpass-v261-analysis-') as temp:
        with zipfile.ZipFile(archive) as z:
            assert all('/' not in n and "\\" not in n and n != '..' for n in z.namelist())
            z.extractall(temp)
        p=Path(temp)
        manifest=json.loads((p/'manifest.json').read_text(encoding='utf8'))
        before=json.loads((p/'analysis.json').read_text(encoding='utf8'))
        raw=subprocess.check_output(['node','load-test/flash-sale-analysis.mjs',temp])
        after=json.loads(raw)
        assert after['evidence']['sourceClean'] and after['evidence']['accounting']['checks']['offeredBuyers']
        comparable=json.loads(raw)
        comparable['analysisRevision']=before['analysisRevision']
        del comparable['evidence']['sourceClean'];del comparable['evidence']['accounting']['checks']['offeredBuyers']
        assert comparable == before, archive.name
        (out/(manifest['runId']+'-analysis.json')).write_bytes(raw)
        results.append({'runId':manifest['runId'],'archive':str(archive).replace("\\",'/'),
            'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
            'measurementCommit':manifest['commit'],'oldClassification':before['classification'],
            'classification':after['classification'],'metricsUnchanged':True,'workingTree':manifest['workingTree'],
            'oldAnalysisRevision':before['analysisRevision'],'analysisRevision':after['analysisRevision'],
            'analysisSha256':hashlib.sha256(raw).hexdigest()})
assert len(results)==12
(out/'reanalysis.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf8')
print(json.dumps({'reanalyzed':len(results),'metricsUnchanged':True,'classifications':[x['classification'] for x in results]}))
