import hashlib,json,subprocess,zipfile,re
from pathlib import Path
out=Path(__file__).parent
dest=Path('load-test/results/flash-sale-baseline-v261')
assert not dest.exists(),'Do not overwrite published evidence'
dest.mkdir()
(dest/'.gitattributes').write_text('*.json -text\n',encoding='utf8')
digest=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
old=read(Path('load-test/results/flash-sale-baseline-v26/index.json'))
index={'format':1,'revision':'flash-sale-v2.6','analysisRevision':'flash-sale-analysis-v2.6.1','analysisCommit':head,
 'acceptedRevision':None,'acceptedRunIds':[],'matrixComplete':True,'state':'complete-awaiting-final-review',
 'previousCheckpoint':'../flash-sale-baseline-v26/index.json','runs':[]}
secret=re.compile(rb'eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+|-----BEGIN [A-Z ]*PRIVATE KEY-----|(?:postgres(?:ql)?|redis)://[^\s:"/]+:[^\s@]+@')
images=[]
sourceCache={}
for runId in sorted([r['runId'] for r in old['runs']]+['p2-v26-limited-02','p2-v26-limited-03']):
 historical=next((r for r in old['runs'] if r['runId']==runId),None)
 if historical:
  archive=Path('load-test/results/flash-sale-baseline-v26')/historical['archive']
  with zipfile.ZipFile(archive) as z:contents={n:z.read(n) for n in z.namelist()}
  analysis=read(out/(runId+'-analysis.json'))
  arcRef='../flash-sale-baseline-v26/'+archive.name
 else:
  folder=Path('load-test/results/flash-sale')/runId
  contents={p.name:p.read_bytes() for p in folder.iterdir() if p.is_file()}
  analysis=read(folder/'analysis.json')
  assert json.loads(subprocess.check_output(['node','load-test/flash-sale-analysis.mjs',str(folder)]))==analysis
  archive=dest/(runId+'.zip');arcRef=archive.name
  with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
   for n,b in sorted(contents.items()):z.writestr(n,b)
  with zipfile.ZipFile(archive) as z:assert all(z.read(n)==b for n,b in contents.items())
 assert all(not secret.search(b) for b in contents.values())
 m=json.loads(contents['manifest.json']);originalAnalysis=json.loads(contents['analysis.json'])
 assert m['workingTree']=='' and not m.get('cleanupError') and not m.get('teardownError')
 assert all(digest(contents[n])==h for n,h in m['artifactHashes'].items())
 for n,h in m['sourceHashes'].items():
  key=(m['commit'],n)
  if key not in sourceCache:sourceCache[key]=digest(subprocess.check_output(['git','show',m['commit']+':'+n]).replace(b'\r\n',b'\n'))
  assert sourceCache[key]==h
 assert analysis['classification'] in ['valid-stable','valid-overload','valid-limited']
 assert analysis['evidence']['sourceClean'] and analysis['evidence']['accounting']['checks']['offeredBuyers']
 formal='preflight' not in runId
 index['runs'].append({'runId':runId,'revision':m['revision'],'commit':m['commit'],'settings':m['settings'],'startedAt':m['startedAt'],
  'formal':formal,'acceptedFormal':False,'archive':arcRef,'sha256':digest(archive.read_bytes()),'files':len(contents),'verifiedArtifactHashes':len(m['artifactHashes']),
  'sourceHashes':m['sourceHashes'],'originalAnalysisRevision':originalAnalysis['analysisRevision'],'originalClassification':originalAnalysis['classification'],'analysis':analysis})
 image=next(c['image'] for c in m['containers'] if c['service']=='app')
 value=json.loads(subprocess.check_output(['docker','image','inspect',image]))[0]
 label=value['Config']['Labels'].pop('com.docker.compose.project');assert label==m['project']
 runtime={'rootFS':value['RootFS'],'config':value['Config'],'architecture':value['Architecture'],'os':value['Os']}
 images.append({'runId':runId,'image':image,'excludedOwnershipLabel':label,'runtimeHash':digest(json.dumps(runtime,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()),'runtime':runtime})
assert len(index['runs'])==14
index['candidateRunIds']=[r['runId'] for r in index['runs'] if r['formal']]
index['measurementCommits']=sorted({r['commit'] for r in index['runs']})
index['formalCounts']={f'ample-{rate}':sum(r['formal'] and r['settings']['stock']=='ample' and r['settings']['rate']==rate for r in index['runs']) for rate in [2,10,25]}
index['formalCounts']['limited-10']=sum(r['formal'] and r['settings']['stock']=='limited' for r in index['runs'])
assert index['formalCounts']=={'ample-2':3,'ample-10':3,'ample-25':3,'limited-10':3}
index['startMemoryChecks']=[json.loads(line) for line in (out/'memory-checks.jsonl').read_text(encoding='utf8').splitlines()]
index['previousStartMemoryChecks']='../flash-sale-baseline-v26/index.json#startMemoryChecks'
index['executedOrder']=[r['runId'] for r in sorted(index['runs'],key=lambda r:r['startedAt'])]
(dest/'index.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf8')
prior=read(Path('load-test/results/flash-sale-baseline-v26/image-equivalence.json'))
assert all(i['runtimeHash']==prior['runtimeHash'] for i in images),'App runtime changed; stop acceptance'
equivalence={'algorithm':prior['algorithm'],'verifiedImages':14,'runtimeHash':images[0]['runtimeHash'],'matchesPriorV26Runtime':True,'images':images}
(dest/'image-equivalence.json').write_text(json.dumps(equivalence,indent=2)+'\n',encoding='utf8')
validation=read(out/'validation-metadata.json');validation['sourceCommit']=head;validation['checks']=read(out/'results.json')
for n,h in validation['canonicalCodeHashes'].items():assert digest(Path(n).read_bytes().replace(b'\r\n',b'\n'))==h
for kind in ['unit','integration']:
 result=read(out/(kind+'.json'));assert result['success']
 validation[kind]={'passed':result['numPassedTests'],'failed':result['numFailedTests'],'skipped':result['numPendingTests'],'suites':result['numPassedTestSuites'],
 'skippedTests':[{'file':r['name'],'test':a['fullName']} for r in result['testResults'] for a in r['assertionResults'] if a['status']=='pending']}
assert len(validation['checks']['checks'])==9 and all(c['exitCode']==0 for c in validation['checks']['checks'])
assert not validation['checks']['cleanupErrors'] and validation['checks']['originalRestored']
files=[p for p in out.rglob('*') if p.is_file() and p.suffix in ['.txt','.json','.jsonl','.ps1','.py'] and not p.name.endswith('-analysis.json')]
contents={p.relative_to(out).as_posix():p.read_bytes() for p in files}
assert all(not secret.search(b) for b in contents.values())
with zipfile.ZipFile(dest/'validation.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n,b in sorted(contents.items()):z.writestr(n,b)
validation['artifactHashes']={n:digest(b) for n,b in contents.items()};validation['archiveSha256']=digest((dest/'validation.zip').read_bytes())
(dest/'validation.json').write_text(json.dumps(validation,indent=2)+'\n',encoding='utf8')
with zipfile.ZipFile(dest/'reanalysis.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.glob('*-analysis.json')):z.writestr(p.name,p.read_bytes())
(dest/'archives.sha256').write_text(''.join(f'{digest(p.read_bytes())}  {p.name}\n' for p in sorted(dest.glob('*.zip'))),encoding='utf8')
(dest/'supplemental.sha256').write_text(''.join(f'{digest((dest/n).read_bytes())}  {n}\n' for n in ['index.json','image-equivalence.json','validation.json']),encoding='utf8')
print(json.dumps({'actualRuns':14,'formalCounts':index['formalCounts'],'files':sum(r['files'] for r in index['runs']),'artifactHashes':sum(r['verifiedArtifactHashes'] for r in index['runs']),
 'validationFiles':len(contents),'unit':validation['unit'],'integration':validation['integration'],'runtimeEquivalent':True}))
