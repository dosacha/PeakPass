import hashlib, json, re, subprocess, zipfile
from pathlib import Path

out = Path(__file__).parent
dest = Path('load-test/results/flash-sale-baseline-v25')
assert not dest.exists(), 'Preserve existing evidence'
dest.mkdir()
digest = lambda data: hashlib.sha256(data).hexdigest()
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
validation = read(out / 'validation-metadata.json')
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
validation['implementationCommit'] = head
for file, expected in validation['canonicalCodeHashes'].items():
    assert digest(Path(file).read_bytes().replace(b'\r\n', b'\n')) == expected
    assert digest(subprocess.check_output(['git', 'show', f'{head}:{file}']).replace(b'\r\n', b'\n')) == expected
names = ['results.json', 'validation-metadata.json', 'run.ps1', 'measure.py', 'package.py', 'memory-checks.jsonl',
         'historical-bytes.json', 'old-contract-check.json', 'duplicate-red.txt', 'duplicate-green.txt',
         'harness.txt', 'callback-harness.txt', 'unit.txt', 'unit.json', 'integration.txt', 'integration.json',
         'production-image.txt', 'build.txt', 'typecheck.txt', 'lint.txt', 'diff-check.txt']
contents = {name: (out / name).read_bytes() for name in names}
secrets = re.compile(rb'eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+|-----BEGIN [A-Z ]*PRIVATE KEY-----|(?:postgres(?:ql)?|redis)://[^\s:"/]+:[^\s@]+@')
assert all(not secrets.search(data) for data in contents.values()), 'Validation secret pattern'
with zipfile.ZipFile(dest / 'validation.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for name, data in sorted(contents.items()):
        z.writestr(name, data)
with zipfile.ZipFile(dest / 'validation.zip') as z:
    assert all(z.read(name) == data for name, data in contents.items())
validation['artifactHashes'] = {name: digest(data) for name, data in contents.items()}
validation['archiveSha256'] = digest((dest / 'validation.zip').read_bytes())
validation['matrixComplete'] = False
validation['acceptedRevision'] = None
validation['acceptedRunIds'] = []
validation['executedV25RunIds'] = []
validation['state'] = 'blocked-before-provisioning-host-memory'
validation['memoryStartMinimumBytes'] = 2 * 1073741824
validation['memoryChecks'] = [json.loads(line) for line in (out / 'memory-checks.jsonl').read_text(encoding='utf8').splitlines()]
assert not list(Path('load-test/results/flash-sale').glob('p2-v25-preflight-*/manifest.json'))
(dest / 'validation.json').write_text(json.dumps(validation, indent=2) + '\n', encoding='utf8')
(dest / 'supplemental.sha256').write_text(''.join(f'{digest((dest / name).read_bytes())}  {name}\n' for name in ['validation.json', 'validation.zip']), encoding='utf8')
print(json.dumps({'implementationCommit': head, 'archivedFiles': len(contents), 'executedV25Runs': 0, 'accepted': 0}))
