import hashlib,json,re,subprocess,zipfile
from pathlib import Path

out=Path(__file__).parent
dest=Path('load-test/results/flash-sale-baseline-v24')
assert not dest.exists(),'Preserve any existing archives; do not overwrite'
with (out/'archive-summary.json').open('w',encoding='utf8') as log:
    subprocess.run(['C:/Python314/python.exe',str(out/'archive-stopped.py')],stdout=log,check=True)
digest=lambda data:hashlib.sha256(data).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
index=read(dest/'index.json')
accepted=index['runs']
assert len(accepted)==9 and not index['matrixComplete'] and not index['acceptedRunIds']
images=[]
for r in accepted:
    manifest=read(Path('load-test/results/flash-sale')/r['runId']/'manifest.json')
    image=next(c['image'] for c in manifest['containers'] if c['service']=='app')
    value=json.loads(subprocess.check_output(['docker','image','inspect',image]))[0]
    label=value['Config']['Labels'].pop('com.docker.compose.project')
    assert label==manifest['project']
    runtime={'rootFS':value['RootFS'],'config':value['Config'],'architecture':value['Architecture'],'os':value['Os']}
    images.append({'runId':r['runId'],'image':image,'excludedOwnershipLabel':label,
                   'runtimeHash':digest(json.dumps(runtime,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()),'runtime':runtime})
assert len({i['runtimeHash'] for i in images})==1
prior=read(Path('load-test/results/flash-sale-baseline/image-equivalence.json'))
equivalence={'algorithm':prior['algorithm'],'verifiedImages':len(images),'runtimeHash':images[0]['runtimeHash'],
             'matchesPriorV23Runtime':images[0]['runtimeHash']==prior['runtimeHash'],'images':images}
(dest/'image-equivalence.json').write_text(json.dumps(equivalence,indent=2)+'\n',encoding='utf8')
validation=read(out/'validation-metadata.json')
for file,expected in validation['canonicalCodeHashes'].items():
    assert digest(Path(file).read_bytes().replace(b'\r\n',b'\n'))==expected,'Tested code changed'
names=['results.json','validation-metadata.json','run.ps1','archive-stopped.py','package-stopped.py','measure.py','old-contract-check.json',
       'harness.txt','callback-harness.txt','unit.txt','unit.json','integration.txt','integration.json','production-image.txt','build.txt','typecheck.txt','lint.txt','diff-check.txt','replay-red.txt']
secrets=re.compile(rb'eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+|-----BEGIN [A-Z ]*PRIVATE KEY-----|(?:postgres(?:ql)?|redis)://[^\s:"/]+:[^\s@]+@')
contents={name:(out/name).read_bytes() for name in names}
contents['review-red.txt']=Path('load-test/results/flash-sale/p2-validation/review-red.txt').read_bytes()
assert all(not secrets.search(data) for data in contents.values()),'Validation secret pattern'
with zipfile.ZipFile(dest/'validation.zip','w',zipfile.ZIP_DEFLATED) as z:
    for name,data in sorted(contents.items()):z.writestr(name,data)
with zipfile.ZipFile(dest/'validation.zip') as z:assert all(z.read(name)==data for name,data in contents.items())
validation['artifactHashes']={name:digest(data) for name,data in contents.items()}
validation['archiveSha256']=digest((dest/'validation.zip').read_bytes())
(dest/'validation.json').write_text(json.dumps(validation,indent=2)+'\n',encoding='utf8')
(dest/'supplemental.sha256').write_text(''.join(f'{digest((dest/name).read_bytes())}  {name}\n' for name in ['index.json','image-equivalence.json','validation.json','validation.zip']),encoding='utf8')
print(json.dumps({'runs':len(index['runs']),'accepted':0,'files':sum(r['files'] for r in index['runs']),
                 'artifactHashes':sum(r['verifiedArtifactHashes'] for r in index['runs']),'runtimeMatchesPrior':equivalence['matchesPriorV23Runtime'],
                 'observedFormalCounts':index['observedFormalCounts']},indent=2))
