import json, subprocess, sys
from pathlib import Path

out=Path(__file__).parent
def run(run_id, rate, users, stock, warmup, seats=None, preflight=False):
    args=['node','load-test/flash-sale-fixture.mjs','--run-id',run_id,'--rate',str(rate),'--users',str(users),'--stock',stock,
          '--warmup-seconds',str(warmup),'--drain-seconds','30','--pre-vus','10' if preflight else '100','--max-vus','20' if preflight else '100','--limiter-max','1000000']
    if seats is not None: args+=['--seats',str(seats)]
    print('START '+run_id,flush=True)
    with (out/f'{run_id}.txt').open('w',encoding='utf8') as log:
        process=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT)
    directory=Path('load-test/results/flash-sale')/run_id
    analysis=json.loads((directory/'analysis.json').read_text(encoding='utf8'))
    manifest=json.loads((directory/'manifest.json').read_text(encoding='utf8'))
    print(json.dumps({'run':run_id,'exit':process.returncode,'class':analysis['classification'],'smoke':manifest['smokePassed'],
          'paid':analysis.get('all',{}).get('sqlPaid'),'cohort':analysis.get('cohort',{}).get('completionFraction'),
          'invalid':analysis.get('invalidReasons'),'source':manifest['commit']}),flush=True)
    assert not manifest['workingTree'],'Dirty measurement source'
    assert analysis['classification'] in ['valid-stable','valid-overload','valid-limited'], 'Stop: invalid/integrity evidence preserved'
    if preflight: assert manifest['smokePassed'], 'Stop: preflight failed'
    elif stock=='ample':
        assert analysis['cohort']['completionFraction']>.8 and analysis['cohort']['paidJourneyMs']['p99']<=5000, 'Stop: fixed performance boundary'

assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip(),'Commit before measuring'
if sys.argv[1]=='preflight':
    run('p2-v24-preflight-ample-02',2,24,'ample',0,preflight=True)
    run('p2-v24-preflight-limited-02',2,24,'limited',0,6,preflight=True)
elif sys.argv[1]=='formal':
    counts={2:0,10:0,25:0}
    for rate in [2,10,25,25,10,2,2,10,25]:
        counts[rate]+=1
        run(f'p2-v24-ample-r{rate}-{counts[rate]:02}',rate,rate*40,'ample',10)
    for repeat in range(1,4): run(f'p2-v24-limited-{repeat:02}',10,300,'limited',0,60)
else: raise ValueError('preflight or formal required')
