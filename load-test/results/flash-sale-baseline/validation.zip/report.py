import json
from pathlib import Path
root=Path.cwd()
i=json.loads((root/'load-test/results/flash-sale-baseline/index.json').read_text())
def interval(s,scale=1,digits=2):
    if s is None:return '—'
    f=lambda n:f'{n*scale:.{digits}f}'
    return f'{f(s["median"])} [{f(s["min"])}–{f(s["max"])}]'
lines=['\n## 최종 측정 결과 (2026-10-01 KST)\n',
'대기열 없는 기존 쓰기 경로에서 ample 2·10·25명/초 각각3회는 사전 안정 기준을 만족했다. **이는 이 환경·30초 측정창·허용 오류 기준에서 관측한 범위이며 최대 용량이 아니다.** 25명/초에는 실제500과 미완료 주문이 있었고 모든 strict smoke는 실패했다. 안정 기준의 99% 완료/1% 요청 실패 허용은 실험 가정이며 운영 SLO가 아니다. 50명/초 예비 실행은 발생기/VU 한계로 무효여서 서비스 포화점으로 쓰지 않는다. 대기열의 필요성·개선 효과는 아직 입증하지 않았다.\n',
'표의 값은 **3회 중앙값 [최솟값–최댓값]**이며 percentile을 합쳐 다시 계산하지 않았다. 구매/s는 측정창 고유 HTTP paid와 최종 SQL paid 사용자 일치를30초로 나눈다. 완료율은 scheduled measurement cohort 전체(미완료 포함)가 분모다. 오류율은 창 안 non-replay normal+retry 시도의429/5xx/전송실패 비율이며 품절409는 별도다.\n',
'| 조건 | 창 paid/s | cohort 완료율 % | 요청 실패율 % | paid 여정 p95 ms | paid 여정 p99 ms |',
'|---|---:|---:|---:|---:|---:|']
for key in ['ample-2','ample-10','ample-25','limited-10']:
    s=i['conditions'][key]['replicateStatistics']
    lines.append('| '+key+' | '+' | '.join([interval(s['paidPerSecond']),interval(s['completionFraction'],100),interval(s['windowFailureFraction'],100),interval(s['journeyP95Ms']),interval(s['journeyP99Ms'])])+' |')
lines += ['\nlimited의1 paid/s와10%는 재고가30개 주문으로 제한된 결과다. 세 번 모두300명 시작,30 paid/60 tickets/270 INSUFFICIENT_INVENTORY, 잔여0·pending0·active hold0이었다. 마지막 paid는 scenario 시작 후2.942–2.952초, 마지막 도착은29.897초였다. 이 수치를 ample 용량 곡선에 섞지 않는다.\n',
'### 실행별 분모와 미완료\n',
'모든 정식 실행은 offered=started, dropped0, script/protocol failure0, replay failure0, SQL paid without HTTP0, HTTP paid without SQL0이었다. 최대 도착 lag는24ms였다. 인증 negative3개/회는 별도이며 모두 기대401/403/401 및 DB 불변을 확인했다.\n',
'| Run ID (`p2-v23-` 생략) | 전체 시작 | cohort paid/offered | 창 paid/30s | 실패 시도/전체 non-replay | 전체 SQL paid | pending 주문 | active hold 좌석 | strict smoke |',
'|---|---:|---:|---:|---:|---:|---:|---:|---|']
for r in sorted((r for r in i['runs'] if r['acceptedFormal']),key=lambda r:(r['analysis']['all']['offered'],r['runId'])):
    a=r['analysis'];s=a['sqlCounts'];c=a['cohort'];w=a['window']
    lines.append(f'| {r["runId"].removeprefix("p2-v23-")} | {a["all"]["started"]} | {c["confirmedPaid"]}/{c["offered"]} | {w["confirmedPaid"]}/30 | {w["failureAttempts"]}/{w["nonReplayAttempts"]} | {s["paidOrders"]} | {s["ordersByStatus"].get("pending",0)} | {s["activeHolds"]} | {a["smokePassed"]} |')
lines += ['\n25명/초의 전체 SQL paid는999/996/999였다. 측정 cohort의 미완료는0/2/0명이고 나머지 실패는 warmup cohort다. `r25-02`의2명은 최종HTTP500이며 unknown outcome은0이었다. `r25-03` 창751 paid에는 warmup 유입의 완료1개가 포함된다. cohort750과 창751은 서로 다른 분자다. paid 여정 percentile은 성공자 조건부이며 이 미완료 수를 대체하지 않는다.\n',
'측정 cohort 마지막 도착/마지막 confirmed paid는 scenario 시작 기준: 2/s39.494–39.495초/39.535–39.540초, 10/s39.895초/39.932–39.940초, 25/s39.955초/39.993–40.019초였다. 최대 drain은69.999초지만 마지막 confirmed paid는40.019초 이내였다. pending/hold는 HTTP 여정이 실패로 끝난 뒤 남은 DB 상태이며 drain 중 완료됐다고 세지 않았다. 최종 SQL 후 소유 fixture를 정리했으므로 이 주문들의 장기 만료/회수는 이번 측정 결과가 아니다.\n',
'### API 지연: 성공과 실패\n',
'아래는 측정창의 non-replay(normal+retry), stage/business별 값이다. 건수는3회 모두(없는 그룹은0)를 포함한다. 실패 관측이 없는 반복의 지연은 정의하지 않으므로 `관측 반복`을 표시한다. flow/kind/status/error_code/API code별 세부 분모와 replay 지연은 index의 각 run `analysis.window.apiLatencyMs` 및 `analysis.all.responses`, 원본 raw에 남아 있다.\n',
'| 조건 | stage/business | 관측 반복 | 시도 수 | p95 ms | p99 ms |',
'|---|---|---:|---:|---:|---:|']
for key in ['ample-2','ample-10','ample-25','limited-10']:
    for stage,s in i['conditions'][key]['windowApiNonReplayByStageBusiness'].items():
        lines.append(f'| {key} | {stage} | {s["observedRepeats"]}/3 | {interval(s["count"],digits=0)} | {interval(s["p95"])} | {interval(s["p99"])} |')
lines += ['\nample의 실패 응답은500/INTERNAL_ERROR였으며, 제한 재고 실패는409/INSUFFICIENT_INVENTORY였다. 정식 실행에서401/403/429·전송오류·기타409는 구매 시도에 없었다(negative 인증 검사는 별도).\n',
'### 관측된 압력과 진단 한계\n',
'25/s 측정창의 transaction retry 예정 로그는77/133/126회로 늘었다. pool waiting 표본은 모든 정식 run에서0이었고 lock waiter 최대는0/2/1이었다. `transactionid`와 `tuple` 대기 표본은 hot-event 쓰기 충돌의 단서지만 DB 단독 병목이나 포화의 증거는 아니다.\n',
'25/s의 run별 app CPU 중앙값은34.71–38.40%, PG는17.67–22.07%였다. Redis observer PING p99는3.61–4.47ms였다. 이는 각 컨테이너 제한(앱/PG 각1CPU)의 Docker 표본과 외부 PING이며 앱 Redis 명령 지연이 아니다. 최대 실제 active VU, host CPU/여유 메모리, 엔진 누적 CPU·RSS, 각 관측 경계/간격/오류는 index와 원본에 있다. 자원 수집은 약3초 간격의 순차 조회이고 각 구간은 종료 경계와 겹칠 수 있어 순간 인과관계를 확정하지 않는다.\n',
'실제 쓰기 경로를 수정하지 않았다. checkout의 SERIALIZABLE 재시도·event row lock·멱등 키 경합, reservation의 event row lock, settlement의 order/callback 처리와 info 로그 비용이 함께 포함된다. 정식 범위에서는 pool 고갈·CPU 포화가 확인되지 않았다. 더 높은 부하에서의 포화점, 장시간 지속성, 다중 인스턴스, WAN/브라우저, 실제 네트워크 단절 및 운영 성능은 미검증이다.\n',
'### 수용 tuple·원본과 제외 범위\n',
f'- 측정 revision: `flash-sale-v2.3`; ample SHA `{i["acceptedMeasurementCommits"][0]}`, limited SHA `{i["acceptedMeasurementCommits"][1]}`.',
f'- 분석 revision: `{i["analysisRevision"]}`; SHA `{i["analysisCommit"]}`; canonical source hash `{i["analysisSourceHash"]}`.',
'- accepted IDs: `p2-v23-ample-r2-01..03`, `p2-v23-ample-r10-01..03`, `p2-v23-ample-r25-01..03`, `p2-v23-limited-01..03`.',
'- 두 측정 SHA 사이의 diff는 분석기·경계 regression·문서뿐이다. 실행 하네스/부하 스크립트/Compose/Dockerfile/lockfile/앱 계측의 canonical hashes는 동일하다. 모든 원본 manifest는 clean source 상태였다. 분석을 전체12회에 같은 revision으로 적용했다.',
'- [원본 인덱스](../load-test/results/flash-sale-baseline/index.json)에 SHA별 source hashes, 원본 분류, 수정 분석, 반복 통계가 있다. [ZIP SHA256](../load-test/results/flash-sale-baseline/archives.sha256)과23개 ZIP(총16.38MiB,529파일/506개 artifact hash 검증)을 함께 전달한다. JWT·private-key·credential-URL 패턴 검사에서 검출0이었다. 합성 UUID와 진단 로그는 보존했다.',
'- v2 preflight3개, v2 pilot4개, v2.1 selection pilot3개, v2.2 formal 중단1개는 정식 통계에서 제외했다. script 예외·launcher 관측·CPU 증가 판정의 한계와 실패 SQL을 그대로 보존했다. v2의50/s pilot은312 dropped/max lag6173ms/100VU 한계 때문에 유효한50/s 서비스 부하가 아니다.',
'- `p2-v23-ample-r25-03`의 원본 `invalid-measurement` 판정도 ZIP에서 유지한다. 종료 경계 수집 race를 위에서 공개한 사후 분석 수정으로만 보정했다. 이 보정은 통계 임계값 변경이 아니다.\n',
'### #12 / #17 인계\n',
'P3은 이 tuple과 환경에서2·10·25 offered arrivals/s가 사전 안정 기준을 만족했다는 제한된 근거를 소비한다. 25/s의 실제500·pending/hold와 미관측 포화점을 함께 소비해야 한다. 입장 제어의 실험 목적은 더 큰 burst에서 쓰기 재시도/오류를 줄이면서 전체 대기·포기 비용을 비교하는 것이다. 현재 결과만으로 큐 도입이나 효과를 정당화하지 않는다. R/C/TTL은 아직 미확정이며 paid/s·실제 active VU·preallocated100VU를 서로 같은 용량으로 환산하지 않는다. 10–25/s는 후속 실험 후보 범위일 뿐 운영 권고값이 아니다.\n',
'P8은 이 A 조건과 원본을 부분 입력으로 소비하되 P3/P6/P7 산출물이 없어 blocked다. B/C와 비교하려면 같은 사용자/혼합/재고/think/retry/replay/auth/limiter/로그/pool/자원/30초 창/3회 반복·발생기 조건을 맞춘다. 쓰기 경로·계측·환경이 바뀌면 A도 다시 측정한다. 새 VU/고부하 조건은 먼저 프로토콜을 고정해야 하며 기존50/s 무효 run을 포화점으로 재사용하지 않는다. #13–16/#18은 수용한 결과가 없어 blocked 유지, 재오픈할 완료 결과는 없다. v1 smoke 및 제외된 v2 pilot을 용량으로 읽는 해석은 stale다.\n',
'### 검증·최종 리뷰\n',
'전체 검사와 최종 독립 리뷰 결과는 완료 후 이 절에 확정한다.\n']
path=root/'docs/FLASH_SALE_BASELINE.md'
text=path.read_text(encoding='utf8')
text=text.replace('# P2 A baseline — preregistered protocol (2026-10-01 KST)','# P2 A baseline — protocol and results (2026-10-01 KST)')
for phrase in ['Add failing regression cases','Modify `flash-sale.js`','Verify relevant checks','Run pilot ladder']:
    text=text.replace('- [ ] '+phrase,'- [x] '+phrase)
assert '## 최종 측정 결과' not in text
path.write_text(text+'\n'.join(lines),encoding='utf8')
