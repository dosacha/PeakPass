"""One-shot evidence packaging; run only after measurements and validation finish."""
import hashlib, json, re, statistics, subprocess, zipfile
from datetime import datetime
from pathlib import Path

root = Path.cwd()
source = root / 'load-test/results/flash-sale'
destination = root / 'load-test/results/flash-sale-baseline'
destination.mkdir(exist_ok=True)
digest = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
secrets = re.compile(rb'eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+|-----BEGIN [A-Z ]*PRIVATE KEY-----|(?:postgres(?:ql)?|redis)://[^\s:"/]+:[^\s@]+@')
index = {'format': 1, 'acceptedRevision': 'flash-sale-v2.3', 'runs': [], 'secretScan': 'JWT, private-key and credential-URL patterns; synthetic UUIDs retained'}
accepted = []
epoch = lambda value: datetime.fromisoformat(value.replace('Z', '+00:00')).timestamp()
def percentiles(values):
    values = sorted(values)
    def at(p):
        index = (len(values)-1)*p
        left = int(index)
        return values[left] + (values[min(left+1,len(values)-1)]-values[left])*(index-left)
    return {'count':len(values), 'p95':at(.95), 'p99':at(.99)}
for folder in sorted(source.glob('p2-*')):
    if not (folder / 'manifest.json').exists():
        continue
    manifest = read(folder / 'manifest.json')
    analysis = read(folder / 'analysis.json')
    original_classification = analysis['classification']
    original = {p.name: p.read_bytes() for p in folder.iterdir() if p.is_file()}
    assert all(not secrets.search(data) for data in original.values()), f'Secret pattern in {folder.name}'
    for name, expected in manifest['artifactHashes'].items():
        assert digest(original[name]) == expected, f'Artifact mismatch {folder.name}/{name}'
    if folder.name.startswith('p2-v23-'):
        analysis = json.loads(subprocess.check_output(['node','load-test/flash-sale-analysis.mjs',str(folder)]))
    formal = folder.name.startswith('p2-v23-') and analysis['classification'] in ['valid-stable', 'valid-overload', 'valid-limited']
    source_matches = {}
    for name, expected in manifest['sourceHashes'].items():
        result = subprocess.run(['git', 'show', f'{manifest["commit"]}:{name}'], capture_output=True)
        source_matches[name] = result.returncode == 0 and digest(result.stdout.replace(b'\r\n', b'\n')) == expected
    if formal:
        assert manifest['revision'] == 'flash-sale-v2.3'
        assert not manifest['workingTree'], f'Dirty formal source {folder.name}'
        assert all(source_matches.values()), f'Source mismatch {folder.name}'
        stage_values = {}
        for line in original['k6-raw.jsonl'].splitlines():
            point = json.loads(line)
            if point['type'] != 'Point' or point['metric'] != 'api_duration':
                continue
            data = point['data']; tags = data['tags']
            if tags['kind'] == 'replay' or not epoch(analysis['window']['start']) <= epoch(data['time']) < epoch(analysis['window']['endExclusive']):
                continue
            stage_values.setdefault(f'{tags["stage"]}/{tags["business"]}', []).append(data['value'])
        analysis['windowApiNonReplayByStageBusiness'] = {key:percentiles(values) for key,values in stage_values.items()}
        analysis['cohort']['lastArrivalAfterScenarioStartSeconds'] = (analysis['cohort']['lastArrival']/1000 - epoch(analysis['window']['start']) + manifest['settings']['warmupSeconds'])
        analysis['cohort']['lastConfirmedCompletionAfterScenarioStartSeconds'] = (analysis['cohort']['lastConfirmedCompletion']/1000 - epoch(analysis['window']['start']) + manifest['settings']['warmupSeconds'])
        accepted.append((manifest, analysis))
    archive = destination / f'{folder.name}.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as output:
        for name, data in sorted(original.items()):
            output.writestr(name, data)
    with zipfile.ZipFile(archive) as check:
        assert set(check.namelist()) == set(original)
        assert all(check.read(name) == data for name, data in original.items())
    index['runs'].append({'runId': folder.name, 'revision': manifest['revision'], 'commit': manifest['commit'],
        'acceptedFormal': formal, 'originalClassification': original_classification,
        'exclusion': None if formal else 'Development/pilot or invalid formal: see protocol revision rulings; original verdict not overwritten',
        'archive': archive.name, 'sha256': digest(archive.read_bytes()), 'bytes': archive.stat().st_size,
        'files': len(original), 'verifiedArtifactHashes': len(manifest['artifactHashes']), 'canonicalSourcesMatchCommit': source_matches,
        'analysis': analysis})

def spread(values):
    values = [v for v in values if v is not None]
    return {'median': statistics.median(values), 'min': min(values), 'max': max(values)} if values else None

groups = {}
for manifest, analysis in accepted:
    key = f'{manifest["settings"]["stock"]}-{manifest["settings"]["rate"]}'
    groups.setdefault(key, []).append(analysis)
summary = {}
for key, runs in groups.items():
    assert len(runs) == 3, f'Expected3 formal repeats for {key}, got{len(runs)}'
    metrics = {
        'paidPerSecond': lambda a: a['window']['paidPerSecond'],
        'completionFraction': lambda a: a['cohort']['completionFraction'],
        'windowFailureFraction': lambda a: a['window']['failureFraction'],
        'journeyP95Ms': lambda a: a['cohort']['paidJourneyMs']['p95'],
        'journeyP99Ms': lambda a: a['cohort']['paidJourneyMs']['p99'],
        'unfinished': lambda a: a['cohort']['unfinished'],
        'sqlPaid': lambda a: a['all']['sqlPaid'],
        'sqlPaidWithoutHttp': lambda a: a['all']['sqlPaidWithoutHttp'],
        'replaysFailed': lambda a: a['all']['replayFailures'],
        'maxArrivalLagMs': lambda a: a['all']['arrivalLagMs']['max'],
        'lastArrivalAfterScenarioStartSeconds': lambda a: a['cohort']['lastArrivalAfterScenarioStartSeconds'],
        'lastConfirmedCompletionAfterScenarioStartSeconds': lambda a: a['cohort']['lastConfirmedCompletionAfterScenarioStartSeconds'],
        'poolWaitingMedian': lambda a: a['diagnostics']['poolWaiting']['median'],
        'poolWaitingMax': lambda a: a['diagnostics']['poolWaiting']['max'],
        'lockWaitersMax': lambda a: a['diagnostics']['lockWaiters']['max'],
        'retriesScheduled': lambda a: a['diagnostics']['retriesScheduledInWindow'],
        'appCpuMedian': lambda a: a['diagnostics']['containers']['app']['cpuPercent']['median'],
        'pgCpuMedian': lambda a: a['diagnostics']['containers']['postgres']['cpuPercent']['median'],
        'redisPingP99Ms': lambda a: a['diagnostics']['redisObserverRttMs']['p99'],
    }
    stage_keys = sorted(set().union(*(a['windowApiNonReplayByStageBusiness'] for a in runs)))
    summary[key] = {'runIds': [a['runId'] for a in runs], 'classifications': [a['classification'] for a in runs],
        'replicateStatistics': {name: spread([get(a) for a in runs]) for name, get in metrics.items()},
        'windowApiNonReplayByStageBusiness': {stage:{'observedRepeats':sum(stage in a['windowApiNonReplayByStageBusiness'] for a in runs), **{metric:spread([a['windowApiNonReplayByStageBusiness'].get(stage,{}).get(metric,0 if metric == 'count' else None) for a in runs]) for metric in ['count','p95','p99']}} for stage in stage_keys}}
assert set(groups) == {'ample-2', 'ample-10', 'ample-25', 'limited-10'}
index['acceptedMeasurementCommits'] = sorted({m['commit'] for m, _ in accepted})
index['measurementSourceHashesByCommit'] = {m['commit']:m['sourceHashes'] for m,_ in accepted}
for path in accepted[0][0]['sourceHashes']:
    if path not in ['load-test/flash-sale-analysis.mjs','load-test/flash-sale-check.mjs']:
        assert len({m['sourceHashes'][path] for m,_ in accepted}) == 1, f'Measurement source changed: {path}'
index['analysisRevision'] = 'flash-sale-analysis-v2.3.1'
index['analysisCommit'] = subprocess.check_output(['git','log','-1','--format=%H','--','load-test/flash-sale-analysis.mjs'],text=True).strip()
index['analysisSourceHash'] = digest((root/'load-test/flash-sale-analysis.mjs').read_bytes().replace(b'\r\n',b'\n'))
index['analysisRuling'] = 'Post-hoc terminal sampling correction applied uniformly; original archive verdicts retained. Only analyzer/tests/docs differ between measured commits; load/collector/application hashes match.'
index['conditions'] = summary
(destination / 'index.json').write_text(json.dumps(index, indent=2) + '\n', encoding='utf8')
(destination / 'archives.sha256').write_text(''.join(f'{r["sha256"]}  {r["archive"]}\n' for r in index['runs']), encoding='utf8')
print(json.dumps({'runs': len(index['runs']), 'accepted': len(accepted), 'conditions': summary}, indent=2))
