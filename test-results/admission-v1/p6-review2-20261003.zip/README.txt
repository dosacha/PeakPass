Evidence of the second round of the external review of run peakpass-p6-20261003, code fc0f4a8a665d385e52a3300882bd376eee4f24f8.
p6-final-20261003.zip holds the evidence up to code 02ee7e0, p6-review-20261003.zip the first round (code b9656ab).

evidence/  s21-* an earlier reservation read answered after a new join and purchase on the same event;
           s22-* a demo session request held after a 401 while waiting. *-before.* ran on bb2fb13 before the
           change, the others after it. review3.proxy.log: the proxy of these runs (its first /demo/session
           line in the s22 run after the change is the request of the run before it, closed when that page
           was left). final.console.log, final-f*, a11y-*.json: the final check on the new code.
logs/      the regression on the new code and summaries.txt (every trace as text).
scripts/   the scripts used for these runs; not part of the source tree; no env file.
