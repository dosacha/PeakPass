#!/usr/bin/env bash
# Real-browser checks for the second round of the external review (run peakpass-p6-20261003).
# Not part of the source tree. The page talks to the application through the local proxy, which
# can hold back a reservation read, make a status request carry an invalid token and hold a
# POST /demo/session without answering it.
#   bash review3.sh s21|s22 [label]      label is appended to the evidence names
. /c/Users/dosac/.claude/worktrees/peakpass-issue15/run/lib.sh
REPO=/c/Users/dosac/.claude/worktrees/peakpass-issue15/PeakPass
cd "$REPO" || exit 1
. "$RUN/helpers.sh"
L=${2:+-$2}
NOTES='[...document.querySelectorAll(".queue-note")].map(n => n.innerText.replace(/\s+/g," ")).join(" / ")'
FORM='(() => { const r = Object.fromEntries([...document.querySelectorAll(".insp-row")].map(x => [x.querySelector(".k").innerText, x.querySelector(".v").innerText])); return JSON.stringify({ event: r.selectedEvent, tier: r.selectedTier, quantity: r.quantity, reservation: r.reservationId === "—" ? "—" : r.reservationId.slice(0, 8), queue: r["queue.phase"] }); })()'
proxylog() { grep -c . "$EV/review3.proxy.log" 2>/dev/null || echo 0; }
since() { tail -n +"$(( $1 + 1 ))" "$EV/review3.proxy.log" | grep -v '"OPTIONS"'; }
quantity() { open_step "tier"; js "(() => { const i = document.querySelector('input.input.small[type=number]'); Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(i, '$1'); i.dispatchEvent(new Event('input', { bubbles: true })); return 'quantity $1'; })()" > /dev/null; pause 300; }
# Status requests the proxy forwarded and the application answered, since a line of its log.
forwarded() { since "$1" | grep -c '"method":"GET","path":"/events/[^"]*/admissions/me","upstreamStatus":200'; }

# A reservation read held back while the same event is joined and bought again.
s21() {
  settled; drained; local from; from=$(now); local mark; mark=$(proxylog)
  open_page "s21-earlier-read$L" fixed "$PROXY"
  press "등록"; wait_pill "입장" 40 && echo "first admission: redis=$(redis_entry)" || echo "NOT ADMITTED: $(js "$PILL")"
  echo "first purchase: $(press 'POST /reservations')"; pause 2000
  AB open "$FRONT/index.html?run=s21-earlier-read$L&poll=fixed" > /dev/null; pause 2500
  echo "after the reload: card=$(js "$PILL") form=$(js "$FORM")"
  echo 15000 > "$RUN/delay.flag"
  echo "load: $(press '예약 불러오기')"; pause 400
  rm -f "$RUN/delay.flag"
  echo "join again: $(press '다시 등록')"; wait_pill "입장" 40 && echo "second admission: redis=$(redis_entry)" || echo "NOT ADMITTED: $(js "$PILL")"
  quantity 1
  echo "second purchase: $(press 'POST /reservations')"; pause 2500
  echo "after the second purchase: card=$(js "$PILL") form=$(js "$FORM")"
  pause 15000
  echo "after the held answer of the first read arrived: card=$(js "$PILL") form=$(js "$FORM")"
  echo "proxy:"; since "$mark" | grep -E 'POST","path":"/reservations"|GET","path":"/reservations/'
  save_trace "s21-earlier-read$L" | grep -E "join|purchase|summary"
  save_requests "s21-earlier-read$L"
  applog "s21-earlier-read$L" "$from" "$(now)"
}

# While waiting, a status request answers 401 and the new demo session it asks for is held for
# 20 s; then the application answers again.
s22() {
  settled; local from; from=$(now); local mark; mark=$(proxylog)
  fillers 60 260 400 "s22-session$L"; pause 3000
  open_page "s22-session$L" fixed "$PROXY"
  press "등록"; pause 3000
  echo "waiting: card=$(js "$PILL") redis=$(redis_entry)"
  local before; before=$(proxylog)
  echo 1 > "$RUN/unauth.flag"; touch "$RUN/stall-session.flag"; echo "401 and session stall on at $(now)"
  pause 20000
  rm -f "$RUN/stall-session.flag"; echo "session stall off at $(now)"
  for i in 1 2 3 4 5 6 7 8 9 10 11 12 13; do
    pause 10000
    echo "+$(( 20 + i * 10 )) s: card=$(js "$PILL") status requests answered since the 401: $(forwarded "$before") redis=$(redis_entry)"
  done
  rm -f "$RUN/unauth.flag"
  echo "proxy, sessions and the replaced token:"; since "$before" | grep -E '/demo/session|tokenReplaced'
  save_trace "s22-session$L" | grep -E "summary"
  save_requests "s22-session$L"
  applog "s22-session$L" "$from" "$(now)"
}

"$1"
