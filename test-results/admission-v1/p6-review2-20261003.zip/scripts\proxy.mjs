// A local pass-through proxy that can lose one answer after the server produced it
// (run peakpass-p6-20261003). Not part of the source tree. It stands between the browser and
// the application for the "response lost after the commit" check: when the flag file exists,
// the next POST /reservations is forwarded, its complete upstream answer is read, and then the
// browser's socket is destroyed instead of answering. Everything else passes unchanged,
// including the CORS preflights. The flag file holds how many answers to lose (default 1):
// Chrome repeats a request once by itself when a reused connection closes without an answer,
// so losing two answers is what makes the page's own code see the loss.
//
// While the optional stall file exists, a status request (GET …/admissions/me) is held: it is
// not forwarded and never answered, which is a server that accepted the connection and then
// says nothing. The log records when the browser gave up on it.
//
// The optional join flag file does for a join (POST /events/:id/admissions) what the flag file
// does for a reservation. While the optional delay file exists, the answer of a reservation
// read (GET /reservations/:id) is held back for the number of milliseconds it contains.
//
// The optional unauth flag file makes the next status requests (as many as it says) reach the
// application with an invalid token, so the application itself answers 401. While the optional
// session stall file exists, POST /demo/session is held like a stalled status request.
//
// Usage: node proxy.mjs <listenPort> <targetPort> <flagFile> <logFile> [stallFile] [joinFlagFile] [delayFile] [unauthFlagFile] [sessionStallFile]
// The log holds time, method, path, upstream status and, for a reservation or a join, the id it
// answered with. No header is logged.
import http from 'node:http';
import { appendFileSync, existsSync, readFileSync, unlinkSync, writeFileSync } from 'node:fs';

const [listen, target, flag, log, stall, joinFlag, delayFile, unauthFlag, sessionStall] = process.argv.slice(2);
const record = (entry) => appendFileSync(log, `${JSON.stringify({ at: new Date().toISOString(), ...entry })}\n`);
// Takes one loss from a flag file; the file holds how many are left.
const take = (file) => {
  if (!file || !existsSync(file)) return false;
  const left = (Number(readFileSync(file, 'utf8').trim()) || 1) - 1;
  if (left > 0) writeFileSync(file, String(left));
  else unlinkSync(file);
  return true;
};

http
  .createServer((request, response) => {
    const chunks = [];
    request.on('data', (chunk) => chunks.push(chunk));
    request.on('end', () => {
      const status = request.method === 'GET' && request.url.endsWith('/admissions/me');
      const session = request.method === 'POST' && request.url === '/demo/session';
      if ((status && stall && existsSync(stall)) || (session && sessionStall && existsSync(sessionStall))) {
        const held = Date.now();
        request.socket.once('close', () =>
          record({ method: request.method, path: request.url, held: true, closedByBrowserAfterMs: Date.now() - held }),
        );
        return;
      }
      const purchase = request.method === 'POST' && request.url === '/reservations';
      const join = request.method === 'POST' && /^\/events\/[^/]+\/admissions$/.test(request.url);
      const read = request.method === 'GET' && /^\/reservations\/[^/]+$/.test(request.url);
      const lose = purchase ? take(flag) : join ? take(joinFlag) : false;
      const unauth = status && take(unauthFlag);
      const delayMs = read && delayFile && existsSync(delayFile) ? Number(readFileSync(delayFile, 'utf8').trim()) || 0 : 0;
      const headers = unauth ? { ...request.headers, authorization: 'Bearer invalid-for-the-check' } : request.headers;
      const upstream = http.request(
        { host: '127.0.0.1', port: target, method: request.method, path: request.url, headers },
        (answer) => {
          const parts = [];
          answer.on('data', (part) => parts.push(part));
          answer.on('end', () => {
            const body = Buffer.concat(parts);
            let answered = {};
            try {
              const data = JSON.parse(body.toString('utf8'));
              if (purchase) answered = { reservationId: data.id ?? null };
              if (join) answered = { admissionId: data.admission?.admissionId ?? null, state: data.admission?.state ?? null };
            } catch {
              answered = purchase || join ? { unreadable: true } : {};
            }
            record({
              method: request.method,
              path: request.url,
              upstreamStatus: answer.statusCode,
              answerLost: lose,
              ...(unauth ? { tokenReplaced: true } : {}),
              ...(delayMs ? { delayedMs: delayMs } : {}),
              ...answered,
            });
            if (lose) {
              request.socket.destroy();
              return;
            }
            setTimeout(() => {
              response.writeHead(answer.statusCode, answer.headers);
              response.end(body);
            }, delayMs);
          });
        },
      );
      upstream.on('error', () => {
        record({ method: request.method, path: request.url, upstreamStatus: null, answerLost: false });
        response.writeHead(502);
        response.end();
      });
      upstream.end(Buffer.concat(chunks));
    });
  })
  .listen(Number(listen), '127.0.0.1', () => record({ listening: Number(listen), target: Number(target) }));
