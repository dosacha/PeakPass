// Ticks every checkbox of the named tasks in the P7 plan. Usage: node tick.mjs 0 1 2
import { readFileSync, writeFileSync } from 'node:fs';
const file = 'C:/Users/dosac/.claude/worktrees/peakpass-issue16/PeakPass/docs/superpowers/plans/2026-10-04-issue-16-failure-validation.md';
const tasks = new Set(process.argv.slice(2));
let current = null;
let ticked = 0;
const out = readFileSync(file, 'utf8').split('\n').map((line) => {
  const head = /^## (?:Task (\d+)|.*)/.exec(line);
  if (head) current = head[1] ?? null;
  if (current !== null && tasks.has(current) && line.startsWith('- [ ]')) {
    ticked++;
    return line.replace('- [ ]', '- [x]');
  }
  return line;
});
writeFileSync(file, out.join('\n'));
console.log(`ticked ${ticked}`);
