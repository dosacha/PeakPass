#!/usr/bin/env bash
# Browser scenarios of P7 (run peakpass-p7-20261004): the page of P6 in headless Chrome against two
# containers of the production image, the owned PostgreSQL and Redis, with real failures of those
# containers. Not part of the source tree. Usage: bash b.sh <scenario> | tee evidence/browser/<name>.console.txt
#
# Evidence kinds: the browser, the HTTP exchange, the containers and their failures are real.
# Synthetic stimuli are named where used: waiting users made by SQL (fillers), requests of the
# demo user sent by a script (as_user), a pg_sleep trigger (slow_on), the proxy's lost or held
# answers, a seat count set by SQL, the SQL activation of an event (protect).
. /c/Users/dosac/.claude/worktrees/peakpass-issue16/run/blib.sh
cd "$REPO" || exit 1

# Instants are read from PostgreSQL: the containers and their logs share that clock.
now() { psqlb "SELECT to_char(clock_timestamp() AT TIME ZONE 'UTC','YYYY-MM-DD\"T\"HH24:MI:SS.MS\"Z\"')"; }
ms() { date +%s%3N; }
title() { echo; echo "== $1"; echo "commit $(git rev-parse --short HEAD), image $(docker inspect --format '{{.Image}}' $APP_B | cut -c8-19), page served from the working tree"; }
ready_event() { # the seeded event is protected and its namespace is published
  [ "$(psqlb "SELECT protected FROM admission_events WHERE event_id='$EVENT'")" = "t" ] || protect $EVENT true > /dev/null
  for _ in $(seq 1 60); do [ "$(rcli HGET "peakpass:admission:$EVENT:control" mode 2> /dev/null)" = "ready" ] && return 0; pause 500; done; return 1
}
ready_app() { for _ in $(seq 1 100); do [ "$(curl -s -o /dev/null -w '%{http_code}' "$1/ready" || true)" = "200" ] && return 0; pause 300; done; return 1; }
generation() { rcli HGET "peakpass:admission:$EVENT:control" generation; }
# The purchase limit is five per user and minute: a scenario starts with empty windows.
spaced() { for _ in $(seq 1 45); do [ -z "$(rcli --scan --pattern 'peakpass:ratelimit:reservation:*')$(rcli --scan --pattern 'peakpass:ratelimit:checkout:*')" ] && return 0; sleep 2; done; echo "limiter windows still open"; }
join() { echo "join: $(press '대기열 등록')$(press '다시 등록' | grep clicked)"; pause 1500; }
admitted() { wait_queue "입장" "${1:-120}" && echo "admitted: $(js "$BANNER") | redis $(redis_entry)" || echo "NOT ADMITTED: $(js "$BANNER")"; }
wait_step() { for _ in $(seq 1 "${2:-60}"); do case "$(step_pill "$1")" in \"done*|\"error*) return 0;; esac; pause 500; done; return 1; } # <step> [tries]: done or error
state() { echo "queue=[$(js "$BANNER")] step3=[$(step_pill 'Reservation')] $(rerror)"; }
aid() { field "$(redis_entry "${1:-$USER1}")" admissionId; }
# The ledger rows of a user since an instant, and what they point at.
results() { psqlb "SELECT COALESCE(string_agg(a.operation||'/'||a.outcome||COALESCE('/'||a.http_status||' '||a.error_code,'')||' admission='||left(a.admission_id::text,8)||' reservation='||COALESCE(left(a.reservation_id::text,8)||'('||r.status||',qty '||r.quantity||')','-')||' order='||COALESCE(left(o.id::text,8)||'('||o.status||')','-'), ' ; ' ORDER BY a.created_at),'none') FROM admission_results a LEFT JOIN reservations r ON r.id=a.reservation_id LEFT JOIN orders o ON o.reservation_id=r.id OR o.id=a.order_id WHERE a.user_id='${2:-$USER1}' AND a.created_at >= '$1'"; }
proxylog() { awk -v from="$1" 'index($0,"\"at\":\"")>0 { at=substr($0,8,24); if (at >= from) print }' "$LOGS/browser-proxy.log" | grep -v 'admissions/me' | grep -v OPTIONS | cut -c1-230; }
closing() { # <name> <fromIso>: what every scenario records at its end
  echo "page log: $(reqlog 8)"
  save_trace "$1"; save_requests "$1"
  echo "seats after: $(seats)"
  echo "ledger since start: $(results "$2")"
  applog "$1" "$2" "$(now)"
  final_sql
}

b1() {
  title "B1 join to ticket: wait behind ten users, admission, reservation, checkout, settlement, ticket"
  ready_event; drained; FROM=$(now)
  echo "seats before: $(seats)"
  fillers 10 50 0 b1; pause 3000          # synthetic: ten users join ahead through application B
  open_page b1
  echo "on load: $(js "$BANNER")"
  join
  echo "after join: $(js "$BANNER") | redis $(redis_entry)"
  admitted 150
  open_step "Reservation"; echo "step 3: $(press 'POST /reservations')"; pause 2500
  echo "after reservation: step3=$(step_pill 'Reservation') queue=$(js "$BANNER") | redis $(redis_entry)"
  open_step "Checkout"; echo "step 4: $(press 'POST /checkouts')"; pause 2500
  echo "after checkout: step4=$(step_pill 'Checkout')"
  open_step "Settlement"; echo "step 5: $(press '/demo/settlement')"; pause 3000
  echo "after settlement: step5=$(step_pill 'Settlement')"
  open_step "Read-side"; echo "step 7: $(press 'ticketByCode')$(press 'POST /graphql' | grep clicked)"; pause 2000
  echo "after ticket lookup: step7=$(step_pill 'Read-side')"
  echo "page log: $(reqlog 8)"
  save_trace b1; save_requests b1
  echo "seats after: $(seats)"
  psqlb "SELECT 'result: operation='||a.operation||' outcome='||a.outcome||' reservation.status='||r.status||' order.status='||COALESCE((SELECT o.status FROM orders o WHERE o.reservation_id=r.id),'-')||' tickets='||(SELECT COUNT(*) FROM tickets t JOIN orders o ON o.id=t.order_id WHERE o.reservation_id=r.id) FROM admission_results a JOIN reservations r ON r.id=a.reservation_id WHERE a.user_id='$USER1' ORDER BY a.created_at DESC LIMIT 1"
  applog b1 "$FROM" "$(now)"
  final_sql
}

# One real restart of the Redis container, and the wait until the event is published again.
restart_redis() {
  local g0 e0 t0; g0=$(generation); e0=$(epoch); t0=$(ms)
  docker restart $REDIS > /dev/null
  ready_event
  echo "redis restarted: published again after $(( $(ms) - t0 )) ms, generation $g0 -> $(generation), epoch changed: $([ "$e0" != "$(epoch)" ] && echo yes || echo no)"
}

b2() {
  title "B2 Redis restarts while the page waits and while it is admitted: reset shown, nothing joins or buys by itself"
  ready_event; drained; spaced; FROM=$(now)
  echo "seats before: $(seats)"
  fillers 12 45 20 b2; pause 3500          # synthetic: twelve users ahead through application B
  open_page b2; join
  echo "waiting: $(js "$BANNER") | redis $(redis_entry)"
  OLD=$(aid); OLD_EPOCH=$(epoch)
  restart_redis                              # real: docker restart of the Redis container
  wait_queue "초기화" 60; echo "page after the restart: $(card)"
  echo "browser requests so far: join $(AB network requests --filter 127.0.0.1 | grep -c 'POST .*/admissions '), reservations $(AB network requests --filter 127.0.0.1 | grep -c 'POST .*/reservations')"
  echo "redis: entry of the user in the new epoch: $(redis_entry)"
  echo "old waiting admission used for a purchase (script): $(as_user $API_B user1@example.com reserve $EVENT $TIER 2 $OLD $OLD_EPOCH)"
  echo "rejoin by click: $(press '다시 등록')"; pause 1500
  admitted 60
  OLD=$(aid); OLD_EPOCH=$(epoch)
  restart_redis                              # real: again, now with the page admitted
  wait_queue "초기화" 60; echo "page after the second restart: $(card)"
  pause 6000
  echo "browser requests at the end: join $(AB network requests --filter 127.0.0.1 | grep -c 'POST .*/admissions '), reservations $(AB network requests --filter 127.0.0.1 | grep -c 'POST .*/reservations')"
  echo "redis: entry of the user in the new epoch: $(redis_entry)"
  echo "old admitted admission used for a purchase (script): $(as_user $API_B user1@example.com reserve $EVENT $TIER 2 $OLD $OLD_EPOCH)"
  closing b2 "$FROM"
}

b3() {
  title "B3 Redis is paused when the purchase is clicked: the page repeats the same request, one result"
  ready_event; drained; spaced; FROM=$(now)
  echo "seats before: $(seats)"
  open_page b3; join; admitted 60
  open_step "Reservation"
  docker pause $REDIS > /dev/null; T0=$(ms); echo "redis paused"   # real: the Redis process is frozen
  echo "step 3: $(press 'POST /reservations')"
  for _ in 1 2 3 4; do sleep 2; echo "  +$(( $(ms) - T0 )) ms: $(state)"; done
  docker unpause $REDIS > /dev/null; echo "redis resumed after $(( $(ms) - T0 )) ms"
  wait_step "Reservation" 80; echo "result after $(( $(ms) - T0 )) ms: $(state)"
  pause 2500; echo "queue: $(js "$BANNER") | redis $(redis_entry) | generation $(generation)"
  closing b3 "$FROM"
}

b4() {
  title "B4 application A dies after the commit and before its answer, then restarts: the page's repeat returns the same reservation"
  ready_event; drained; spaced; FROM=$(now)
  echo "seats before: $(seats)"
  open_page b4; join; admitted 60
  slow_on 4                                  # synthetic stimulus: the INSERT sleeps 4 s inside PostgreSQL
  open_step "Reservation"; T0=$(ms); echo "step 3: $(press 'POST /reservations')"
  sleeping && docker pause $REDIS > /dev/null && echo "+$(( $(ms) - T0 )) ms: redis paused while the INSERT sleeps"
  for _ in $(seq 1 120); do [ "$(psqlb "SELECT count(*) FROM admission_results WHERE user_id='$USER1' AND created_at >= '$FROM'")" = "1" ] && break; done
  echo "+$(( $(ms) - T0 )) ms: committed: $(results "$FROM")"
  docker kill $APP_A > /dev/null             # real: SIGKILL of the instance that holds the request
  echo "+$(( $(ms) - T0 )) ms: application A killed: $(docker inspect --format '{{.State.Status}} exit={{.State.ExitCode}}' $APP_A)"
  docker unpause $REDIS > /dev/null; slow_off
  echo "redis entry after the death: $(redis_entry)"
  echo "page: $(state) | $(answer_code 'POST')"
  docker start $APP_A > /dev/null; ready_app $API_A && echo "+$(( $(ms) - T0 )) ms: application A ready again"
  if wait_step "Reservation" 60; then echo "+$(( $(ms) - T0 )) ms: decided by the page's own repeat: $(state)"
  else echo "+$(( $(ms) - T0 )) ms: not decided automatically: $(state) | $(card)"; echo "manual: $(press '같은 요청으로 다시 확인')"; wait_step "Reservation" 40; echo "after the manual repeat: $(state)"; fi
  echo "ledger: $(results "$FROM")"
  open_step "Checkout"; echo "step 4: $(press 'POST /checkouts')"; wait_step "Checkout" 20; echo "after checkout: step4=$(step_pill 'Checkout')"
  open_step "Settlement"; echo "step 5: $(press '/demo/settlement')"; wait_step "Settlement" 20; echo "after settlement: step5=$(step_pill 'Settlement')"
  for _ in $(seq 1 40); do case "$(redis_entry)" in *consumed*) break;; esac; sleep 1; done
  echo "redis entry at the end: $(redis_entry) | queue: $(js "$BANNER")"
  closing b4 "$FROM"
}

b5() {
  title "B5 application A receives SIGTERM and is started again while the page waits: the same entry and sequence"
  ready_event; drained; FROM=$(now)
  fillers 34 170 40 b5; pause 6000         # synthetic: 34 users ahead through application B
  open_page b5; join
  BEFORE=$(redis_entry); echo "waiting: $(js "$BANNER") | redis $BEFORE"
  T0=$(ms); docker kill --signal SIGTERM $APP_A > /dev/null; echo "SIGTERM sent to application A"   # real
  for _ in $(seq 1 50); do
    [ "$(docker inspect --format '{{.State.Running}}' $APP_A)" = "false" ] && break
    sleep 2; echo "  +$(( $(ms) - T0 )) ms running: $(card | cut -c1-260)"
  done
  echo "application A: $(docker inspect --format '{{.State.Status}} exit={{.State.ExitCode}}' $APP_A) after $(( $(ms) - T0 )) ms"
  echo "page while A is down: $(card | cut -c1-300)"
  docker start $APP_A > /dev/null; ready_app $API_A && echo "+$(( $(ms) - T0 )) ms: application A ready again"
  for _ in $(seq 1 60); do case "$(card)" in *notes*:[]*) break;; esac; pause 1000; done
  echo "+$(( $(ms) - T0 )) ms page after the restart: $(card | cut -c1-300)"
  AFTER=$(redis_entry); echo "redis after: $AFTER"
  [ "$(field "$BEFORE" admissionId)/$(field "$BEFORE" sequence)" = "$(field "$AFTER" admissionId)/$(field "$AFTER" sequence)" ] && echo "same admission and sequence: yes" || echo "same admission and sequence: NO"
  echo "cancel by click: $(press '대기 취소')"; pause 500; echo "confirm: $(press '취소 확정')"; wait_queue "취소" 20; echo "queue: $(js "$BANNER") | redis $(redis_entry)"
  closing b5 "$FROM"
}

b6a() {
  title "B6a the event becomes protected after the page loaded: the page's purchase without an admission is refused"
  spaced; FROM=$(now)
  echo "release (SQL transition): $(protect $EVENT false)"
  for _ in $(seq 1 40); do [ "$(rcli EXISTS "peakpass:admission:$EVENT:control")" = "0" ] && break; pause 500; done
  open_page b6a; echo "on load: $(js "$BANNER")"
  echo "activation (SQL transition): $(protect $EVENT true)"; ready_event; echo "control: $(control)"
  echo "seats before: $(seats)"
  open_step "Reservation"; echo "step 3: $(press 'POST /reservations')"; wait_step "Reservation" 20
  echo "page: $(state) | $(answer_code 'POST')"
  echo "page log: $(reqlog 4)"
  reload_page b6a; echo "after a reload: $(js "$BANNER")"
  closing b6a "$FROM"
}

# The page reaches application A through the proxy and its status polls are held, so it still
# shows the admission while a script or a failure changes it on the server.
held_page() { # <runId>
  ready_event; drained; spaced; FROM=$(now)
  echo "seats before: $(seats)"
  open_page "$1" "$PROXY"; join; admitted 60
  open_step "Reservation"
  touch "$RUN/flags/stall-status"; echo "status polls of the page are held by the proxy"
  ADM=$(aid); EP=$(epoch)
}
release_page() { rm -f "$RUN/flags/stall-status"; }

b6b() {
  title "B6b the admission was used by another request of the same user: 409 ADMISSION_REQUEST_MISMATCH"
  held_page b6b
  echo "other device (script), quantity 1: $(as_user $API_B user1@example.com reserve $EVENT $TIER 1 $ADM $EP)"
  echo "step 3 (quantity 2): $(press 'POST /reservations')"; wait_step "Reservation" 30
  echo "page: $(state) | $(answer_code 'POST')"
  release_page; wait_queue "사용" 30; echo "queue after the next poll: $(card | cut -c1-320)"
  echo "proxy: $(proxylog "$FROM")"
  closing b6b "$FROM"
}

b6c() {
  title "B6c the same request is still being processed elsewhere: 409 ADMISSION_IN_PROGRESS, repeated by the page, then the same reservation"
  held_page b6c
  slow_on 3                                  # synthetic stimulus: the INSERT sleeps 3 s inside PostgreSQL
  as_user $API_B user1@example.com reserve $EVENT $TIER 2 $ADM $EP > "$EV/b6c.other.txt" 2>&1 &
  sleeping && echo "the other device's INSERT sleeps in PostgreSQL"
  echo "step 3 (same request): $(press 'POST /reservations')"
  wait; slow_off
  echo "other device (script): $(cat "$EV/b6c.other.txt")"
  wait_step "Reservation" 40; echo "page: $(state)"
  release_page; pause 3000; echo "queue: $(js "$BANNER")"
  echo "proxy: $(proxylog "$FROM")"
  closing b6c "$FROM"
}

b6d() {
  title "B6d Redis loses its data before the click: 410 ADMISSION_RESET"
  held_page b6d
  G0=$(generation); rcli FLUSHALL > /dev/null; echo "redis emptied (FLUSHALL, same process)"   # real data loss
  echo "step 3: $(press 'POST /reservations')"; wait_step "Reservation" 60
  echo "page: $(state) | generation $G0 -> $(generation)"
  release_page; wait_queue "초기화" 30; echo "queue after the next poll: $(card | cut -c1-320)"
  echo "proxy: $(proxylog "$FROM")"
  closing b6d "$FROM"
}

b6e() {
  title "B6e the admission was cancelled elsewhere before the click: 410 ADMISSION_CANCELLED"
  held_page b6e
  echo "other device (script): $(as_user $API_B user1@example.com cancel $EVENT $ADM $EP)"
  echo "step 3: $(press 'POST /reservations')"; wait_step "Reservation" 30
  echo "page: $(state) | $(answer_code 'POST')"
  release_page; wait_queue "취소" 30; echo "queue after the next poll: $(card | cut -c1-320)"
  echo "proxy: $(proxylog "$FROM")"
  closing b6e "$FROM"
}

b6f() {
  title "B6f one seat is left and the page asks for two: 409 INSUFFICIENT_INVENTORY, stored as the answer of that admission"
  ready_event; drained; spaced; FROM=$(now)
  N=$(( $(psqlb "SELECT available_seats FROM events WHERE id='$EVENT'") - 1 ))
  psqlb "UPDATE events SET total_seats=total_seats-$N, available_seats=available_seats-$N WHERE id='$EVENT'" > /dev/null   # synthetic: seat count by SQL
  echo "seats before (total and available lowered by $N): $(seats)"
  open_page b6f; join; admitted 60
  ADM=$(aid); EP=$(epoch)
  open_step "Reservation"; echo "step 3 (quantity 2): $(press 'POST /reservations')"; wait_step "Reservation" 30
  echo "page: $(state)"; pause 2500; echo "queue: $(card | cut -c1-320)"
  psqlb "UPDATE events SET total_seats=total_seats+$N, available_seats=available_seats+$N WHERE id='$EVENT'" > /dev/null
  echo "seats restored: $(seats)"
  echo "same request again with seats available (script): $(as_user $API_B user1@example.com reserve $EVENT $TIER 2 $ADM $EP)"
  closing b6f "$FROM"
}

# A reservation made through the proxy, then a checkout whose two answers are lost.
lost_checkout() { # <runId>
  ready_event; drained; spaced; FROM=$(now)
  echo "seats before: $(seats)"
  open_page "$1" "$PROXY"; join; admitted 60
  open_step "Reservation"; echo "step 3: $(press 'POST /reservations')"; wait_step "Reservation" 30; echo "page: $(state)"
  echo 2 > "$RUN/flags/lose-checkout"       # injected: the proxy drops the next two checkout answers
  open_step "Checkout"; echo "step 4: $(press 'POST /checkouts')"; wait_step "Checkout" 40
  echo "after the lost answers: step4=$(step_pill 'Checkout') | flag left: $(cat "$RUN/flags/lose-checkout" 2> /dev/null || echo none)"
  echo "orders of the user since start: $(psqlb "SELECT COALESCE(string_agg(left(id::text,8)||'('||status||')',' '),'none') FROM orders WHERE user_id='$USER1' AND created_at >= '$FROM'")"
}

b7a() {
  title "B7a the checkout answer is lost: clicking again in the same tab repeats the same key"
  lost_checkout b7a
  echo "step 4 again: $(press 'POST /checkouts')"; wait_step "Checkout" 30; echo "after the repeat: step4=$(step_pill 'Checkout')"
  open_step "Settlement"; echo "step 5: $(press '/demo/settlement')"; wait_step "Settlement" 30; echo "after settlement: step5=$(step_pill 'Settlement')"
  echo "orders of the user since start: $(psqlb "SELECT COALESCE(string_agg(left(o.id::text,8)||'('||o.status||', tickets '||(SELECT count(*) FROM tickets t WHERE t.order_id=o.id)||')',' '),'none') FROM orders o WHERE o.user_id='$USER1' AND o.created_at >= '$FROM'")"
  echo "proxy: $(proxylog "$FROM")"
  closing b7a "$FROM"
}

b7b() {
  title "B7b the checkout answer is lost and the page is reloaded: what the page can still reach"
  lost_checkout b7b
  reload_page b7b; echo "after the reload: $(card | cut -c1-320)"
  echo "load the reservation: $(press '예약 불러오기')"; pause 2500; echo "page: $(state)"
  open_step "Checkout"; echo "step 4 (the key of the lost request is gone): $(press 'POST /checkouts')"; wait_step "Checkout" 30
  echo "after the new checkout: step4=$(step_pill 'Checkout')"
  echo "orders of the user since start: $(psqlb "SELECT COALESCE(string_agg(left(o.id::text,8)||'('||o.status||', tickets '||(SELECT count(*) FROM tickets t WHERE t.order_id=o.id)||', expires in '||round(extract(epoch from (o.payment_deadline_at-now())))||' s)',' '),'none') FROM orders o WHERE o.user_id='$USER1' AND o.created_at >= '$FROM'")"
  echo "proxy: $(proxylog "$FROM")"
  closing b7b "$FROM"
}

base_field() { AB fill 'input[placeholder="http://localhost:3000"]' "$1" > /dev/null; pause 3000; }
who() { js 'document.querySelector(".queue-hint code")?.innerText'; }

b8() {
  title "B8 the page changes its user from A to B and back across a Redis restart: each user sees only its own entry, nothing joins by itself"
  ready_event; drained; FROM=$(now)
  fillers 12 70 80 b8; pause 3500          # synthetic: twelve users ahead through application B
  open_page b8; join
  echo "user A ($(who)): $(js "$BANNER") | redis $(redis_entry $USER1)"
  base_field "$API_B"
  echo "switched to application B, user ($(who)): $(js "$BANNER") | redis $(redis_entry $USER2)"
  join
  echo "user B joined: $(js "$BANNER") | redis $(redis_entry $USER2)"
  restart_redis                              # real: docker restart of the Redis container
  wait_queue "초기화" 60; echo "user B after the restart: $(card | cut -c1-300)"
  base_field "$API_A"
  echo "switched back to application A, user ($(who)): $(card | cut -c1-300)"
  pause 6000
  echo "redis in the new epoch: user A $(redis_entry $USER1) | user B $(redis_entry $USER2)"
  echo "browser requests: join $(AB network requests --filter 127.0.0.1 | grep -c 'POST .*/admissions '), reservations $(AB network requests --filter 127.0.0.1 | grep -c 'POST .*/reservations')"
  join
  echo "user A joined again by click: $(js "$BANNER") | redis $(redis_entry $USER1) | user B $(redis_entry $USER2)"
  echo "cancel by click: $(press '대기 취소')"; pause 500; echo "confirm: $(press '취소 확정')"; wait_queue "취소" 20; echo "queue: $(js "$BANNER")"
  closing b8 "$FROM"
}

"$@"
