// Replays recorded transition logs with the replay helper of the working tree and reports, per
// log, the violations by rule and the most promotions one event saw in a rolling second across
// its epochs (run peakpass-p7-20261004). Not part of the source tree.
// Usage: node replay-check.js <label-prefix>      e.g. final  ->  evidence/final-r*-*/
const fs = require('fs');
const path = require('path');
const RUN = __dirname;
const REPO = path.join(RUN, '..', 'PeakPass');
const ts = require(path.join(REPO, 'node_modules', 'typescript'));
const source = fs.readFileSync(path.join(REPO, 'src', 'tests', 'helpers', 'admission-transition-log.ts'), 'utf8');
const compiled = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText;
const helper = { exports: {} };
new Function('module', 'exports', compiled)(helper, helper.exports);
const { parseMonitorLine, replayAdmissionLog } = helper.exports;

const KEY = /^peakpass:admission:([0-9a-f-]{36}):([0-9a-f-]{36}):active$/;
const prefix = process.argv[2] || 'final';
const folders = fs.readdirSync(path.join(RUN, 'evidence')).filter((name) => new RegExp('^' + prefix + '-r\\d+-').test(name)).sort();
let worst = 0;
for (const folder of folders) {
  for (const file of fs.readdirSync(path.join(RUN, 'evidence', folder)).filter((name) => name.endsWith('-transitions.log'))) {
    const entries = fs.readFileSync(path.join(RUN, 'evidence', folder, file), 'utf8').split(/\r?\n/).map(parseMonitorLine).filter(Boolean);
    const replay = replayAdmissionLog(entries);
    const byRule = {};
    for (const violation of replay.violations) byRule[violation.rule] = (byRule[violation.rule] || 0) + 1;
    // Promotions of one event, over all of its epochs, by the time Redis ran the command.
    const promotions = new Map();
    for (const { time, args } of entries) {
      if ((args[0] || '').toUpperCase() !== 'ZADD' || args[3] === undefined || args[3] === '__') continue;
      const key = KEY.exec(args[1] || '');
      if (!key) continue;
      if (!promotions.has(key[1])) promotions.set(key[1], []);
      promotions.get(key[1]).push({ time, epoch: key[2] });
    }
    let most = 0;
    let across = 0;
    for (const list of promotions.values()) {
      for (const at of list) {
        const inSecond = list.filter((other) => other.time > at.time - 1000 && other.time <= at.time);
        most = Math.max(most, inSecond.length);
        if (inSecond.length > 2 && new Set(inSecond.map((other) => other.epoch)).size > 1) across++;
      }
    }
    worst = Math.max(worst, most);
    console.log(`${folder}/${file}: entries ${entries.length}, promotions ${replay.promotions}, violations ${JSON.stringify(byRule)}, most promotions of one event in a rolling second over all epochs ${most}, windows above 2 that span epochs ${across}`);
  }
}
console.log(`logs ${folders.length}, most promotions of one event in a rolling second over all epochs: ${worst}`);
