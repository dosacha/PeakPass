#!/usr/bin/env bash
# The whole re-verification on a rebuilt image, one step after the other (run
# peakpass-p7-20261004): image checks, browser scenarios, final regression with three rounds of
# the fault suites. Not part of the source tree. Progress goes to logs/chain.txt.
cd /c/Users/dosac/.claude/worktrees/peakpass-issue16/run || exit 1
out=logs/chain.txt; : > "$out"
say() { echo "$(date -u +%H:%M:%S) $*" | tee -a "$out"; }
say "image $(docker image inspect peakpass:p7-issue16 --format '{{.Id}}'), commit $(cd ../PeakPass && git rev-parse --short HEAD)"
bash browser-env.sh down 2>&1 | tail -2 | while read -r line; do say "browser down: $line"; done
bash image-check.sh "${1:-image-f1b}" 2>&1 | cut -c1-180 | while read -r line; do say "image: $line"; done
bash browser-env.sh up 2>&1 | tail -1 | while read -r line; do say "browser up: $line"; done
bash browser-env.sh serve 2>&1 | tail -1 | while read -r line; do say "browser serve: $line"; done
bash ball.sh 2>&1 | grep --line-buffered -E "^== |final SQL|^summary:|NOT ADMITTED|all browser" | cut -c1-170 | while read -r line; do say "browser: $line"; done
bash final.sh final 3 2>&1 | grep --line-buffered -E "exit=|×|LEFTOVER| done$" | cut -c1-170 | while read -r line; do say "final: $line"; done
say "chain done"
