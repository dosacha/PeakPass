#!/usr/bin/env bash
# Runs the regression commands of the validation documents on the owned test resources and keeps
# every output under logs/<label>-*.log. Usage: suite.sh <label> [build|lint|unit|integration|harness|all]
. /c/Users/dosac/.claude/worktrees/peakpass-issue16/run/lib.sh
label=$1; what=${2:-all}
mkdir -p "$LOGS"; cd "$REPO" || exit 1
load_env test.env
run() { # name, command...
  local name=$1; shift
  "$@" > "$LOGS/$label-$name.log" 2>&1
  echo "$name: exit=$? $(tail -n 400 "$LOGS/$label-$name.log" | grep -E '^(Tests|Test Suites):|^# (tests|pass|fail)|problems \(|PASS:|run-isolation' | tr '\n' ' ')"
}
case $what in build|all)
  run build npm run build
  run typecheck npx --no-install tsc --noEmit ;;
esac
case $what in lint|all) run lint npm run lint ;; esac
case $what in unit|all) run unit npm test -- --runInBand ;; esac
case $what in integration|all)
  run migrate npm run migrate:up
  run integration npx --no-install jest --runInBand --config jest.integration.cjs ;;
esac
case $what in harness|all)
  run harness npm run test:flash-sale
  run callback node --experimental-vm-modules load-test/payment-callback-check.mjs ;;
esac
