// Summarizes the notes the fault suites wrote in the rounds of the final regression (run
// peakpass-p7-20261004). Not part of the source tree. Usage: node rounds.mjs <label> <rounds>
// Prints one line per note kind and round, without the scenario markers and the docker commands.
import { existsSync, readFileSync } from 'node:fs';

const [label = 'final', rounds = '3'] = process.argv.slice(2);
const notes = (round, suite) => {
  const file = `evidence/${label}-r${round}-${suite}/${suite}-notes.jsonl`;
  if (!existsSync(file)) return [];
  return readFileSync(file, 'utf8').trim().split('\n').map((line) => JSON.parse(line));
};
const brief = (value) => JSON.stringify(value).replace(/"/g, '').slice(0, 900);

for (const suite of ['redis', 'process', 'flows']) {
  console.log(`\n== ${suite}`);
  const kinds = new Map();
  for (let round = 1; round <= Number(rounds); round++) {
    for (const { at, what, ...rest } of notes(round, suite)) {
      if (what === 'scenario' || what === 'migrations' || what.startsWith('docker ') || what === 'FLUSHALL') continue;
      if (!kinds.has(what)) kinds.set(what, []);
      kinds.get(what).push(`r${round} ${brief(rest)}`);
    }
  }
  for (const [what, lines] of kinds) {
    console.log(`-- ${what}`);
    for (const line of lines) console.log(`   ${line}`);
  }
}
