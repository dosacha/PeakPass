#!/usr/bin/env bash
# Waits for CI and the Codex auto-review of one PR head (run peakpass-p7-20261004). Not part of
# the source tree. Usage: watch-pr.sh <sha7>
sha=$1; repo=dosacha/PeakPass; n=0
while [ $n -lt 90 ]; do
  ci=$(gh pr checks 31 --repo $repo 2>/dev/null | awk -F'\t' '{print $1"="$2}' | tr '\n' ' ')
  rv=$(gh api repos/$repo/pulls/31/reviews --jq '[.[] | "\(.state)@\(.commit_id[0:7])"] | join(",")' 2>/dev/null)
  ic=$(gh api repos/$repo/pulls/31/comments --jq "[.[] | select(.commit_id | startswith(\"$sha\"))] | length" 2>/dev/null)
  st=$(gh api repos/$repo/issues/31/comments --jq '[.[] | select(.body | contains("codex-pull-request-review-summary"))] | last | .body' 2>/dev/null | tr '\n' ' ' | grep -oE '(Running|Completed|Failed)[^|]*\| `[0-9a-f]+`' | head -1)
  rc=$(gh api repos/$repo/issues/31/reactions --jq '[.[] | "\(.user.login):\(.content)@\(.created_at)"] | join(",")' 2>/dev/null)
  echo "$(date -u +%H:%M:%S) ci[$ci] reviews[$rv] inline@$sha[$ic] summary[$st] reactions[$rc]"
  case "$ci" in *pending*|"") ;; *)
    if echo "$st" | grep -q "Completed.*$sha" || echo "$rv" | grep -q "@$sha" || echo "$rc" | grep -q ":+1@"; then echo done; exit 0; fi ;;
  esac
  n=$((n+1)); sleep 30
done
echo "timed out"
