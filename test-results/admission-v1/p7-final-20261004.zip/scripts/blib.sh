# Helpers of the P7 browser checks (run peakpass-p7-20261004), adapted from lib.sh and helpers.sh
# of the P6 run. Source it. Not part of the source tree. Nothing here prints a token: the request
# list is read without headers and the page trace holds none.
. /c/Users/dosac/.claude/worktrees/peakpass-issue16/run/lib.sh
. "$RUN/browser-ports.env"
export AGENT_BROWSER_SESSION=peakpass-p7
EV=$RUN/evidence/browser
mkdir -p "$EV" "$RUN/flags"
FRONT=http://127.0.0.1:$FRONT_PORT
API_A=http://127.0.0.1:$API_A_PORT
API_B=http://127.0.0.1:$API_B_PORT
PROXY=http://127.0.0.1:$PROXY_PORT
EVENT=a3ae4dfe-160b-5ec7-9a08-125b9235b45f
OTHER_EVENT=4ed183c2-ab4d-54a8-8404-d4f5b932e9a6
TIER=91dfab04-048e-53af-b2ec-50bcaeff16e1
REDIS=peakpass-p7-redis-browser
APP_A=peakpass-p7-app-a
APP_B=peakpass-p7-app-b

AB() { timeout 45 agent-browser "$@" 2>&1; }
js() { AB eval "$1" | tail -1; }
pause() { AB wait "$1" > /dev/null; }
now() { date -u +%Y-%m-%dT%H:%M:%S.%3NZ; }
field() { node -e 'console.log(JSON.parse(process.argv[1])[process.argv[2]])' "$1" "$2"; }

# Opens the page for one scenario: live mode, the given API base and event, a run id.
open_page() { # <runId> [apiBase] [eventId]
  AB open "$FRONT/index.html" > /dev/null
  js "localStorage.setItem('pp_api_base','${2:-$API_A}'); localStorage.setItem('pp_mode','live'); localStorage.setItem('pp_event_id','${3:-$EVENT}'); localStorage.setItem('pp_tier_id','$TIER'); 'ok'" > /dev/null
  # The static server sends no cache policy; reading each file with cache "reload" replaces a cached copy.
  AB eval '(async () => { for (const f of ["index.html","styles.css","utils.js","admission-polling.js","app.jsx","app-flow.jsx"]) await (await fetch(f, { cache: "reload" })).text(); return "fresh"; })()' > /dev/null
  AB network requests --clear > /dev/null
  AB open "$FRONT/index.html?run=$1&poll=adaptive" > /dev/null
  pause 2500
}
reload_page() { AB open "$FRONT/index.html?run=$1&poll=adaptive" > /dev/null; pause 2500; }

PILL='document.querySelector(".step .status-pill")?.innerText'
BANNER='document.querySelector(".qb-title")?.innerText'
card() {
  js 'JSON.stringify({pills: [...document.querySelectorAll(".step .status-pill")].map(p => p.innerText).join(","), queue: document.querySelector(".qb-title")?.innerText, banner: document.querySelector(".queue-banner")?.innerText.replace(/\n/g," | "), notes: [...document.querySelectorAll(".queue-note")].map(n => n.innerText), error: [...document.querySelectorAll(".rb-title, .rb-sub")].map(n => n.innerText).join(" | ")})'
}
# Only action buttons: a step header is a button too and names the same endpoint.
press() { js "(() => { const b = [...document.querySelectorAll('button.btn')].find(b => b.innerText.includes('$1')); if (!b) return 'no button: $1'; if (b.disabled) return 'disabled: $1'; b.click(); return 'clicked: $1'; })()"; }
open_step() { js "(() => { const s = [...document.querySelectorAll('.step')].find(s => s.querySelector('.step-head').innerText.includes('$1')); if (!s) return 'no step: $1'; if (!s.querySelector('.step-body')) s.querySelector('.step-head').click(); return 'open: $1'; })()" > /dev/null; pause 300; }
# The state of one step, by a text of its header: the state class of the card and its meta line.
step_pill() { js "(() => { const s = [...document.querySelectorAll('.step')].find(s => s.querySelector('.step-head').innerText.includes('$1')); return s ? s.className.replace('step','').trim() + ' / ' + s.querySelector('.step-meta').innerText.replace(/\\s+/g,' ') : 'no step'; })()"; }
# The error code in the body of the newest request-log line that names <text>, as the page shows it.
answer_code() {
  js "(() => { const r = [...document.querySelectorAll('.log-entry')].reverse().find(r => r.innerText.includes('$1')); if (!r) return 'no line'; if (!r.innerText.includes('\"code\"')) r.querySelector('.le-head')?.click(); return 'open'; })()" > /dev/null; pause 300
  js "(() => { const r = [...document.querySelectorAll('.log-entry')].reverse().find(r => r.innerText.includes('$1')); const m = r && r.innerText.match(/\"code\":\\s*\"([A-Z_]+)\"/); return r ? r.querySelector('.le-head').innerText.replace(/\\s+/g,' ').slice(0,60) + ' code=' + (m ? m[1] : 'none') : 'no line'; })()"
}
# The purchase error banner of the reservation step and the result-unknown box.
rerror() { js "JSON.stringify({error: [...document.querySelectorAll('.rb-title, .rb-sub')].map(n => n.innerText.replace(/\\s+/g,' ')).join(' | '), pills: [...document.querySelectorAll('.step .status-pill')].map(p => p.innerText).join(',')})"; }
wait_queue() { for _ in $(seq 1 "${2:-90}"); do case "$(js "$BANNER")" in *"$1"*) return 0;; esac; pause 700; done; return 1; }
# The page's own request log: method, path, status of the last lines (no header is shown there).
reqlog() { js "JSON.stringify([...document.querySelectorAll('.log-entry')].slice(-${1:-8}).map(r => r.innerText.replace(/\\s+/g,' ').slice(0,110)))"; }

save_trace() { # <name>
  AB eval 'JSON.stringify(window.PeakPassAdmissionTrace.snapshot())' | tail -1 \
    | node -e 'let s="";process.stdin.on("data",d=>s+=d).on("end",()=>require("fs").writeFileSync(process.argv[1],JSON.stringify(JSON.parse(JSON.parse(s)),null,1)+"\n"))' "$EV/$1.trace.json"
  node "$RUN/summary.mjs" "$EV/$1.trace.json" | grep -E "^(purchase|join|cancel|epoch|RECOGNITION|MISSED|summary)" | cut -c1-260
}
# The browser's own request list: method, URL and status only.
save_requests() { # <name>
  AB network requests --filter 127.0.0.1 > "$EV/$1.requests.txt"
  echo "requests: $(grep -c . "$EV/$1.requests.txt") lines; join $(grep -c 'POST .*/admissions ' "$EV/$1.requests.txt"), status $(grep -c 'GET .*/admissions/me' "$EV/$1.requests.txt"), reservations $(grep -c 'POST .*/reservations' "$EV/$1.requests.txt"), checkouts $(grep -c 'POST .*/checkouts' "$EV/$1.requests.txt"), settlement $(grep -c 'POST .*/demo/settlement' "$EV/$1.requests.txt")"
}
# The applications' own request logs between two instants, as an observer independent of the page.
applog() { # <name> <fromIso> <toIso>
  docker logs $APP_A > "$LOGS/browser-app-a.log" 2>&1; docker logs $APP_B > "$LOGS/browser-app-b.log" 2>&1
  ( cd "$RUN" && node applog.mjs logs/browser-app-a.log,logs/browser-app-b.log "$2" "$3" > "$EV/$1.applog.json" )
  echo "server log: $(cat "$EV/$1.applog.json" | cut -c1-600)"
}

rcli() { docker exec $REDIS redis-cli "$@"; }
epoch() { rcli HGET "peakpass:admission:$EVENT:control" epoch; }
control() { rcli HGETALL "peakpass:admission:$EVENT:control" | paste -sd' ' | sed -E 's/runId [0-9a-f]+/runId …/'; }
entry() { rcli HGET "peakpass:admission:$EVENT:$(epoch):entries" "$1"; }
latest() { rcli HGET "peakpass:admission:$EVENT:$(epoch):latest" "$1"; }
psqlb() { docker exec peakpass-p7-pg psql -U peakpass -d peakpass_browser -Atc "$1"; }
USER1=$(psqlb "SELECT id FROM users WHERE email='user1@example.com'")
USER2=$(psqlb "SELECT id FROM users WHERE email='user2@example.com'")
redis_entry() { # [userId]
  entry "$(latest "${1:-$USER1}")" | node -e 'let s="";process.stdin.on("data",d=>s+=d).on("end",()=>{try{const e=JSON.parse(s);console.log(JSON.stringify({admissionId:e.admissionId,sequence:e.sequence,state:e.state,phase:e.phase,reason:e.reason,outcome:e.outcome}))}catch{console.log("no entry")}})'
}
seats() { psqlb "SELECT 'available='||e.available_seats||' total='||e.total_seats||' held='||(SELECT COALESCE(SUM(quantity),0) FROM reservations WHERE event_id=e.id AND status='active')||' ordered='||(SELECT COALESCE(SUM(quantity),0) FROM orders WHERE event_id=e.id AND status IN ('pending','paid','delivered'))||' reservations='||(SELECT COUNT(*) FROM reservations WHERE event_id=e.id)||' orders='||(SELECT COUNT(*) FROM orders WHERE event_id=e.id)||' tickets='||(SELECT COUNT(*) FROM tickets WHERE event_id=e.id)||' results='||(SELECT COUNT(*) FROM admission_results WHERE event_id=e.id) FROM events e WHERE e.id='${1:-$EVENT}'"; }
# The final SQL of contract §8, the same file the Jest suites run: every row is a violation.
final_sql() { local rows; rows=$(docker exec -i peakpass-p7-pg psql -U peakpass -d peakpass_browser -At < "$REPO/src/tests/integration/admission-final.sql"); echo "final SQL violations: $(printf '%s' "$rows" | grep -c .) $rows"; }
# Requests of a seed user outside the browser, and synthetic waiting users.
as_user() { ( cd "$REPO" && load_env browser.env && DB_NAME=peakpass_browser node "$RUN/as-user.mjs" "$@" ); }
fillers() { # <count> <seconds> <firstIndex> <name>
  ( cd "$REPO" && load_env browser.env && DB_NAME=peakpass_browser node "$RUN/fillers.mjs" "$API_B" "$EVENT" "$1" "$2" "$3" > "$EV/$4.fillers.log" 2>&1 & ) > /dev/null 2>&1
}
protect() { ( cd "$REPO" && load_env browser.env && DB_NAME=peakpass_browser npx --no-install tsx "$RUN/protect.ts" "$1" "$2" 2>&1 | grep -E '^\{"eventId"' ); }
# Waits until the user's last entry is finished and nobody waits or is admitted.
drained() {
  for _ in $(seq 1 90); do
    w=$(rcli ZCARD "peakpass:admission:$EVENT:$(epoch):waiting"); a=$(rcli ZCARD "peakpass:admission:$EVENT:$(epoch):active")
    [ "$w" = "1" ] && [ "$a" = "1" ] && return 0
    pause 2000
  done
  return 1
}
# Synthetic stimulus: the demo user's reservation INSERT sleeps for <seconds> inside PostgreSQL.
slow_on() { psqlb "CREATE OR REPLACE FUNCTION p7_sleep() RETURNS trigger LANGUAGE plpgsql AS \$\$ BEGIN PERFORM pg_sleep(TG_ARGV[0]::float8); RETURN NEW; END \$\$; DROP TRIGGER IF EXISTS p7_slow ON reservations; CREATE TRIGGER p7_slow BEFORE INSERT ON reservations FOR EACH ROW WHEN (NEW.user_id = '$USER1'::uuid) EXECUTE FUNCTION p7_sleep('$1')" > /dev/null; }
slow_off() { psqlb "DROP TRIGGER IF EXISTS p7_slow ON reservations" > /dev/null; }
sleeping() { for _ in $(seq 1 100); do [ "$(psqlb "SELECT count(*) FROM pg_stat_activity WHERE wait_event='PgSleep' AND query ILIKE '%INSERT INTO reservations%'")" != "0" ] && return 0; node -e "setTimeout(()=>{},100)"; done; return 1; }
