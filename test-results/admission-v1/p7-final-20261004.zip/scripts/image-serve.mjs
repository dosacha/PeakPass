// Smoke of the P7 image on an existing database (see image-check.sh). Not part of the source tree.
// Run from the repository root so that jsonwebtoken resolves; BASE is the published address.
import { createRequire } from 'node:module';
const require = createRequire('C:/Users/dosac/.claude/worktrees/peakpass-issue16/PeakPass/package.json');
const jwt = require('jsonwebtoken');
const base = process.env.BASE;
const user = '11111111-1111-4111-8111-111111111111';
// The image runs with NODE_ENV unset here, so it signs with the documented development secret.
const token = `Bearer ${jwt.sign({ sub: user }, 'dev-secret-change-in-production-32chars', { expiresIn: '5m' })}`;
let ready;
for (let i = 0; i < 60 && ready?.status !== 200; i++) {
  ready = await fetch(`${base}/ready`).catch(() => undefined);
  if (ready?.status !== 200) await new Promise((r) => setTimeout(r, 500));
}
console.log('ready:', ready?.status, JSON.stringify((await ready.json()).checks));
const post = async (path, body, headers = {}) => {
  const r = await fetch(base + path, {
    method: 'POST',
    body: JSON.stringify(body),
    headers: { 'content-type': 'application/json', authorization: token, ...headers },
  });
  return [r.status, await r.json()];
};
const purchase = { userId: user, tierId: 'general' };
const [converted, order] = await post(
  '/checkouts',
  { ...purchase, quantity: 1, eventId: '22222222-2222-4222-8222-222222222222', reservationId: '44444444-4444-4444-8444-444444444444' },
  { 'idempotency-key': '88888888-8888-4888-8888-888888888888' },
);
console.log('existing reservation checkout:', converted, order.order?.status);
const [reserved, reservation] = await post('/reservations', {
  ...purchase,
  quantity: 1,
  eventId: '33333333-3333-4333-8333-333333333333',
});
console.log('new reservation on the event without a policy row:', reserved, reservation.status);
// The reservation that a consumed result stands for is replayed by its admission.
const [replayed, replay] = await post('/reservations', {
  ...purchase,
  quantity: 1,
  eventId: '22222222-2222-4222-8222-222222222222',
  admissionId: 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',
  admissionEpoch: 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb',
});
console.log('replay of the stored result:', replayed, replay.id);
if (ready?.status !== 200 || converted !== 201 || reserved !== 201 || replayed !== 201 || replay.id !== '99999999-9999-4999-8999-999999999999')
  process.exit(1);
