// Synthetic waiting users for the P7 browser checks (run peakpass-p7-20261004, taken from the P6 run). Not part of the
// source tree. The users are rows created by SQL and their JWTs are signed with the secret of
// the owned environment; every queue transition they cause is a real HTTP request to the
// application and a real Lua call in Redis. They never buy: an admitted filler holds a slot
// until its 30 s TTL ends, which is what keeps a browser user waiting behind them.
//
// Usage, from the worktree root with the browser environment exported:
//   node ../run/fillers.mjs <baseUrl> <eventId> <count> <seconds> [firstIndex]
// Prints one JSON line per round with the number of fillers in each state. No token is printed.
import { createRequire } from 'node:module';
import { randomUUID } from 'node:crypto';

const require = createRequire(`${process.cwd()}/package.json`);
const { Client } = require('pg');
const jwt = require('jsonwebtoken');

const [base, eventId, countArg, secondsArg, firstArg] = process.argv.slice(2);
const count = Number(countArg);
const seconds = Number(secondsArg);
const first = Number(firstArg ?? 0);
if (!base || !eventId || !Number.isInteger(count) || !Number.isFinite(seconds)) {
  throw new Error('usage: fillers.mjs <baseUrl> <eventId> <count> <seconds> [firstIndex]');
}
const pause = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const db = new Client({
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT),
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
});
await db.connect();
const users = [];
for (let index = first; index < first + count; index += 1) {
  const email = `filler-${String(index).padStart(3, '0')}@p7.test`;
  await db.query('INSERT INTO users(id,email,name) VALUES($1,$2,$3) ON CONFLICT (email) DO NOTHING', [
    randomUUID(),
    email,
    `Filler ${index}`,
  ]);
  const id = (await db.query('SELECT id FROM users WHERE email=$1', [email])).rows[0].id;
  users.push({ id, token: jwt.sign({ sub: id }, process.env.JWT_SECRET, { expiresIn: '2h' }) });
}
await db.end();

const call = async (user, method, path, body) => {
  const response = await fetch(`${base}${path}`, {
    method,
    headers: { Authorization: `Bearer ${user.token}`, 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: response.status, data: await response.json().catch(() => null) };
};
const path = `/events/${eventId}/admissions`;

const epoch = (await call(users[0], 'GET', `${path}/me`)).data?.queue?.epoch;
if (!epoch) throw new Error('the event has no open queue');
// One after the other, so that the order of the fillers is their order in the queue.
for (const user of users) {
  const joined = await call(user, 'POST', path, { epoch, joinRequestId: randomUUID() });
  user.joined = joined.status;
}
console.log(JSON.stringify({ at: new Date().toISOString(), epoch, joined: users.map((u) => u.joined) }));

const end = Date.now() + seconds * 1000;
for (;;) {
  const states = {};
  for (const user of users) {
    const status = await call(user, 'GET', `${path}/me`);
    const state = status.data?.admission?.state ?? `http-${status.status}`;
    states[state] = (states[state] ?? 0) + 1;
  }
  console.log(JSON.stringify({ at: new Date().toISOString(), ...states }));
  if (Date.now() >= end) break;
  // Often enough to keep a waiting lease (120 s) alive.
  await pause(10000);
}
