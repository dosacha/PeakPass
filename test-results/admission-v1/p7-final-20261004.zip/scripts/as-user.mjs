// Requests of a seed user sent outside the browser (run peakpass-p7-20261004, extended from the
// script of the P6 run): another tab or device of the same user, as far as the server can tell.
// Not part of the source tree. The JWT is signed with the secret of the owned environment and
// never printed.
//
// Usage, from the worktree root with the browser environment exported:
//   node ../run/as-user.mjs <baseUrl> <email> status  <eventId>
//   node ../run/as-user.mjs <baseUrl> <email> cancel  <eventId> <admissionId> <epoch>
//   node ../run/as-user.mjs <baseUrl> <email> reserve <eventId> <tierId> <quantity> <admissionId> <epoch>
//   node ../run/as-user.mjs <baseUrl> <email> direct  <eventId> <tierId> <quantity> <admissionId> <epoch>
import { createRequire } from 'node:module';
import { randomUUID } from 'node:crypto';

const require = createRequire(`${process.cwd()}/package.json`);
const { Client } = require('pg');
const jwt = require('jsonwebtoken');

const [base, email, action, eventId, a, b, c, d] = process.argv.slice(2);
const db = new Client({
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT),
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
});
await db.connect();
const userId = (await db.query('SELECT id FROM users WHERE email=$1', [email])).rows[0]?.id;
await db.end();
if (!userId) throw new Error(`no user ${email}`);
const headers = {
  Authorization: `Bearer ${jwt.sign({ sub: userId }, process.env.JWT_SECRET, { expiresIn: '5m' })}`,
  'Content-Type': 'application/json',
};
const queue = `${base}/events/${eventId}/admissions`;
const print = (extra) =>
  console.log(JSON.stringify({ at: new Date().toISOString(), user: userId.slice(0, 8), action, ...extra }));
const answer = async (response) => ({ status: response.status, body: await response.json().catch(() => null) });

if (action === 'status') {
  const { status, body } = await answer(await fetch(`${queue}/me`, { headers }));
  print({
    status,
    code: body?.error?.code ?? null,
    epoch: body?.queue?.epoch ?? null,
    admissionId: body?.admission?.admissionId ?? null,
    state: body?.admission?.state ?? null,
    phase: body?.admission?.phase ?? null,
  });
} else if (action === 'cancel') {
  const { status, body } = await answer(
    await fetch(`${queue}/${a}`, { method: 'DELETE', headers, body: JSON.stringify({ epoch: b }) }),
  );
  print({ admissionId: a, status, code: body?.error?.code ?? null, state: body?.admission?.state ?? null });
} else if (action === 'reserve' || action === 'direct') {
  const purchase = { eventId, userId, tierId: a, quantity: Number(b), admissionId: c, admissionEpoch: d };
  const { status, body } = await answer(
    await fetch(`${base}/${action === 'reserve' ? 'reservations' : 'checkouts'}`, {
      method: 'POST',
      headers: action === 'reserve' ? headers : { ...headers, 'Idempotency-Key': randomUUID() },
      body: JSON.stringify(purchase),
    }),
  );
  print({ status, code: body?.error?.code ?? null, id: body?.id ?? body?.order?.id ?? null });
} else {
  throw new Error('unknown action');
}
