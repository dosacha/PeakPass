// Owned resources of the P7 task (run peakpass-p7-20261004). Not part of the source tree.
// One PostgreSQL 16 container (track_commit_timestamp=on) with the databases of this task and two
// Redis 7 containers (AOF/RDB off, noeviction). Every host port is asked from the operating system
// at creation and then published explicitly, so it survives stop and start. Nothing secret is printed.
import { execFileSync } from 'node:child_process';
import { randomBytes } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { createServer } from 'node:net';
import { fileURLToPath } from 'node:url';

const here = (name) => fileURLToPath(new URL(name, import.meta.url));
const label = 'peakpass.task=peakpass-p7-20261004';
const docker = (...args) => execFileSync('docker', args, { encoding: 'utf8' }).trim();
const exists = (name) => docker('ps', '-a', '--filter', `name=^${name}$`, '--format', '{{.Names}}') === name;
const pause = (ms) => Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
const port = (name, inner) => docker('port', name, `${inner}/tcp`).split('\n')[0].split(':').pop();
const freePort = () =>
  new Promise((resolve, reject) => {
    const server = createServer();
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const { port: chosen } = server.address();
      server.close(() => resolve(chosen));
    });
  });
const databases = ['peakpass_test', 'peakpass_browser', 'peakpass_image_off', 'peakpass_image_on', 'peakpass_upgrade'];

if (!existsSync(here('pg.env'))) {
  writeFileSync(
    here('pg.env'),
    `POSTGRES_USER=peakpass\nPOSTGRES_PASSWORD=${randomBytes(18).toString('base64url')}\nPOSTGRES_DB=peakpass_test\n`,
  );
}
const pgEnv = Object.fromEntries(
  readFileSync(here('pg.env'), 'utf8').trim().split('\n').map((line) => line.split(/=(.*)/s).slice(0, 2)),
);

if (!exists('peakpass-p7-pg')) {
  docker('run', '-d', '--name', 'peakpass-p7-pg', '--label', label, '--env-file', here('pg.env'),
    '-p', `127.0.0.1:${await freePort()}:5432`, 'postgres:16-alpine', '-c', 'track_commit_timestamp=on');
}
for (const name of ['peakpass-p7-redis-test', 'peakpass-p7-redis-browser']) {
  if (!exists(name)) {
    // The outage label marks a Redis that tests may stop, pause and start.
    docker('run', '-d', '--name', name, '--label', label, '--label', 'peakpass.redis-outage=owned',
      '-p', `127.0.0.1:${await freePort()}:6379`, 'redis:7-alpine',
      'redis-server', '--save', '', '--appendonly', 'no', '--maxmemory', '256mb',
      '--maxmemory-policy', 'noeviction');
  }
}

for (let attempt = 0; ; attempt++) {
  try {
    docker('exec', 'peakpass-p7-pg', 'pg_isready', '-U', pgEnv.POSTGRES_USER, '-d', pgEnv.POSTGRES_DB);
    docker('exec', 'peakpass-p7-pg', 'psql', '-U', pgEnv.POSTGRES_USER, '-d', pgEnv.POSTGRES_DB, '-c', 'SELECT 1');
    break;
  } catch (error) {
    if (attempt > 60) throw new Error('PostgreSQL did not become ready');
    pause(500);
  }
}
const psql = (sql) =>
  docker('exec', 'peakpass-p7-pg', 'psql', '-U', pgEnv.POSTGRES_USER, '-d', pgEnv.POSTGRES_DB, '-Atc', sql);
const present = psql('SELECT datname FROM pg_database').split('\n');
for (const name of databases) if (!present.includes(name)) psql(`CREATE DATABASE ${name}`);

const common = [
  'DB_HOST=127.0.0.1',
  `DB_PORT=${port('peakpass-p7-pg', 5432)}`,
  `DB_USER=${pgEnv.POSTGRES_USER}`,
  `DB_PASSWORD=${pgEnv.POSTGRES_PASSWORD}`,
  'REDIS_HOST=127.0.0.1',
];
writeFileSync(here('test.env'), [
  ...common, 'DB_NAME=peakpass_test', `REDIS_PORT=${port('peakpass-p7-redis-test', 6379)}`, 'NODE_ENV=test', '',
].join('\n'));
// The opt-in of the Redis-outage cases: the owned container by name and by id.
writeFileSync(here('outage.env'), [
  'WAVE3_REDIS_DESTRUCTIVE=1', 'WAVE3_REDIS_CONTAINER=peakpass-p7-redis-test',
  `WAVE3_REDIS_CONTAINER_ID=${docker('inspect', '--format', '{{.Id}}', 'peakpass-p7-redis-test')}`, '',
].join('\n'));
const previous = existsSync(here('browser.env')) ? readFileSync(here('browser.env'), 'utf8') : '';
const keep = (key) => new RegExp(`^${key}=(.+)$`, 'm').exec(previous)?.[1] ?? randomBytes(36).toString('base64url');
writeFileSync(here('browser.env'), [
  ...common, 'DB_NAME=peakpass_browser', `REDIS_PORT=${port('peakpass-p7-redis-browser', 6379)}`,
  `JWT_SECRET=${keep('JWT_SECRET')}`, `API_KEY=${keep('API_KEY')}`,
  `WEBHOOK_SIGNING_SECRET=${keep('WEBHOOK_SIGNING_SECRET')}`, '',
].join('\n'));

for (const name of ['peakpass-p7-redis-test', 'peakpass-p7-redis-browser']) {
  const config = ['save', 'appendonly', 'maxmemory-policy']
    .map((key) => docker('exec', name, 'redis-cli', 'CONFIG', 'GET', key).split('\n').join('='))
    .join(' ');
  console.log(`${name}: port ${port(name, 6379)} ${docker('exec', name, 'redis-cli', 'INFO', 'server').match(/redis_version:\S+/)[0]} ${config}`);
}
console.log(`peakpass-p7-pg: port ${port('peakpass-p7-pg', 5432)} ${psql('SHOW server_version')} track_commit_timestamp=${psql('SHOW track_commit_timestamp')} databases=${psql('SELECT count(*) FROM pg_database WHERE datname LIKE \'peakpass_%\'')}`);
