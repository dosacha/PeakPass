#!/usr/bin/env bash
# Runs every browser scenario of P7 once, in order, and keeps each console output. Prints only
# the lines that carry an outcome. Not part of the source tree. Usage: bash ball.sh
cd /c/Users/dosac/.claude/worktrees/peakpass-issue16/run || exit 1
mkdir -p evidence/browser
for name in b1 b2 b3 b4 b5 b6a b6b b6c b6d b6e b6f b7a b7b b8; do
  bash b.sh "$name" > "evidence/browser/$name.console.txt" 2>&1
  grep -E "^== |^commit |page: |result after|decided by|not decided|after the manual|old (waiting|admitted) admission|redis restarted|application A: |same admission|orders of the user|after the new checkout|after the repeat|after settlement|joined again|switched |same request again|NOT ADMITTED|^summary:|final SQL" \
    "evidence/browser/$name.console.txt" | cut -c1-230
done
echo "all browser scenarios done"
