#!/usr/bin/env bash
# Runs fault suites of P7 against the image built from the worktree and keeps the output and the
# evidence files. Usage: fault.sh <label> <jest arguments...>
. /c/Users/dosac/.claude/worktrees/peakpass-issue16/run/lib.sh
label=$1; shift
mkdir -p "$LOGS" "$RUN/evidence/$label"; cd "$REPO" || exit 1
export ADMISSION_FAULT_IMAGE=${ADMISSION_FAULT_IMAGE:-peakpass:p7-issue16}
export ADMISSION_FAULT_TASK=peakpass-p7-20261004
export ADMISSION_FAULT_EVIDENCE="C:/Users/dosac/.claude/worktrees/peakpass-issue16/run/evidence/$label"
npx --no-install jest --runInBand --config jest.integration.cjs "$@" > "$LOGS/$label.log" 2>&1
code=$?
echo "exit=$code $(grep -E '^(Tests|Test Suites):' "$LOGS/$label.log" | tr '\n' ' ')"
grep -E '^\s+(√|×|✓|✕|○)' "$LOGS/$label.log" | cut -c1-180
# Nothing of this run may stay behind.
docker ps -a --filter label=peakpass.task=peakpass-p7-20261004 --format '{{.Names}}' | grep '^pp-fault-' | sed 's/^/LEFTOVER: /'
exit $code
