// Prints what a saved page trace shows (run peakpass-p7-20261004, taken from the P6 run). Not part of the source tree.
// Usage: node summary.mjs <trace.json>
import { readFileSync } from 'node:fs';

const trace = JSON.parse(readFileSync(process.argv[2], 'utf8'));
const r = (value) => (typeof value === 'number' ? Math.round(value) : value ?? '-');
const events = trace.events;
console.log(`meta ${JSON.stringify(trace.meta)} dropped ${trace.dropped} events ${events.length}`);
for (const e of events) {
  if (e.type === 'poll')
    console.log(
      `poll #${e.seq} ${e.reason} ${e.mode}${e.hidden ? ' hidden' : ''} t=${r(e.tSend)}..${r(e.tRecv)} ` +
        `${e.status}${e.code ? ` ${e.code}` : ''}${e.timedOut ? ' timeout' : ''} ` +
        `${e.state ?? '-'}${e.phase && e.phase !== 'idle' ? `/${e.phase}` : ''} pos=${r(e.position)} next=${r(e.nextPollAfterMs)} ` +
        `planned=${r(e.plannedDelayMs)} actual=${r(e.actualDelayMs)} base=${r(e.baseMs)} u=${typeof e.u === 'number' ? e.u.toFixed(2) : '-'}` +
        `${e.serverMinMs ? ` serverMin=${e.serverMinMs}` : ''}${e.retryAfterMs ? ` retryAfter=${e.retryAfterMs}` : ''}${e.changed ? ' *' : ''}`,
    );
  else if (e.type === 'recognition')
    console.log(
      `RECOGNITION ${e.admissionId.slice(0, 8)} layer=${e.layer} delay=[${r(e.lowerMs)}, ${r(e.upperMs)}] ms ` +
        `serverDelta=${e.serverDeltaMs} roundTrip=${r(e.tRecv - e.tSend)} visibleAtPromotion=${e.visibleAtPromotion} ` +
        `hiddenBetween=${e.hiddenBetween} hiddenAtApply=${e.hiddenAtApply} failuresBefore=${e.failuresBefore} viaRecover=${e.viaRecover} mode=${e.mode}`,
    );
  else if (e.type === 'recognition-missed')
    console.log(`MISSED ${e.admissionId.slice(0, 8)} state=${e.state} serverDelta=${e.serverDeltaMs}`);
  else {
    const { type, t, wall, ...rest } = e;
    console.log(`${type} t=${r(t)} ${JSON.stringify(rest)}`);
  }
}

// One request at a time: every request of the trace starts after the previous one ended.
const spans = events
  .filter((e) => ['poll', 'join', 'cancel', 'purchase'].includes(e.type))
  .map((e) => ({ type: e.type, tSend: e.tSend, tRecv: e.tRecv }))
  .sort((a, b) => a.tSend - b.tSend);
let overlaps = 0;
for (let i = 1; i < spans.length; i += 1) if (spans[i].tSend < spans[i - 1].tRecv) overlaps += 1;
const polls = events.filter((e) => e.type === 'poll');
const by = (key) => Object.entries(polls.reduce((acc, e) => ({ ...acc, [e[key]]: (acc[e[key]] ?? 0) + 1 }), {}));
console.log(
  `summary: requests ${spans.length}, overlapping ${overlaps}, polls ${polls.length} ` +
    `(by reason ${JSON.stringify(Object.fromEntries(by('reason')))}, by status ${JSON.stringify(Object.fromEntries(by('status')))}), ` +
    `joins ${events.filter((e) => e.type === 'join').length}, cancels ${events.filter((e) => e.type === 'cancel').length}, ` +
    `purchase attempts ${events.filter((e) => e.type === 'purchase').length}, recognitions ${events.filter((e) => e.type === 'recognition').length}, ` +
    `missed ${events.filter((e) => e.type === 'recognition-missed').length}`,
);
