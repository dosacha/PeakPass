# Shared helpers of the P7 run. Not part of the source tree. Source it; nothing secret is printed.
RUN=/c/Users/dosac/.claude/worktrees/peakpass-issue16/run
REPO=/c/Users/dosac/.claude/worktrees/peakpass-issue16/PeakPass
LOGS=$RUN/logs

# Exports every KEY=VALUE line of an env file into this shell.
load_env() { set -a; . "$RUN/$1"; set +a; }

# psql inside the owned PostgreSQL container, against the given database.
psqlp() { docker exec peakpass-p7-pg psql -U peakpass -d "$1" -Atc "$2"; }
