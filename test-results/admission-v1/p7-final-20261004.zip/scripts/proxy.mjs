// A local pass-through proxy between the browser and application A (run peakpass-p7-20261004,
// adapted from the proxy of the P6 run). Not part of the source tree.
//
// Flag files in <flagsDir> switch its behaviour; everything else passes unchanged, CORS
// preflights included:
//   lose-reservation | lose-checkout | lose-settlement | lose-join
//       holds a number N: the next N such POSTs are forwarded, their complete upstream answer is
//       read, and the browser's socket is destroyed instead of answering (an answer lost after
//       the server produced it). Chrome repeats a POST once by itself when a reused connection
//       closes without an answer, so losing two is what makes the page's own code see the loss.
//   stall-status
//       while it exists, GET …/admissions/me is neither forwarded nor answered.
// Usage: node proxy.mjs <listenPort> <targetPort> <flagsDir> <logFile>
// The log holds time, method, path, upstream status and the id a purchase answered with.
// No header is logged.
import http from 'node:http';
import { appendFileSync, existsSync, readFileSync, unlinkSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const [listen, target, flags, log] = process.argv.slice(2);
const record = (entry) => appendFileSync(log, `${JSON.stringify({ at: new Date().toISOString(), ...entry })}\n`);
// Takes one loss from a flag file; the file holds how many are left.
const take = (name) => {
  const file = join(flags, name);
  if (!existsSync(file)) return false;
  const left = (Number(readFileSync(file, 'utf8').trim()) || 1) - 1;
  if (left > 0) writeFileSync(file, String(left));
  else unlinkSync(file);
  return true;
};
const kinds = [
  ['reservation', (m, url) => m === 'POST' && url === '/reservations'],
  ['checkout', (m, url) => m === 'POST' && url === '/checkouts'],
  ['settlement', (m, url) => m === 'POST' && url === '/demo/settlement'],
  ['join', (m, url) => m === 'POST' && /^\/events\/[^/]+\/admissions$/.test(url)],
];

http
  .createServer((request, response) => {
    const chunks = [];
    request.on('data', (chunk) => chunks.push(chunk));
    request.on('end', () => {
      if (request.method === 'GET' && request.url.endsWith('/admissions/me') && existsSync(join(flags, 'stall-status'))) {
        const held = Date.now();
        request.socket.once('close', () =>
          record({ method: request.method, path: request.url, held: true, closedByBrowserAfterMs: Date.now() - held }),
        );
        return;
      }
      const kind = kinds.find(([, matches]) => matches(request.method, request.url))?.[0];
      const lose = kind ? take(`lose-${kind}`) : false;
      const upstream = http.request(
        { host: '127.0.0.1', port: target, method: request.method, path: request.url, headers: request.headers },
        (answer) => {
          const parts = [];
          answer.on('data', (part) => parts.push(part));
          answer.on('end', () => {
            const body = Buffer.concat(parts);
            let answered = {};
            try {
              const data = JSON.parse(body.toString('utf8'));
              if (kind === 'reservation') answered = { reservationId: data.id ?? null, code: data.error?.code ?? null };
              if (kind === 'checkout' || kind === 'settlement')
                answered = { orderId: data.order?.id ?? null, orderStatus: data.order?.status ?? null, code: data.error?.code ?? null };
              if (kind === 'join') answered = { admissionId: data.admission?.admissionId ?? null };
            } catch {
              answered = kind ? { unreadable: true } : {};
            }
            record({ method: request.method, path: request.url, upstreamStatus: answer.statusCode, answerLost: lose, ...answered });
            if (lose) {
              request.socket.destroy();
              return;
            }
            response.writeHead(answer.statusCode, answer.headers);
            response.end(body);
          });
        },
      );
      upstream.on('error', () => {
        record({ method: request.method, path: request.url, upstreamStatus: null, answerLost: false });
        response.writeHead(502);
        response.end();
      });
      upstream.end(Buffer.concat(chunks));
    });
  })
  .listen(Number(listen), '127.0.0.1', () => record({ listening: Number(listen), target: Number(target) }));
