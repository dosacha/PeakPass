#!/usr/bin/env bash
# Production image checks of P7 on owned resources. Not part of the source tree.
#  1. production-image-check.mjs on two empty databases, feature off and on
#  2. a database made by the accepted P5 image (migration 013, with rows): the P7 image applies
#     nothing, changes no row, and serves it
#  3. the five Docker order-worker lifecycle cases with the P7 image
# Credentials come from env files and are never printed. Usage: image-check.sh <label>
set -uo pipefail
. /c/Users/dosac/.claude/worktrees/peakpass-issue16/run/lib.sh
label=${1:-image}
IMAGE=peakpass:p7-issue16
P5_IMAGE=peakpass:p5-issue14-review
PG=peakpass-p7-pg
cd "$REPO" || exit 1
load_env test.env
export REDIS_PORT=$(docker port peakpass-p7-redis-browser 6379/tcp | head -1 | sed 's/.*://')
export IMAGE_DB_HOST=host.docker.internal IMAGE_REDIS_HOST=host.docker.internal
sql() { docker exec -i "$PG" psql -U "$DB_USER" -d "$1" -v ON_ERROR_STOP=1 -qAt "${@:2}"; }
fresh() { docker exec "$PG" psql -U "$DB_USER" -d postgres -v ON_ERROR_STOP=1 -qAt -c "DROP DATABASE IF EXISTS $1" -c "CREATE DATABASE $1" >/dev/null; }

echo "image: $(docker image inspect $IMAGE --format '{{.Id}}')" | tee "$LOGS/$label-image-id.txt"
for mode in off on; do
  db=peakpass_image_$mode; fresh $db
  flag=false; [ $mode = on ] && flag=true
  DB_NAME=$db ENABLE_ADMISSION=$flag node --import dotenv/config .github/scripts/production-image-check.mjs $IMAGE > "$LOGS/$label-image-$mode.log" 2>&1
  echo "image check, feature $mode: exit=$? $(grep -o 'PASS:.*' "$LOGS/$label-image-$mode.log")"
done

{
  DB=peakpass_upgrade; fresh $DB
  run_image() { local image=$1; shift
    docker run --rm --env DB_HOST=host.docker.internal --env DB_PORT --env DB_USER --env DB_PASSWORD \
      --env DB_NAME=$DB --env REDIS_HOST=host.docker.internal --env REDIS_PORT --env LOG_LEVEL=info \
      --env ENABLE_ADMISSION=false "$image" "$@"; }
  counts() { sql $DB -c "SELECT 'users='||(SELECT count(*) FROM users)||' events='||(SELECT count(*) FROM events)
    ||' reservations='||(SELECT count(*) FROM reservations)||' orders='||(SELECT count(*) FROM orders)
    ||' payment_records='||(SELECT count(*) FROM payment_records)||' admission_events='||(SELECT count(*) FROM admission_events)
    ||' admission_results='||(SELECT count(*) FROM admission_results)
    ||' seats='||(SELECT string_agg(available_seats::text||'/'||total_seats::text, ',' ORDER BY name) FROM events)"; }
  echo "== 1. fresh database, migrated by the accepted P5 image ($P5_IMAGE)"
  run_image "$P5_IMAGE" node dist/infra/migrations/runner.js up | grep -o 'All migrations complete. Total new: [0-9]*'
  echo "versions: $(sql $DB -c "SELECT string_agg(version::text, ',' ORDER BY version) FROM migrations")"
  echo "== 2. rows written at the 013 level (direct SQL fixture)"
  sql $DB <<'SQL'
INSERT INTO users(id,email) VALUES ('11111111-1111-4111-8111-111111111111','upgrade@p7.test');
INSERT INTO events(id,name,starts_at,ends_at,total_seats,available_seats,pricing,status) VALUES
 ('22222222-2222-4222-8222-222222222222','existing with policy',NOW()+interval '1 hour',NOW()+interval '2 hours',10,6,
  '[{"id":"general","name":"General","price":50,"quantity":10}]','published'),
 ('33333333-3333-4333-8333-333333333333','existing without policy',NOW()+interval '1 hour',NOW()+interval '2 hours',5,5,
  '[{"id":"general","name":"General","price":50,"quantity":5}]','published');
INSERT INTO admission_events(event_id,redis_namespace)
 VALUES ('22222222-2222-4222-8222-222222222222','peakpass:admission:22222222-2222-4222-8222-222222222222:');
INSERT INTO reservations(id,user_id,event_id,quantity,tier_id,expires_at) VALUES
 ('44444444-4444-4444-8444-444444444444','11111111-1111-4111-8111-111111111111','22222222-2222-4222-8222-222222222222',1,'general',NOW()+interval '5 minutes'),
 ('99999999-9999-4999-8999-999999999999','11111111-1111-4111-8111-111111111111','22222222-2222-4222-8222-222222222222',1,'general',NOW()+interval '5 minutes');
INSERT INTO orders(id,user_id,event_id,quantity,tier_id,unit_price,total_amount,idempotency_key,payment_deadline_at)
 VALUES ('55555555-5555-4555-8555-555555555555','11111111-1111-4111-8111-111111111111',
  '22222222-2222-4222-8222-222222222222',2,'general',50,100,'66666666-6666-4666-8666-666666666666',NOW()+interval '10 minutes');
INSERT INTO payment_records(id,order_id,status,idempotency_key)
 VALUES ('77777777-7777-4777-8777-777777777777','55555555-5555-4555-8555-555555555555','pending','66666666-6666-4666-8666-666666666666');
INSERT INTO admission_results(admission_id,user_id,event_id,epoch,operation,fingerprint,outcome,reservation_id)
 VALUES ('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','11111111-1111-4111-8111-111111111111','22222222-2222-4222-8222-222222222222',
  'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb','reservation',
  '["11111111-1111-4111-8111-111111111111","22222222-2222-4222-8222-222222222222","bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb","reservation","general",1,null]',
  'consumed','99999999-9999-4999-8999-999999999999');
SQL
  BEFORE=$(counts); echo "before: $BEFORE"
  echo "== 3. the P7 image applies nothing, twice"
  run_image "$IMAGE" node dist/infra/migrations/runner.js up | grep -o 'All migrations complete. Total new: [0-9]*'
  run_image "$IMAGE" node dist/infra/migrations/runner.js up | grep -o 'All migrations complete. Total new: [0-9]*'
  echo "versions: $(sql $DB -c "SELECT string_agg(version::text, ',' ORDER BY version) FROM migrations")"
  AFTER=$(counts); echo "after:  $AFTER"
  [ "$BEFORE" = "$AFTER" ] && echo "rows unchanged" || echo "ROWS CHANGED"
  echo "== 4. the P7 image serves it: ready, an existing-reservation checkout, a new reservation"
  CID=$(docker run --detach --rm --label peakpass.task=peakpass-p7-20261004 --publish 127.0.0.1::3000 \
    --env DB_HOST=host.docker.internal --env DB_PORT --env DB_USER --env DB_PASSWORD --env DB_NAME=$DB \
    --env REDIS_HOST=host.docker.internal --env REDIS_PORT --env LOG_LEVEL=error --env ENABLE_ADMISSION=false "$IMAGE")
  PORT=$(docker port "$CID" 3000/tcp | sed 's/.*://')
  BASE="http://127.0.0.1:$PORT" node "$RUN/image-serve.mjs"; echo "serve exit=$?"
  docker stop "$CID" >/dev/null 2>&1
  echo "final:  $(counts)"
} > "$LOGS/$label-existing-db.log" 2>&1
echo "existing database: $(grep -c 'Total new: 0' "$LOGS/$label-existing-db.log") runs applied nothing; $(grep -E 'rows unchanged|ROWS CHANGED|serve exit' "$LOGS/$label-existing-db.log" | tr '\n' ' ')"

load_env test.env
WAVE4_TEST_IMAGE=$IMAGE npx --no-install jest --runInBand --verbose --config jest.integration.cjs src/tests/integration/order-sweeper-docker.test.ts > "$LOGS/$label-docker-lifecycle.log" 2>&1
echo "docker lifecycle: exit=$? $(grep -E '^Tests:' "$LOGS/$label-docker-lifecycle.log")"
docker ps -a --filter label=peakpass.task=wave4 --format 'LEFTOVER wave4: {{.Names}}'
