# Builds the evidence archive of P7 and its manifest (run peakpass-p7-20261004). Not part of the
# source tree. Usage: python pack.py <resultsJson>
#   <resultsJson>  a JSON file with the "results" and "review" objects of the manifest
# It stages the files, refuses to continue when a staged file holds a value of an env file or a
# token-like string, writes the ZIP with fixed timestamps and prints the manifest path.
import hashlib, io, json, os, re, shutil, sys, zipfile

RUN = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.join(os.path.dirname(RUN), 'PeakPass')
NAME = 'p7-final-20261004'
STAGE = os.path.join(RUN, 'archive', NAME)
OUT = os.path.join(REPO, 'test-results', 'admission-v1')

def copy(src, dst):
    os.makedirs(os.path.dirname(os.path.join(STAGE, dst)), exist_ok=True)
    shutil.copyfile(os.path.join(RUN, src), os.path.join(STAGE, dst))

if os.path.isdir(STAGE):
    shutil.rmtree(STAGE)
os.makedirs(STAGE)

logs = os.path.join(RUN, 'logs')
for name in sorted(os.listdir(logs)):
    # The logs of the browser applications and of the static server are large and add nothing
    # to the extracts kept per scenario.
    if name.startswith('browser-app-') or name in ('browser-static.log', 'browser-proxy.out', 'npm-ci.log', 'agent-browser-core.txt'):
        continue
    if name.endswith('-build.log') and name.startswith('mut-'):
        continue
    # Of the regressions before the F1 fix and on its two earlier forms and of the two stopped
    # starts the progress files and the fault suites are kept; their copies of the unchanged
    # commands are not.
    if name.startswith(('stopped-', 'prefix-', 'f1a-', 'f1b-')) and not (name.endswith('.txt') or re.search(r'-(r\d-\w+|redis-again-\d)\.log$', name)):
        continue
    copy(os.path.join('logs', name), os.path.join('logs', name))

evidence = os.path.join(RUN, 'evidence')
for folder in sorted(os.listdir(evidence)):
    for name in sorted(os.listdir(os.path.join(evidence, folder))):
        # Application logs of the fault topologies stay in the run directory.
        if re.search(r'-app\d+\.log$', name):
            continue
        if folder in ('browser-pre-f1', 'browser-f1a', 'browser-f1b'):
            # The earlier passes of the browser scenarios, on the image before the fix and on the
            # images of its two earlier forms: consoles only.
            if name.endswith('.console.txt'):
                copy(os.path.join('evidence', folder, name), os.path.join(folder, name))
            continue
        # The request lists and the transition logs are kept for the three final rounds; of every
        # other run the notes are enough to see what it did and observed.
        if folder != 'browser' and not folder.startswith('final-r') and not name.endswith('-notes.jsonl'):
            continue
        copy(os.path.join('evidence', folder, name), os.path.join('browser' if folder == 'browser' else os.path.join('fault', folder), name))

for name in ['b.sh', 'ball.sh', 'blib.sh', 'proxy.mjs', 'fillers.mjs', 'as-user.mjs', 'protect.ts', 'summary.mjs', 'applog.mjs',
             'browser-env.sh', 'fault.sh', 'suite.sh', 'final.sh', 'image-check.sh', 'image-serve.mjs', 'setup.mjs',
             'lib.sh', 'rounds.mjs', 'obs.mjs', 'tick.mjs', 'chain.sh', 'pack.py']:
    copy(name, os.path.join('scripts', name))

with io.open(os.path.join(RUN, 'README.archive.txt'), encoding='utf-8') as source:
    readme = source.read()
with io.open(os.path.join(STAGE, 'README.txt'), 'w', encoding='utf-8', newline='\n') as target:
    target.write(readme)

# Nothing secret may be staged: no value of an env file, no token, no request header.
secrets = set()
for name in os.listdir(RUN):
    if not name.endswith('.env'):
        continue
    for line in io.open(os.path.join(RUN, name), encoding='utf-8'):
        key, _, value = line.strip().partition('=')
        if re.search(r'SECRET|PASSWORD|KEY|TOKEN', key) and len(value) >= 8:
            secrets.add(value)
patterns = [re.compile(rb'eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}'), re.compile(rb'Bearer [A-Za-z0-9]'),
            re.compile(rb'(?i)"authori' rb'zation"')]  # split so that this file does not match itself
bad = []
files = []
for root, _, names in os.walk(STAGE):
    for name in names:
        path = os.path.join(root, name)
        data = open(path, 'rb').read()
        rel = os.path.relpath(path, STAGE).replace('\\', '/')
        if any(value.encode() in data for value in secrets) or any(p.search(data) for p in patterns):
            bad.append(rel)
        files.append((rel, data))
if bad:
    print('REFUSED: secret-like content in', bad)
    sys.exit(1)
files.sort()

os.makedirs(OUT, exist_ok=True)
archive = os.path.join(OUT, NAME + '.zip')
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for rel, data in files:
        info = zipfile.ZipInfo(rel, date_time=(2026, 10, 4, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        z.writestr(info, data)
digest = hashlib.sha256(open(archive, 'rb').read()).hexdigest()

extra = json.load(io.open(sys.argv[1], encoding='utf-8'))
manifest = {
    'runId': 'peakpass-p7-20261004',
    **extra,
    'archive': NAME + '.zip',
    'archiveSha256': digest,
    'files': [{'name': rel, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for rel, data in files],
}
with io.open(os.path.join(OUT, NAME + '.json'), 'w', encoding='utf-8', newline='\n') as target:
    json.dump(manifest, target, ensure_ascii=False, indent=2)
    target.write('\n')
print('files', len(files), 'env values checked', len(secrets), 'zip bytes', os.path.getsize(archive), 'sha256', digest)
