// Aggregates the notes of the three final rounds into the few numbers the validation document
// states. Not part of the source tree. Usage: node obs.mjs <label>
import { readFileSync } from 'node:fs';

const label = process.argv[2] ?? 'final';
const notes = (suite) =>
  [1, 2, 3].flatMap((round) =>
    readFileSync(`evidence/${label}-r${round}-${suite}/${suite}-notes.jsonl`, 'utf8')
      .trim()
      .split('\n')
      .map((line) => ({ round, ...JSON.parse(line) })),
  );
const range = (values) => `${Math.min(...values)}..${Math.max(...values)}`;
const of = (all, what) => all.filter((note) => note.what === what);
const redis = notes('redis');
const process_ = notes('process');
const flows = notes('flows');

const paused = of(redis, 'R1 answers while Redis is paused');
console.log('R1 paused ms', range(paused.flatMap((n) => [n.status.ms, n.join.ms, n.purchase.ms, n.exempt.ms, n.ready.ms])), 'health', range(paused.map((n) => n.health.ms)));
const stopped = of(redis, 'R2 answers while Redis is stopped');
console.log('R2 stopped ms', range(stopped.flatMap((n) => [n.status.ms, n.purchase.ms, n.exempt.ms, n.ready.ms])));
const r6 = of(redis, 'R6 round');
console.log('R6 pause', range(r6.map((n) => n.pause)), 'delay', range(r6.map((n) => n.delay)), 'generations', r6.map((n) => n.generation).join(','));
const m2 = of(process_, 'M2 round');
console.log('M2 reservation won', m2.filter((n) => n.reservation.status === 201).length, 'of', m2.length);
const promo = of(process_, 'M3 cancel against promotion');
for (const delay of [0, 120, 260, 400])
  console.log('M3 promotion delay', delay, 'promoted first', promo.filter((n) => n.delayMs === delay && n.promotedBeforeCancel).length, 'of', promo.filter((n) => n.delayMs === delay).length);
const claim = of(process_, 'M3 cancel against claim');
for (const after of [0, 4, 8, 12, 18, 30])
  console.log('M3 claim cancelAfter', after, claim.filter((n) => n.cancelAfterMs === after).map((n) => `${n.purchase.status}/${n.cancel.status}${n.cancel.code ? ' ' + n.cancel.code : ''}`).join(' | '));
for (const note of of(process_, 'M4'))
  console.log('M4 r' + note.round, note.outcomes.map((o) => `${o.offsetMs}:${o.status}${o.attempts > 1 ? '(' + o.attempts + ')' : ''}`).join(' '));
for (const note of of(process_, 'K1 the same request on the other instance'))
  console.log('K1 r' + note.round, note.attempts.map((a) => `${a.status}@${a.ms}`).join(' '));
console.log('K2 afterDeadlineMs', of(process_, 'K2 closed').map((n) => n.afterDeadlineMs).join(','));
console.log('K4 ms', of(process_, 'K4 the resumed writer').map((n) => `${n.status}@${n.ms}`).join(','));
console.log('K5 s', of(process_, 'K5 client that closes its connection').map((n) => n.secondsToExit).join(','), 'K5b s', of(process_, 'K5b keep-alive client').map((n) => n.secondsToExit).join(','));
console.log('T1 ms', of(process_, 'T1').map((n) => `${n.status}@${n.ms}`).join(','));
for (const kind of ['restart', 'crash']) {
  const t2 = of(process_, `T2 ${kind}`);
  console.log('T2', kind, 'inflight', range(t2.map((n) => n.inflight.ms)), 'status', range(t2.map((n) => n.status.ms)), 'purchase', range(t2.map((n) => n.purchase.ms)));
}
console.log('T3', of(process_, 'T3 first answers of eight simultaneous purchases').map((n) => `201x${n['201'] ?? 0} 503x${n['503 ADMISSION_UNAVAILABLE'] ?? 0}`).join(' | '));
for (const note of of(flows, 'L1 answers'))
  console.log('L1 r' + note.round, JSON.stringify(note.seen));
const l3 = of(flows, 'L3 purchase against deletion').flatMap((n) => n.rounds);
console.log('L3 deleted first', l3.filter((r) => r.deletion === 'deleted').length, 'of', l3.length, 'purchase statuses', [...new Set(l3.map((r) => r.purchase.status))].join(','));
for (const note of of(flows, 'L4 deadline against settlement'))
  console.log('L4 r' + note.round, note.outcomes.map((o) => `${o.offsetMs}:${o.status}`).join(' '));
