#!/usr/bin/env bash
# Browser environment of P7 (run peakpass-p7-20261004). Not part of the source tree.
# Two containers of the production image share the owned browser database and its Redis and differ
# only in the demo user. The page is served by a static server and reaches application A through
# a local proxy, so that answers can be lost or held between browser and application.
#   browser-env.sh up     create the network, migrate and seed, start both applications
#   browser-env.sh serve  start the static server and the proxy (host processes)
#   browser-env.sh down   remove the two application containers and stop the host processes
# Nothing secret is printed; values travel through the environment of the docker CLI.
set -u
. /c/Users/dosac/.claude/worktrees/peakpass-issue16/run/lib.sh
NET=peakpass-p7-browser
IMAGE=${IMAGE:-peakpass:p7-issue16}
LABEL=peakpass.task=peakpass-p7-20261004
PORTS=$RUN/browser-ports.env
free_port() { node -e "const s=require('net').createServer();s.listen(0,'127.0.0.1',()=>{console.log(s.address().port);s.close()})"; }
app() { # name, host port, demo user email
  docker run -d --name "$1" --network $NET --label $LABEL -p "127.0.0.1:$2:3000" \
    --env NODE_ENV=production --env PORT=3000 --env LOG_LEVEL=info \
    --env DB_HOST=pg --env DB_PORT=5432 --env DB_USER --env DB_PASSWORD --env DB_NAME=peakpass_browser \
    --env REDIS_HOST=redis --env REDIS_PORT=6379 --env JWT_SECRET --env API_KEY --env WEBHOOK_SIGNING_SECRET \
    --env ENFORCE_AUTH_USER_MATCH=true --env ENABLE_RATE_LIMITING=true --env RATE_LIMIT_FAIL_MODE=closed \
    --env ENABLE_ADMISSION=${ENABLE_ADMISSION:-true} --env ENABLE_DEMO_SESSION=true --env "DEMO_USER_EMAIL=$3" \
    ${EXTRA_ENV:-} "$IMAGE" > /dev/null
}
wait_ready() { for _ in $(seq 1 80); do [ "$(curl -s -o /dev/null -w '%{http_code}' "http://127.0.0.1:$1/ready" || true)" = "200" ] && return 0; node -e "setTimeout(()=>{},300)"; done; return 1; }

case "${1:-}" in
  up)
    load_env browser.env
    docker network inspect $NET > /dev/null 2>&1 || docker network create --label $LABEL $NET > /dev/null
    docker network connect --alias pg $NET peakpass-p7-pg 2>/dev/null
    docker network connect --alias redis $NET peakpass-p7-redis-browser 2>/dev/null
    docker run --rm --network $NET --env DB_HOST=pg --env DB_PORT=5432 --env DB_USER --env DB_PASSWORD \
      --env DB_NAME=peakpass_browser --env REDIS_HOST=redis --env REDIS_PORT=6379 "$IMAGE" \
      node dist/infra/migrations/runner.js up | grep -o 'All migrations complete. Total new: [0-9]*'
    ( cd "$REPO" && DB_NAME=peakpass_browser npx --no-install tsx src/infra/seed.ts > "$LOGS/browser-seed.log" 2>&1; echo "seed exit=$?" )
    [ -f "$PORTS" ] || printf 'API_A_PORT=%s\nAPI_B_PORT=%s\nFRONT_PORT=%s\nPROXY_PORT=%s\n' "$(free_port)" "$(free_port)" "$(free_port)" "$(free_port)" > "$PORTS"
    . "$PORTS"
    docker rm -f peakpass-p7-app-a peakpass-p7-app-b > /dev/null 2>&1
    app peakpass-p7-app-a "$API_A_PORT" user1@example.com
    app peakpass-p7-app-b "$API_B_PORT" user2@example.com
    wait_ready "$API_A_PORT" && wait_ready "$API_B_PORT" && echo "applications ready on $API_A_PORT and $API_B_PORT" || echo "NOT READY"
    ;;
  serve)
    . "$PORTS"
    ( cd "$REPO/frontend" && python -m http.server "$FRONT_PORT" --bind 127.0.0.1 > "$LOGS/browser-static.log" 2>&1 & ) > /dev/null 2>&1
    mkdir -p "$RUN/flags"
    ( cd "$RUN" && node proxy.mjs "$PROXY_PORT" "$API_A_PORT" flags "$LOGS/browser-proxy.log" > "$LOGS/browser-proxy.out" 2>&1 & ) > /dev/null 2>&1
    node -e "setTimeout(()=>{},1500)"
    echo "static $(curl -s -o /dev/null -w '%{http_code}' "http://127.0.0.1:$FRONT_PORT/index.html") proxy $(curl -s -o /dev/null -w '%{http_code}' "http://127.0.0.1:$PROXY_PORT/health")"
    ;;
  down)
    . "$PORTS" 2>/dev/null
    docker rm -f peakpass-p7-app-a peakpass-p7-app-b > /dev/null 2>&1
    for port in ${FRONT_PORT:-} ${PROXY_PORT:-}; do
      pid=$(netstat -ano | grep -E "TCP +127\.0\.0\.1:$port .*LISTENING" | awk '{print $NF}' | head -1)
      [ -n "$pid" ] && taskkill //PID "$pid" //T //F > /dev/null 2>&1 && echo "stopped the process on $port"
    done
    ;;
  *) echo "usage: browser-env.sh up|serve|down"; exit 2 ;;
esac
