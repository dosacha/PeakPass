#!/usr/bin/env bash
# Final regression of P7 on the owned resources (run peakpass-p7-20261004). Not part of the source
# tree. Every output is kept under logs/<label>-*.log and the progress lines go to logs/<label>.txt.
# Usage: final.sh <label> [rounds]
. /c/Users/dosac/.claude/worktrees/peakpass-issue16/run/lib.sh
label=${1:-final}; rounds=${2:-3}
out=$LOGS/$label.txt; : > "$out"
say() { echo "$(date -u +%H:%M:%S) $*" | tee -a "$out"; }
cd "$REPO" || exit 1
say "commit $(git rev-parse HEAD), tree $(git status --short | wc -l) changed files, image $(docker image inspect peakpass:p7-issue16 --format '{{.Id}}')"

# 1. the commands of the validation documents, without any opt-in
bash "$RUN/suite.sh" "$label" all 2>&1 | while read -r line; do say "$line"; done

# 2. the ten Redis-outage cases on the owned Redis (they stop and start it)
( load_env test.env; load_env outage.env
  npx --no-install jest --runInBand --config jest.integration.cjs \
    src/tests/integration/redis-recovery.test.ts src/tests/integration/order-expiration-http.test.ts \
    src/tests/integration/order-sweeper.test.ts > "$LOGS/$label-outage.log" 2>&1
  echo "outage opt-in: exit=$? $(grep -E '^(Tests|Test Suites):' "$LOGS/$label-outage.log" | tr '\n' ' ')" ) | while read -r line; do say "$line"; done

# 3. the five Docker order-worker lifecycle cases with the image
( load_env test.env
  WAVE4_TEST_IMAGE=peakpass:p7-issue16 npx --no-install jest --runInBand --config jest.integration.cjs \
    src/tests/integration/order-sweeper-docker.test.ts > "$LOGS/$label-docker-lifecycle.log" 2>&1
  echo "docker lifecycle opt-in: exit=$? $(grep -E '^(Tests|Test Suites):' "$LOGS/$label-docker-lifecycle.log" | tr '\n' ' ')"
  docker ps -a --filter label=peakpass.task=wave4 --format 'LEFTOVER wave4: {{.Names}}' ) | while read -r line; do say "$line"; done

# 4. the fault suites, several rounds in a row
for round in $(seq 1 "$rounds"); do
  for suite in redis process flows; do
    bash "$RUN/fault.sh" "$label-r$round-$suite" "src/tests/integration/admission-fault-$suite.test.ts" 2>&1 \
      | grep -E '^exit=|×|✕|LEFTOVER' | while read -r line; do say "round $round $suite: $line"; done
  done
done
say "done"
