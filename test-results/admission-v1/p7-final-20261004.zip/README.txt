Evidence of P7 / Issue #16 (run peakpass-p7-20261004)
======================================================

What this archive holds. Nothing in it is a performance result: every duration and count is an
observation of a local run on one Windows host shared with other work.

logs/
  base-*.log            the commands of the validation documents at the base, before any change
  red-*.log, green-*.log  each new check failing first and then passing (the replay, the final SQL,
                        the guard of the ten Redis-outage cases, the run-id rule, the cleanup of a
                        topology that cannot start, the Redis suite after the fix of F1, the
                        lifecycle tests and the stricter checks after each auto-review)
  final.txt             the progress lines of the final regression at d24f98a, the commit that
                        completes the F1 fix: commit, image id, each command
  chain.txt             the order of the last re-verification: image checks, browser, regression
  final-*.log           its outputs: build, typecheck, lint, unit, migrate, integration, harness,
                        callback, the Redis-outage opt-in, the Docker lifecycle opt-in, and one
                        log per fault suite and round (final-r<round>-<suite>.log)
  prefix-164c60b*       the same regression before the fix of F1: its progress file and its fault
                        suites, where R2 and R3 fail on F1 in each of the three rounds
  f1a-92e1250*          the same regression on the first form of the fix: all green; the
                        auto-review of the PR then found what red-6-recover.log shows
  f1b-e617e0e*          the same regression on the second form of the fix: its progress files and
                        its fault suites, where R5 fails once on the scenario's own assumption;
                        f1b-e617e0e-redis-again-* is the Redis suite three more times at 62b998b,
                        after R5 was corrected; the auto-review then found what red-7-*.log shows
  stopped-<commit>*     two earlier starts of the final regression that were stopped to change
                        test code: their progress file and the fault suites they had reached
  mut-*.log             the six sensitivity runs: the named scenario failing on a throwaway image
                        built from one changed product branch
  image-*.log           the production image checks: before the fix (image-*), on its first
                        form (image-f1-*), on its second form (image-f1b-*) and on the final
                        image (image-f1c-*)
  other *.log           earlier runs of single scenarios during the work, kept as they are,
                        including runs that failed for a reason the plan's ledger explains

fault/<label>/          what a fault suite wrote for one run:
  <suite>-notes.jsonl        the faults it applied and what it observed, with times
  <suite>-requests.jsonl     every request it sent: user id, instance, method, path, status, code,
                             duration. No header and no token.
  <suite>-transitions.log    the Redis MONITOR lines of every admission command, as captured
  The request lists and the transition logs are kept for the three final rounds (final-r1..r3);
  of every other run only the notes are kept. The application logs of the fault topologies are
  not in the archive.

browser/                the browser scenarios on the final image, one set per scenario
                        b1..b8 (b6 and b7 have several cases):
  <name>.console.txt    the output of the scenario script
  <name>.trace.json     the page's own trace (window.PeakPassAdmissionTrace.snapshot())
  <name>.requests.txt   the browser's request list: method, URL and status only
  <name>.applog.json    counts from the applications' request logs for the same window
  <name>.fillers.log    the synthetic waiting users, where used
browser-pre-f1/         the consoles of the earlier pass of the same scenarios, before the fix
browser-f1a/            the consoles of the pass on the first form of the fix
browser-f1b/            the consoles of the pass on the second form of the fix

scripts/                the scripts of the run. They are not part of the source tree, name paths
                        of this host, and read their credentials from env files that are not in
                        the archive.

Evidence kinds: see docs/ISSUE_16_VALIDATION.md. Real: containers of the production image, real
container faults and timers, headless Chrome. Synthetic stimulus: SQL users, a pg_sleep trigger,
a held gate, SQL transitions and seat counts, requests sent by a script. Injected: the proxy's
lost or held answers.

No credential, env file, token or request header is in this archive; pack.py refuses to build it
when a staged file contains a value of an env file or a token-like string.
