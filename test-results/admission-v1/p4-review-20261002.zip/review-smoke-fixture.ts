// Disposable two-process smoke for the PR #24 review follow-up. Not part of the repository.
// This process plays the operator/coordinator: it protects an event, opens its queue and later
// releases protection under the exclusive gate. It never calls maintain()/recover() after the
// release, so the retirement observed over HTTP must come from the separately started app's
// real scheduler.
import 'dotenv/config';
import { randomUUID } from 'crypto';
import jwt from 'jsonwebtoken';
import { initLogger } from '@/infra/logger';
import { getConfig } from '@/infra/config';
import { initRedis, closeRedis } from '@/infra/redis/client';
import {
  initPostgresPool,
  closePostgresPool,
  serializableTransactionWithRetry,
} from '@/infra/postgres/client';
import { readAdmissionPolicy, policyColumns } from '@/infra/postgres/admission-policy';
import { AdmissionService } from '@/core/services/admission.service';

const base = process.env.SMOKE_BASE!;
const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

async function main() {
  initLogger();
  const pool = await initPostgresPool();
  const redis = await initRedis();
  const eventId = randomUUID(),
    userId = randomUUID();
  const authorization = `Bearer ${jwt.sign({ sub: userId }, getConfig().JWT_SECRET)}`;
  const call = async (path: string, method = 'GET', body?: unknown) => {
    const response = await fetch(base + path, {
      method,
      headers: { authorization, 'content-type': 'application/json' },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    });
    return { status: response.status, body: (await response.json()) as Record<string, any> };
  };
  const setProtected = (value: boolean) =>
    serializableTransactionWithRetry(async (c) => {
      await readAdmissionPolicy(c, eventId, 'exclusive');
      await c.query('UPDATE admission_events SET protected=$2 WHERE event_id=$1', [eventId, value]);
    });
  const policy = async () =>
    (await pool.query(`SELECT ${policyColumns} FROM admission_events WHERE event_id=$1`, [eventId]))
      .rows[0];
  const summary: Record<string, unknown> = { eventId };
  try {
    await pool.query(
      `INSERT INTO events(id,name,starts_at,ends_at,total_seats,available_seats)
      VALUES($1,'pr24 smoke',NOW(),NOW()+interval '1 day',10,10)`,
      [eventId],
    );
    summary.readyBefore = (await fetch(base + '/ready')).status;
    summary.unprotectedBefore = (await call(`/events/${eventId}/admissions/me`)).body.error?.code;

    await setProtected(true);
    const service = new AdmissionService(true);
    await service.verifyEnvironment();
    await service.recover(eventId);
    const opened = (await service.control(eventId))!;
    summary.opened = { mode: opened.mode, generation: opened.generation };

    const status = await call(`/events/${eventId}/admissions/me`);
    const join = await call(`/events/${eventId}/admissions`, 'POST', {
      epoch: status.body.queue?.epoch,
      joinRequestId: randomUUID(),
    });
    summary.servedWhileProtected = { get: status.status, join: join.status };
    // The other process's scheduler tick, not this process, must promote the entry.
    let state = '';
    for (let i = 0; i < 150 && state !== 'admitted'; i++) {
      await sleep(20);
      state = (await call(`/events/${eventId}/admissions/me`)).body.admission?.state;
    }
    summary.promotedByAppScheduler = state;

    await setProtected(false);
    const released = Date.now();
    const seen: Record<string, number> = {};
    let last = { status: 0, body: {} as Record<string, any> };
    for (let i = 0; i < 250; i++) {
      last = await call(`/events/${eventId}/admissions/me`);
      seen[last.status] = (seen[last.status] ?? 0) + 1;
      if (last.status === 404) break;
      await sleep(20);
    }
    summary.afterRelease = {
      finalStatus: last.status,
      code: last.body.error?.code,
      elapsedMs: Date.now() - released,
      statusesSeen: seen,
    };
    summary.control = await service.control(eventId);
    summary.epochKeysLeft = (
      await redis.keys(`peakpass:admission:${eventId}:${opened.epoch}:*`)
    ).length;
    const retired = await policy();
    summary.policy = {
      protected: retired.protected,
      phase: retired.phase,
      generation: retired.generation,
      epochChanged: retired.epoch !== opened.epoch,
    };
    summary.ok =
      status.status === 200 &&
      join.status === 201 &&
      state === 'admitted' &&
      last.status === 404 &&
      last.body.error?.code === 'ADMISSION_NOT_ENABLED' &&
      summary.control === null &&
      summary.epochKeysLeft === 0 &&
      retired.protected === false &&
      retired.phase === 'recovering' &&
      BigInt(retired.generation) === BigInt(opened.generation) + 1n;
  } finally {
    await pool.query('DELETE FROM events WHERE id=$1', [eventId]);
    const keys = await redis.keys(`peakpass:admission:${eventId}:*`);
    if (keys.length) await redis.del(keys);
    summary.readyAfter = (await fetch(base + '/ready')).status;
    await closeRedis();
    await closePostgresPool();
  }
  process.stdout.write('\nSMOKE ' + JSON.stringify(summary) + '\n');
  process.exit(summary.ok ? 0 : 1);
}
void main().catch((error) => {
  process.stdout.write('\nSMOKE-ERROR ' + String(error?.stack ?? error) + '\n');
  process.exit(1);
});
