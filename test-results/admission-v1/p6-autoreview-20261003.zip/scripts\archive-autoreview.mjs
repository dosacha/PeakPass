// Builds the evidence archive of the first GitHub Codex auto-review of PR #28 (run
// peakpass-p6-20261003). Not part of the source tree. Run from the run directory:
//   node archive-autoreview.mjs <codeSha>
// The earlier archives (p6-final, p6-review, p6-review2 of 20261003) stay as they are.
import { createHash } from 'node:crypto';
import { cpSync, mkdirSync, readFileSync, readdirSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { execFileSync, spawnSync } from 'node:child_process';
import { join, relative, sep } from 'node:path';

const codeSha = process.argv[2];
if (!/^[0-9a-f]{40}$/.test(codeSha ?? '')) throw new Error('usage: node archive-autoreview.mjs <codeSha>');
const RUN = process.cwd();
const REPO = join(RUN, '..', 'PeakPass');
const NAME = 'p6-autoreview-20261003';
const stage = join(RUN, 'archive', NAME);
const out = join(REPO, 'test-results', 'admission-v1');
const posix = (path) => path.split(sep).join('/');
const walk = (dir) =>
  readdirSync(dir).flatMap((name) => {
    const path = join(dir, name);
    return statSync(path).isDirectory() ? walk(path) : [path];
  });

// The auto-review checks (s23, s24, with their runs before the change), the final check on the
// new code, and the CI and review records of the PR.
const EV = join(RUN, 'evidence');
const evidence = readdirSync(EV).filter((name) =>
  /^(s23-|s24-|review4\.proxy\.log$|final\.console\.log$|final-f[12][abc]?\.|a11y-(waiting|waiting-confirm|admitted|finished|page)\.json$)/.test(name),
);
rmSync(stage, { recursive: true, force: true });
mkdirSync(join(stage, 'evidence'), { recursive: true });
for (const name of evidence) cpSync(join(EV, name), join(stage, 'evidence', name), { recursive: true });

const traces = walk(join(stage, 'evidence')).filter((file) => file.endsWith('.trace.json')).sort();
mkdirSync(join(stage, 'logs'));
writeFileSync(
  join(stage, 'logs', 'summaries.txt'),
  traces
    .map((file) => `=== ${posix(relative(stage, file))}\n${spawnSync(process.execPath, [join(RUN, 'summary.mjs'), file], { encoding: 'utf8' }).stdout}`)
    .join(''),
);
for (const name of readdirSync(join(RUN, 'logs')).filter((n) => /^(ar1-|pr28-)/.test(n))) cpSync(join(RUN, 'logs', name), join(stage, 'logs', name));
mkdirSync(join(stage, 'scripts'));
for (const name of ['review4.sh', 'proxy.mjs', 'helpers.sh', 'lib.sh', 'final.sh', 'summary.mjs', 'applog.mjs', 'app.sh', 'archive-autoreview.mjs'])
  cpSync(join(RUN, name), join(stage, 'scripts', name));
writeFileSync(
  join(stage, 'README.txt'),
  [
    `Evidence of the first GitHub Codex auto-review of PR #28, run peakpass-p6-20261003, code ${codeSha}.`,
    'p6-final-20261003.zip holds the evidence up to code 02ee7e0, p6-review-20261003.zip and p6-review2-20261003.zip',
    'the two rounds of the external static review (codes b9656ab and fc0f4a8).',
    '',
    'evidence/  s23-* a reservation read answered after Reset; s24-* a status request answered 401 and repeated',
    '           with a new demo session. *-before.* ran on 6645a29 before the change, the others after it.',
    '           review4.proxy.log: the proxy of these runs. final.console.log, final-f*, a11y-*.json: the final',
    '           check on the new code.',
    'logs/      the regression on the new code (ar1-*), the CI checks and the review records of PR #28 as',
    '           read from GitHub (pr28-*), and summaries.txt (every trace as text).',
    'scripts/   the scripts used for these runs; not part of the source tree; no env file.',
    '',
  ].join('\n'),
);

const suspicious = [
  /eyJ[A-Za-z0-9_-]{10,}/,
  /Bearer [A-Za-z0-9._-]{12,}/,
  /:\/\/[^/\s:@]+:[^@\s/]+@/,
  /(JWT_SECRET|DB_PASSWORD|POSTGRES_PASSWORD|REDIS_PASSWORD)=[A-Za-z0-9_\-+/]{8,}/,
];
const staged = walk(stage).sort();
// The proxy injects one deliberately invalid token; that literal is not a credential.
const hits = staged.filter((file) => {
  const text = readFileSync(file, 'utf8').replaceAll('Bearer invalid-for-the-check', '');
  return suspicious.some((pattern) => pattern.test(text));
});
if (hits.length) throw new Error(`credential-like text in: ${hits.map((file) => relative(stage, file)).join(', ')}`);
const sha = (buffer) => createHash('sha256').update(buffer).digest('hex');
const files = staged.map((file) => {
  const data = readFileSync(file);
  return { name: posix(relative(stage, file)), bytes: data.length, sha256: sha(data) };
});
const zip = join(out, `${NAME}.zip`);
rmSync(zip, { force: true });
execFileSync('powershell.exe', ['-NoProfile', '-Command', `Compress-Archive -Path '${stage}\\*' -DestinationPath '${zip}' -CompressionLevel Optimal`], { stdio: 'inherit' });

const events = traces.map((file) => JSON.parse(readFileSync(file, 'utf8')).events);
let overlapping = 0;
for (const list of events) {
  const spans = list.filter((e) => ['poll', 'join', 'cancel', 'purchase'].includes(e.type)).sort((a, b) => a.tSend - b.tSend);
  for (let i = 1; i < spans.length; i += 1) if (spans[i].tSend < spans[i - 1].tRecv) overlapping += 1;
}
const extracts = walk(join(stage, 'evidence')).filter((file) => /\.applog[^/\\]*\.json$/.test(file)).map((file) => JSON.parse(readFileSync(file, 'utf8')));

const manifest = {
  runId: 'peakpass-p6-20261003',
  part: 'GitHub Codex auto-review of PR #28, first round',
  codeSha,
  previous: [
    { archive: 'p6-final-20261003.zip', codeSha: '02ee7e025b31b5de39f942d4cfec1fc3e9432e74' },
    { archive: 'p6-review-20261003.zip', codeSha: 'b9656ab317d344f2bedff3b49ecfb9638c77f7bb' },
    { archive: 'p6-review2-20261003.zip', codeSha: 'fc0f4a8a665d385e52a3300882bd376eee4f24f8', head: '6645a2903fd2ab74071cd1f8f0121a2edcd67ca5' },
  ],
  baseSha: '2d67cc3c10a1d04bebe0a7a81f9575ea39e63363',
  contract: { revision: 'admission-v1', sha256: 'e22be4df9910811eba552f630b43170ba0cf0c8d953a54dc5a3cea34c0dcf3d1' },
  archive: `${NAME}.zip`,
  archiveSha256: sha(readFileSync(zip)),
  pullRequest: { number: 28, head: '6645a2903fd2ab74071cd1f8f0121a2edcd67ca5', ci: 'install-lint-test passed on 6645a29' },
  autoReview: {
    reviewer: 'chatgpt-codex-connector[bot] on PR #28',
    target: '6645a2903fd2ab74071cd1f8f0121a2edcd67ca5',
    findings: 'three P2: cross-tab race of the recognition marker (answered by an analysis rule, no code change); a reservation read answered after Reset (fixed); a 401 attempt missing from the trace and the request log (fixed)',
    fixedIn: codeSha,
    nextReview: 'starts with the next push',
  },
  results: {
    build: 'pass',
    typecheck: 'pass',
    lintErrors: 0,
    lintWarnings: 11,
    unitPassed: 223,
    unitSuites: 23,
    integrationPassed: 346,
    integrationSkipped: 15,
    integrationSuitesPassed: 30,
    integrationSuitesSkipped: 2,
    harnessPassed: 29,
    callbackHarness: 'pass',
    mutations: '49/49 at b9656ab; the polling script did not change afterwards',
    checkPageTask21: '10/10',
    checkPageTask22CasesPassed: 4,
    servedFilesEqualCommittedBlobs: 10,
    pageTraces: traces.length,
    overlappingRequestsInPageTraces: overlapping,
    serverLogExtractsOfTheBrowser: extracts.filter((j) => j.agents === 'browser').length,
    overlappingRequestsInServerLogExtracts: extracts.filter((j) => j.agents === 'browser').reduce((sum, j) => sum + j.overlapping, 0),
    finalSql: 'available + active reservation quantity + pending/paid/delivered order quantity = total (82 + 4 + 14 = 100); consumed results that do not match their target: 0',
  },
  scenarios: {
    s23: 'reservation read held back 8 s, Reset clicked meanwhile: before the change the late answer put the reservation back and marked step 3 done; after it nothing changed',
    s24: 'one status request answered 401 (invalid token injected) and repeated with a new session: before the change neither the trace nor the request log had the rejected attempt; after it the trace has an auth-retry record and the request log a 401 line',
  },
  note: 'No credentials, env file, token or raw HAR are archived; the raw application logs are not archived.',
  files,
};
writeFileSync(join(out, `${NAME}.json`), `${JSON.stringify(manifest, null, 2)}\n`);
console.log(JSON.stringify({ files: files.length, zipBytes: statSync(zip).size, zipSha256: manifest.archiveSha256, traces: traces.length, overlapping, extracts: manifest.results.serverLogExtractsOfTheBrowser }, null, 1));
