Evidence of the first GitHub Codex auto-review of PR #28, run peakpass-p6-20261003, code a9954d86c3705d45a763f6bfe1a1fde164231442.
p6-final-20261003.zip holds the evidence up to code 02ee7e0, p6-review-20261003.zip and p6-review2-20261003.zip
the two rounds of the external static review (codes b9656ab and fc0f4a8).

evidence/  s23-* a reservation read answered after Reset; s24-* a status request answered 401 and repeated
           with a new demo session. *-before.* ran on 6645a29 before the change, the others after it.
           review4.proxy.log: the proxy of these runs. final.console.log, final-f*, a11y-*.json: the final
           check on the new code.
logs/      the regression on the new code (ar1-*), the CI checks and the review records of PR #28 as
           read from GitHub (pr28-*), and summaries.txt (every trace as text).
scripts/   the scripts used for these runs; not part of the source tree; no env file.
