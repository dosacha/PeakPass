# Helpers shared by final.sh and review-fix.sh (run peakpass-p6-20261003). Source after lib.sh.
PILL='document.querySelector(".step .status-pill").innerText'
BANNER='document.querySelector(".qb-title")?.innerText'
# Only action buttons: a step header is a button too and names the same endpoint.
press() { js "(() => { const b = [...document.querySelectorAll('button.btn')].find(b => b.innerText.includes('$1')); if (!b) return 'no button: $1'; if (b.disabled) return 'disabled: $1'; b.click(); return 'clicked: $1'; })()"; }
open_step() { js "(() => { const s = [...document.querySelectorAll('.step')].find(s => s.querySelector('.step-head').innerText.includes('$1')); if (!s) return 'no step: $1'; if (!s.querySelector('.step-body')) s.querySelector('.step-head').click(); return 'open: $1'; })()" > /dev/null; pause 300; }
wait_pill() { for _ in $(seq 1 "${2:-90}"); do case "$(js "$PILL")" in *"$1"*) return 0;; esac; pause 700; done; return 1; }
seats() { psqlb "SELECT 'available='||e.available_seats||' total='||e.total_seats||' held='||(SELECT COALESCE(SUM(quantity),0) FROM reservations WHERE event_id=e.id AND status='active')||' ordered='||(SELECT COALESCE(SUM(quantity),0) FROM orders WHERE event_id=e.id AND status IN ('pending','paid','delivered'))||' reservations='||(SELECT COUNT(*) FROM reservations WHERE event_id=e.id)||' orders='||(SELECT COUNT(*) FROM orders WHERE event_id=e.id)||' results='||(SELECT COUNT(*) FROM admission_results WHERE event_id=e.id) FROM events e WHERE e.id='$EVENT'"; }
redis_entry() { entry "$(latest $USER1)" | node -e 'let s="";process.stdin.on("data",d=>s+=d).on("end",()=>{const e=JSON.parse(s);console.log(JSON.stringify({admissionId:e.admissionId,sequence:e.sequence,state:e.state,phase:e.phase,reason:e.reason,outcome:e.outcome}))})'; }
field() { node -e 'console.log(JSON.parse(process.argv[1])[process.argv[2]])' "$1" "$2"; }
fillers() { ( set -a; . "$RUN/browser.env"; set +a; node "$RUN/fillers.mjs" "$API_B" "$EVENT" "$1" "$2" "$3" > "$EV/$4.fillers.log" 2>&1 & ); }
applog() { ( cd "$RUN" && node applog.mjs logs/app-a5.log,logs/app-b5.log "$2" "$3" > "evidence/$1.applog.json" ); node -e 'const j=JSON.parse(require("fs").readFileSync(process.argv[1],"utf8"));const o={};for(const[k,v]of Object.entries(j))if(!Array.isArray(v)||k==="window")o[k]=v;console.log("server log: "+JSON.stringify(o))' "$EV/$1.applog.json"; }
ACTIVE='(() => { const a = document.activeElement; return a.tagName + ":" + (a.innerText || "").trim().slice(0, 20) + ":expanded=" + (a.getAttribute("aria-expanded") || "-"); })()'
# axe-core, WCAG 2 A and AA rules, scoped to the queue card. The tool lists at most ten nodes
# of a rule, so the node count of each rule is printed next to what is listed. The pointer is
# moved away first: a button under it shows its hover colour, which has another contrast.
audit() { # <name> [selector]
  AB mouse move 2 2 > /dev/null
  AB a11y --tags wcag2a,wcag2aa ${2:+--selector "$2"} --json > "$EV/a11y-$1.json"
  node -e 'const d=JSON.parse(require("fs").readFileSync(process.argv[1],"utf8")).data; const f=(k)=>d[k].map(v=>v.id+" "+v.nodeCount+": "+v.nodes.map(n=>n.target.join(" ")+" ("+((n.failureSummary||"").match(/contrast of ([0-9.]+)/)||[,"-"])[1]+")").join(", ")).join("; "); console.log("audit "+process.argv[2]+" | violations: "+(f("violations")||"none")+" | incomplete: "+(f("incomplete")||"none")+" | axe "+d.axeVersion)' "$EV/a11y-$1.json" "$1"
}
# One case of the native keyboard check page: real key presses, then the page's own verdict.
run_case() { # <case> <keys…>
  local c=$1; shift
  AB open "$FRONT/task22-keyboard-check.html?case=$c" > /dev/null
  for _ in $(seq 1 20); do case "$(js 'document.getElementById("results").textContent.slice(0,9)')" in *Loading*) pause 500;; *) break;; esac; done
  AB click "#start" > /dev/null
  for k in "$@"; do AB press "$k" > /dev/null; done
  AB click "#verify" > /dev/null
  echo "task22 $c: $* => $(js 'document.getElementById("results").textContent.trim().split("\n").slice(-1)[0]')"
}
