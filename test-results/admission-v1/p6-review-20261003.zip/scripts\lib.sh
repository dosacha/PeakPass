# Helpers of the P6 browser checks (run peakpass-p6-20261003). Source it: `. ../run/lib.sh`.
# Not part of the source tree. Nothing here prints a token: the request list is read without
# headers and the page trace holds none.
export AGENT_BROWSER_SESSION=peakpass-p6
RUN=/c/Users/dosac/.claude/worktrees/peakpass-issue15/run
EV=$RUN/evidence
FRONT=http://127.0.0.1:8765
API_A=http://127.0.0.1:3101
API_B=http://127.0.0.1:3102
PROXY=http://127.0.0.1:3103
EVENT=a3ae4dfe-160b-5ec7-9a08-125b9235b45f
OTHER_EVENT=4ed183c2-ab4d-54a8-8404-d4f5b932e9a6
REDIS=peakpass-p6-redis-browser

AB() { timeout 45 agent-browser "$@" 2>&1; }
js() { AB eval "$1" | tail -1; }
pause() { AB wait "$1" > /dev/null; }
now() { date -u +%Y-%m-%dT%H:%M:%S.%3NZ; }

# Opens the page for one scenario: live mode, the given API base, polling mode and run id.
open_page() { # <runId> <mode> [apiBase]
  AB open "$FRONT/index.html" > /dev/null
  js "localStorage.setItem('pp_api_base','${3:-$API_A}'); localStorage.setItem('pp_mode','live'); localStorage.setItem('pp_event_id','$EVENT'); localStorage.setItem('pp_tier_id','91dfab04-048e-53af-b2ec-50bcaeff16e1'); 'ok'" > /dev/null
  # The static server sends no cache policy, so a file edited seconds ago can be served from the
  # browser's cache. Reading each file with cache "reload" replaces the cached copy.
  AB eval '(async () => { for (const f of ["index.html","styles.css","utils.js","admission-polling.js","app.jsx","app-flow.jsx"]) await (await fetch(f, { cache: "reload" })).text(); return "fresh"; })()' > /dev/null
  AB network requests --clear > /dev/null
  AB open "$FRONT/index.html?run=$1&poll=$2" > /dev/null
  pause 1200
  AB find role button click --name "실행 — Load events" > /dev/null
  pause 1200
}

card() {
  js 'JSON.stringify({pill: [...document.querySelectorAll(".step .status-pill")].map(p => p.innerText).join(","), banner: document.querySelector(".queue-banner")?.innerText.replace(/\n/g," | "), notes: [...document.querySelectorAll(".queue-note")].map(n => n.innerText), buttons: [...document.querySelectorAll(".queue-banner ~ .btn-row .btn")].map(b => b.innerText.trim() + (b.disabled ? " [disabled]" : "")), reserve: [...document.querySelectorAll(".step .btn-danger")].filter(b => b.innerText.includes("POST /reservations")).map(b => b.disabled ? "disabled" : "enabled").join(), admission: (window.PeakPassAdmissionTrace.snapshot().events.filter(e => e.type === "poll" && e.state).slice(-1)[0] || {}).state, title: document.title})'
}
click() { AB find role button click --name "$1" | tail -1; }
reserve() { js '[...document.querySelectorAll(".step .btn-danger")].find(b => b.innerText.includes("POST /reservations")).click(); "reserve clicked"'; }

# Saves the page trace. The eval result is a JSON string of the JSON text.
save_trace() { # <name>
  AB eval 'JSON.stringify(window.PeakPassAdmissionTrace.snapshot())' | tail -1 \
    | node -e 'let s="";process.stdin.on("data",d=>s+=d).on("end",()=>require("fs").writeFileSync(process.argv[1],JSON.stringify(JSON.parse(JSON.parse(s)),null,1)+"\n"))' "$EV/$1.trace.json"
  node "$RUN/summary.mjs" "$EV/$1.trace.json"
}
# The browser's own request list: method, URL and status only.
save_requests() { # <name>
  AB network requests --filter 127.0.0.1:310 > "$EV/$1.requests.txt"
  echo "requests: $(grep -c . "$EV/$1.requests.txt") lines; admission POST $(grep -c 'POST .*/admissions ' "$EV/$1.requests.txt"), DELETE $(grep -c 'DELETE ' "$EV/$1.requests.txt"), status GET $(grep -c 'GET .*/admissions/me' "$EV/$1.requests.txt"), reservations POST $(grep -c 'POST .*/reservations' "$EV/$1.requests.txt")"
}
rcli() { docker exec $REDIS redis-cli "$@"; }
epoch() { rcli HGET "peakpass:admission:$EVENT:control" epoch; }
lease() { rcli ZSCORE "peakpass:admission:$EVENT:$(epoch):leases" "$1"; }
entry() { rcli HGET "peakpass:admission:$EVENT:$(epoch):entries" "$1"; }
USER1=56302f15-9185-4a87-a687-ad2c4b882df6
USER2=fb6f13a4
# The user's last entry in the current epoch, read from Redis so that nothing renews a lease.
latest() { rcli HGET "peakpass:admission:$EVENT:$(epoch):latest" "$1"; }
seconds() { echo $(( $(date +%s) - S0 )); }
until_s() { while [ $(seconds) -lt "$1" ]; do pause 1000; done; }
# Waits until the user's last entry is finished, so that a scenario starts from a new join.
settled() {
  for _ in $(seq 1 60); do
    case "$(entry "$(latest $USER1)")" in *'"state":"waiting"'*|*'"state":"admitted"'*) pause 2000;; *) return 0;; esac
  done
  return 1
}
# Waits until nobody is waiting or admitted, so that the next join is admitted at once.
drained() {
  for _ in $(seq 1 90); do
    w=$(rcli ZCARD "peakpass:admission:$EVENT:$(epoch):waiting"); a=$(rcli ZCARD "peakpass:admission:$EVENT:$(epoch):active")
    [ "$w" = "1" ] && [ "$a" = "1" ] && return 0
    pause 2000
  done
  return 1
}
psqlb() { docker exec peakpass-p6-pg psql -U peakpass -d peakpass_browser -Atc "$1"; }
