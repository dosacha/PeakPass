#!/usr/bin/env bash
# Final check of the committed frontend in a real browser against the real application, Redis
# and PostgreSQL (run peakpass-p6-20261003). Not part of the source tree. It repeats the main
# flow on the final commit and saves what earlier runs only printed: the Redis entry around a
# reload and a re-join, the seats before and after, and the final SQL of contract §8.
#   bash final.sh            (from anywhere; prints to the console, tee it into the evidence)
. /c/Users/dosac/.claude/worktrees/peakpass-issue15/run/lib.sh
REPO=/c/Users/dosac/.claude/worktrees/peakpass-issue15/PeakPass
cd "$REPO" || exit 1
. "$RUN/helpers.sh"


echo "== commit $(git rev-parse HEAD), working tree changes in frontend: $(git status --short frontend | wc -l)"
echo "== served files against the committed blobs (line endings normalized)"
for f in $(git ls-files frontend); do
  served=$(curl -s "$FRONT/${f#frontend/}" | tr -d '\r' | sha256sum | cut -c1-64)
  blob=$(git show "HEAD:$f" | tr -d '\r' | sha256sum | cut -c1-64)
  [ "$served" = "$blob" ] && echo "same  $f ${blob:0:16}" || echo "DIFFERENT $f served ${served:0:16} blob ${blob:0:16}"
done

echo; echo "== existing check pages"
AB open "$FRONT/task21-contract-check.html" > /dev/null; pause 5000
echo "task21: $(js '(() => { const t = document.body.innerText.split("\n"); return t.filter(l => /^PASS: |^FAIL/.test(l)).join(" | ") + " (PASS lines " + t.filter(l => /^PASS /.test(l)).length + ", FAIL lines " + t.filter(l => /^FAIL/.test(l)).length + ")"; })()')"
run_case toggle Tab Enter Space
run_case step Tab Enter Space Tab Enter Space
run_case selection Tab Tab Enter Space Tab Tab Enter Space
run_case log Tab Tab Enter Space

echo; echo "== F1 adaptive: join, reload while waiting, admission, reservation, checkout, settlement"
settled; F1_FROM=$(now)
echo "seats before: $(seats)"
fillers 12 45 80 final-f1; pause 2500
open_page final-f1 adaptive
echo "card on load: $(js "$PILL")"
press "등록"; pause 2500
A=$(redis_entry); echo "after join: card=$(js "$PILL") redis=$A"
save_trace final-f1a | grep -E "meta|summary"
AB open "$FRONT/index.html?run=final-f1&poll=adaptive" > /dev/null; pause 2500
B=$(redis_entry); echo "after reload: card=$(js "$PILL") redis=$B"
[ "$(field "$A" admissionId)" = "$(field "$B" admissionId)" ] && [ "$(field "$A" sequence)" = "$(field "$B" sequence)" ] && echo "reload: same entry and sequence" || echo "reload: ENTRY CHANGED"
wait_pill "입장" 120 && echo "admitted: redis=$(redis_entry) title=$(js 'document.title')" || echo "NOT ADMITTED: $(js "$PILL")"
echo "step 3: $(press 'POST /reservations')"; pause 2000
echo "after reservation: card=$(js "$PILL") banner=$(js "$BANNER") redis=$(redis_entry)"
save_trace final-f1b | grep -E "meta|RECOGNITION|MISSED|purchase|summary"
# A reload after the purchase, under another run id: the admission is neither counted again nor
# called missed, and the reservation is read back so that the checkout can continue.
AB open "$FRONT/index.html?run=final-f1-other&poll=adaptive" > /dev/null; pause 2500
echo "reload under another run id: card=$(js "$PILL") recognitions=$(js 'window.PeakPassAdmissionTrace.snapshot().events.filter(e => e.type === "recognition").length') missed=$(js 'window.PeakPassAdmissionTrace.snapshot().events.filter(e => e.type === "recognition-missed").length')"
echo "read the reservation back: $(press '예약 불러오기')"; pause 1500
open_step "Checkout"; echo "step 4: $(press 'POST /checkouts')"; pause 2000
open_step "Settlement Webhook"; echo "step 5: $(press '/demo/settlement')"; pause 2500
echo "after settlement: card=$(js "$PILL") banner=$(js "$BANNER")"
save_trace final-f1c | grep -E "meta|RECOGNITION|MISSED|purchase|summary"
save_requests final-f1
echo "seats after: $(seats)"
psqlb "SELECT 'result: operation='||a.operation||' outcome='||a.outcome||' reservation='||COALESCE(left(a.reservation_id::text,8),'-')||' reservation.status='||COALESCE(r.status,'-')||' order='||COALESCE((SELECT left(o.id::text,8)||'/'||o.status FROM orders o WHERE o.reservation_id=r.id),'-') FROM admission_results a LEFT JOIN reservations r ON r.id=a.reservation_id WHERE a.admission_id='$(field "$A" admissionId)'"
applog final-f1 "$F1_FROM" "$(now)"

echo; echo "== F2 fixed: join, cancel, join again, late cancel of the first entry, expiry"
settled; F2_FROM=$(now)
fillers 12 40 100 final-f2; pause 2500
open_page final-f2 fixed
# The entry of F1 was recognized under another run id; this run must not record it as missed.
echo "card on load: $(js "$PILL"); missed records after the first poll of this run: $(js 'window.PeakPassAdmissionTrace.snapshot().events.filter(e => e.type === "recognition-missed").length')"
press "등록"; pause 2500
A=$(redis_entry); echo "entry A: card=$(js "$PILL") redis=$A"
audit waiting ".step:has(.queue-lead)"
click "대기 취소" > /dev/null; pause 300; audit waiting-confirm ".step:has(.queue-lead)"; click "돌아가기" > /dev/null; pause 300
# The cancel is made with the keyboard: Tab from the mode toggle, Enter, Tab, Enter.
js 'document.querySelector(".queue-mode-option").focus(); "focus"' > /dev/null
AB press Tab > /dev/null; AB press Tab > /dev/null; echo "keyboard: two Tabs from the mode toggle reach: $(js "$ACTIVE")"
AB press Enter > /dev/null; pause 300; echo "keyboard: Enter opens the confirmation, focus stays on: $(js "$ACTIVE")"
AB press Tab > /dev/null; echo "keyboard: Tab moves to: $(js "$ACTIVE")"
AB press Enter > /dev/null; pause 1500
echo "after cancel: card=$(js "$PILL") redis=$(redis_entry)"
pause 3000; echo "status requests in the 3 s after the cancel: see the trace"
press "다시 등록"; pause 2500
B=$(redis_entry); echo "entry B: card=$(js "$PILL") redis=$B"
[ "$(field "$B" sequence)" -gt "$(field "$A" sequence)" ] && echo "re-join: new entry with a later sequence" || echo "re-join: SEQUENCE NOT LATER"
echo "late cancel of A, sent outside the browser: $( ( set -a; . "$RUN/browser.env"; set +a; node "$RUN/as-user.mjs" "$API_A" user1@example.com cancel "$EVENT" "$(field "$A" admissionId)" "$(epoch)" ) 2>&1 | tail -1)"
pause 1500; echo "entry B after the late cancel: card=$(js "$PILL") redis=$(redis_entry)"
wait_pill "입장" 120 && echo "admitted: redis=$(redis_entry)" || echo "NOT ADMITTED: $(js "$PILL")"
audit admitted ".step:has(.queue-lead)"
wait_pill "만료" 60 && echo "expired: redis=$(redis_entry)" || echo "NOT EXPIRED: $(js "$PILL")"
pause 5000
audit finished ".step:has(.queue-lead)"
audit page
echo "announced: status=$(js 'document.querySelector(".step:has(.queue-lead) [role=status]").textContent') alert=$(js 'document.querySelector(".step:has(.queue-lead) [role=alert]").textContent')"
save_trace final-f2 | grep -E "meta|RECOGNITION|MISSED|cancel|join|summary"
save_requests final-f2
applog final-f2 "$F2_FROM" "$(now)"

echo; echo "== final SQL of contract §8 on the browser database"
echo "seats: $(seats)"
psqlb "SELECT 'invariant available+held+ordered=total: '||(e.available_seats + (SELECT COALESCE(SUM(quantity),0) FROM reservations WHERE event_id=e.id AND status='active') + (SELECT COALESCE(SUM(quantity),0) FROM orders WHERE event_id=e.id AND status IN ('pending','paid','delivered')) = e.total_seats)||', 0<=available<=total: '||(e.available_seats BETWEEN 0 AND e.total_seats) FROM events e WHERE e.id='$EVENT'"
psqlb "SELECT 'consumed results that do not match their target: '||COUNT(*) FROM admission_results a LEFT JOIN reservations r ON r.id=a.reservation_id LEFT JOIN orders o ON o.id=a.order_id WHERE a.event_id='$EVENT' AND a.outcome='consumed' AND NOT COALESCE((a.operation='reservation' AND r.user_id=a.user_id AND r.event_id=a.event_id AND r.tier_id=a.fingerprint::jsonb->>4 AND r.quantity=(a.fingerprint::jsonb->>5)::int) OR (a.operation='direct-checkout' AND o.user_id=a.user_id AND o.event_id=a.event_id AND o.reservation_id IS NULL AND o.tier_id=a.fingerprint::jsonb->>4 AND o.quantity=(a.fingerprint::jsonb->>5)::int AND o.idempotency_key::text=a.fingerprint::jsonb->>6), false)"
psqlb "SELECT 'results by outcome: '||string_agg(outcome||'='||n, ', ') FROM (SELECT outcome, COUNT(*) n FROM admission_results WHERE event_id='$EVENT' GROUP BY outcome) s"
psqlb "SELECT 'reservations by status: '||string_agg(status||'='||n, ', ') FROM (SELECT status, COUNT(*) n FROM reservations WHERE event_id='$EVENT' GROUP BY status) s"
psqlb "SELECT 'orders by status: '||COALESCE(string_agg(status||'='||n, ', '),'none') FROM (SELECT status, COUNT(*) n FROM orders WHERE event_id='$EVENT' GROUP BY status) s"
