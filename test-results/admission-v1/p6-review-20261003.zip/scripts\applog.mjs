// Reads the application's own request log as an observer that is independent of the page
// (run peakpass-p6-20261003). Not part of the source tree. Fastify logs one JSON line when a
// request arrives (method, URL, user agent, time) and one when it completes (status, response
// time). The logger does not record the Authorization header.
//
// Usage: node applog.mjs <log>[,<log>…] <fromIso> <toIso> [--all-agents] [--gaps]
// By default only requests of the browser (user agent containing "Chrome") are counted, so the
// synthetic users and the helper scripts (user agent "node") are left out.
import { readFileSync } from 'node:fs';

const [files, from, to, ...flags] = process.argv.slice(2);
const start = Date.parse(from);
const end = Date.parse(to);
const browserOnly = !flags.includes('--all-agents');
const arrived = new Map();
const requests = [];
for (const file of files.split(',')) {
  for (const line of readFileSync(file, 'utf8').split(/\r?\n/)) {
    if (!line.startsWith('{"level"')) continue;
    let entry;
    try {
      entry = JSON.parse(line);
    } catch {
      continue;
    }
    const key = `${file}:${entry.pid}:${entry.reqId}`;
    if (entry.msg === 'incoming request') arrived.set(key, entry);
    else if (entry.msg === 'request completed' && arrived.has(key)) {
      const first = arrived.get(key);
      arrived.delete(key);
      const agent = first.req.userAgent ?? '';
      if (first.time < start || first.time > end) continue;
      if (browserOnly && !agent.includes('Chrome')) continue;
      requests.push({
        at: first.time,
        done: entry.time,
        ms: entry.res.responseTime,
        method: first.req.method,
        url: first.req.url,
        status: entry.res.statusCode,
      });
    }
  }
}
requests.sort((a, b) => a.at - b.at);
const queue = requests.filter((q) => q.url.includes('/admissions') || q.url === '/reservations');
const own = queue.filter((q) => q.method !== 'OPTIONS');
const status = own.filter((q) => q.method === 'GET' && q.url.endsWith('/admissions/me'));
const gaps = status.slice(1).map((q, i) => q.at - status[i].at);
// Server side view of "one request at a time": a request arrives after the previous completed.
let overlapping = 0;
for (let i = 1; i < own.length; i += 1) if (own[i].at < own[i - 1].done) overlapping += 1;
const perSecond = new Map();
for (const q of status) perSecond.set(Math.floor(q.at / 1000), (perSecond.get(Math.floor(q.at / 1000)) ?? 0) + 1);
const tally = (list) => {
  const out = {};
  for (const q of list) out[`${q.method} ${q.status}`] = (out[`${q.method} ${q.status}`] ?? 0) + 1;
  return out;
};
console.log(
  JSON.stringify({
    window: [from, to],
    agents: browserOnly ? 'browser' : 'all',
    preflights: queue.filter((q) => q.method === 'OPTIONS').length,
    status: tally(status),
    join: tally(own.filter((q) => q.method === 'POST' && q.url.endsWith('/admissions'))),
    cancel: tally(own.filter((q) => q.method === 'DELETE')),
    reservations: tally(own.filter((q) => q.url === '/reservations')),
    overlapping,
    statusGapMs: gaps.length ? { min: Math.min(...gaps), max: Math.max(...gaps) } : null,
    maxStatusPerSecond: perSecond.size ? Math.max(...perSecond.values()) : 0,
  }),
);
if (flags.includes('--gaps')) console.log(`gaps ${gaps.join(' ')}`);
