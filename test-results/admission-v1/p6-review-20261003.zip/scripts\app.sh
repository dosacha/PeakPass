#!/usr/bin/env bash
# Starts and stops the application processes of the P6 browser checks (run peakpass-p6-20261003).
# Not part of the source tree. Only processes listening on the ports of this run are touched.
#   app.sh start <port> <demoUserEmail> <enableAdmission:true|false> <logFile>
#   app.sh stop <port>
#   app.sh wait <port>
set -u
RUN=/c/Users/dosac/.claude/worktrees/peakpass-issue15/run
REPO=/c/Users/dosac/.claude/worktrees/peakpass-issue15/PeakPass

pid_on() { netstat -ano | grep -E "TCP +(0\.0\.0\.0|127\.0\.0\.1):$1 .*LISTENING" | awk '{print $NF}' | head -1; }

case "$1" in
  start)
    cd "$REPO" || exit 1
    set -a; . "$RUN/browser.env"; set +a
    export PORT=$2 DEMO_USER_EMAIL=$3 ENABLE_ADMISSION=$4
    ( npx --no-install tsx src/main.ts > "$RUN/logs/$5" 2>&1 & ) > /dev/null 2>&1
    ;;
  stop)
    pid=$(pid_on "$2")
    if [ -n "$pid" ]; then taskkill //PID "$pid" //T //F > /dev/null 2>&1; echo "stopped pid $pid on $2"; else echo "nothing on $2"; fi
    ;;
  wait)
    for _ in $(seq 1 80); do
      code=$(curl -s -o /dev/null -w '%{http_code}' "http://127.0.0.1:$2/ready" || true)
      [ "$code" = "200" ] && { echo "ready on $2"; exit 0; }
      node -e "setTimeout(()=>{},300)"
    done
    echo "not ready on $2"; exit 1
    ;;
esac
