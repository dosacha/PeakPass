#!/usr/bin/env bash
# Real-browser checks for the findings of the external review (run peakpass-p6-20261003). Not
# part of the source tree. The page talks to the application through the local proxy, which can
# lose answers of a purchase or a join and hold back the answer of a reservation read.
#   bash review2.sh s18|s19|s20 [label]      label is appended to the evidence names
. /c/Users/dosac/.claude/worktrees/peakpass-issue15/run/lib.sh
REPO=/c/Users/dosac/.claude/worktrees/peakpass-issue15/PeakPass
cd "$REPO" || exit 1
. "$RUN/helpers.sh"
L=${2:+-$2}
NOTES='[...document.querySelectorAll(".queue-note")].map(n => n.innerText.replace(/\s+/g," ")).join(" / ")'
# What the page holds, from its state inspector.
FORM='(() => { const r = Object.fromEntries([...document.querySelectorAll(".insp-row")].map(x => [x.querySelector(".k").innerText, x.querySelector(".v").innerText])); return JSON.stringify({ event: r.selectedEvent, tier: r.selectedTier, quantity: r.quantity, reservation: r.reservationId === "—" ? "—" : r.reservationId.slice(0, 8), reservationStatus: r["reservation.status"], order: r.orderStatus, queue: r["queue.phase"] }); })()'
LAST_LOG='[...document.querySelectorAll(".le-head")].slice(-1).map(h => [h.querySelector(".method").innerText, h.querySelector(".url").innerText.replace(/[0-9a-f-]{36}/g, "<id>"), h.querySelector(".status").innerText].join(" ")).join("")'
STEP3='(() => { const b = [...document.querySelectorAll("button.btn")].find(b => b.innerText.includes("POST /reservations")); return "step 3 button: " + (b ? (b.disabled ? "disabled" : "enabled") : "not shown"); })()'
proxylog() { grep -c . "$EV/review2.proxy.log" 2>/dev/null || echo 0; }
since() { tail -n +"$(( $1 + 1 ))" "$EV/review2.proxy.log" | grep -v '"OPTIONS"'; }
# Sets the quantity input of step 2 the way a typed value would.
quantity() { open_step "tier"; js "(() => { const i = document.querySelector('input.input.small[type=number]'); Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(i, '$1'); i.dispatchEvent(new Event('input', { bubbles: true })); return 'quantity $1'; })()" > /dev/null; pause 300; }
pick_event() { js "(() => { [...document.querySelectorAll('.event-card')].find(c => c.innerText.includes('$1')).click(); return 'event'; })()" > /dev/null; pause 800; open_step "tier"; js 'document.querySelector(".tier-card").click(); "tier"' > /dev/null; pause 400; }

# A purchase of quantity 1 whose answers are lost, recovered after a reload, then the checkout.
s18() {
  settled; drained; local from; from=$(now); local mark; mark=$(proxylog)
  echo "seats before: $(seats)"
  open_page "s18-quantity$L" fixed "$PROXY"
  quantity 1; echo "form: $(js "$FORM")"
  press "등록"; wait_pill "입장" 40 && echo "admitted: redis=$(redis_entry)" || echo "NOT ADMITTED: $(js "$PILL")"
  local admitted; admitted=$(field "$(redis_entry)" admissionId)
  echo 9 > "$RUN/drop.flag"
  echo "step 3: $(press 'POST /reservations')"; pause 1800
  AB open "$FRONT/index.html?run=s18-quantity$L&poll=fixed" > /dev/null; pause 2500
  rm -f "$RUN/drop.flag"
  echo "after the reload: card=$(js "$PILL") form=$(js "$FORM")"
  echo "repeat the same request: $(press '같은 요청으로 다시 확인')"; pause 2500
  echo "after the repeat: card=$(js "$PILL") form=$(js "$FORM")"
  open_step "Checkout"; echo "step 4: $(press 'POST /checkouts')"; pause 2500
  echo "after the checkout: form=$(js "$FORM") last request: $(js "$LAST_LOG")"
  save_trace "s18-quantity$L" | grep -E "purchase|summary"
  echo "proxy:"; since "$mark" | grep reservations
  psqlb "SELECT 'reservation: quantity='||r.quantity||' status='||r.status||'; order: '||COALESCE((SELECT 'quantity='||o.quantity||' status='||o.status FROM orders o WHERE o.reservation_id=r.id),'none') FROM admission_results a JOIN reservations r ON r.id=a.reservation_id WHERE a.admission_id='$admitted'"
  echo "seats after: $(seats)"
  save_requests "s18-quantity$L"
  applog "s18-quantity$L" "$from" "$(now)"
}

# A join whose answer is lost and whose entry the page then reads, then cancel and join again.
s19() {
  settled; drained; local from; from=$(now); local mark; mark=$(proxylog)
  open_page "s19-join-key$L" fixed "$PROXY"
  echo 2 > "$RUN/drop-join.flag"
  echo "join: $(press '등록')"; pause 3000
  rm -f "$RUN/drop-join.flag"
  local a; a=$(redis_entry)
  echo "after the lost join: card=$(js "$PILL") notes=$(js "$NOTES") redis=$a"
  click "대기 취소" > /dev/null; pause 300; click "취소 확정" > /dev/null; pause 1500
  echo "after the cancel: card=$(js "$PILL") redis=$(redis_entry)"
  echo "join again: $(press '다시 등록')"; pause 2500
  local b; b=$(redis_entry)
  echo "after joining again: card=$(js "$PILL") redis=$b"
  [ "$(field "$a" admissionId)" != "$(field "$b" admissionId)" ] && echo "join again: a new entry" || echo "join again: THE CANCELLED ENTRY WAS REPLAYED, no new entry"
  save_trace "s19-join-key$L" | grep -E "join|cancel|summary"
  echo "proxy:"; since "$mark" | grep '/admissions"'
  save_requests "s19-join-key$L"
  applog "s19-join-key$L" "$from" "$(now)"
}

# The reservation is read back after a reload and the event is changed before the answer.
s20() {
  settled; drained; local from; from=$(now); local mark; mark=$(proxylog)
  open_page "s20-late-load$L" fixed "$PROXY"
  quantity 1
  press "등록"; wait_pill "입장" 40 && echo "admitted: redis=$(redis_entry)" || echo "NOT ADMITTED: $(js "$PILL")"
  echo "step 3: $(press 'POST /reservations')"; pause 2000
  AB open "$FRONT/index.html?run=s20-late-load$L&poll=fixed" > /dev/null; pause 2500
  echo "after the reload: card=$(js "$PILL") form=$(js "$FORM")"
  echo 10000 > "$RUN/delay.flag"
  echo "load: $(press '예약 불러오기')"; pause 500
  pick_event "Advanced GraphQL"
  echo "other event, before the late answer: card=$(js "$PILL") form=$(js "$FORM") $(js "$STEP3")"
  pause 11000
  rm -f "$RUN/delay.flag"
  echo "other event, after the late answer: card=$(js "$PILL") form=$(js "$FORM") $(js "$STEP3")"
  echo "proxy:"; since "$mark" | grep 'GET.*reservations/'
  save_trace "s20-late-load$L" | grep -E "purchase|summary"
  save_requests "s20-late-load$L"
  applog "s20-late-load$L" "$from" "$(now)"
}

"$1"
