// Builds the evidence archive of the external review follow-up of P6 (run peakpass-p6-20261003).
// Not part of the source tree. Run from the run directory: node archive-review.mjs <codeSha>
// The first archive (p6-final-20261003) stays as it is; this one holds what was made after it.
import { createHash } from 'node:crypto';
import { cpSync, mkdirSync, readFileSync, readdirSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { execFileSync, spawnSync } from 'node:child_process';
import { join, relative, sep } from 'node:path';

const codeSha = process.argv[2];
if (!/^[0-9a-f]{40}$/.test(codeSha ?? '')) throw new Error('usage: node archive-review.mjs <codeSha>');
const RUN = process.cwd();
const REPO = join(RUN, '..', 'PeakPass');
const NAME = 'p6-review-20261003';
const stage = join(RUN, 'archive', NAME);
const out = join(REPO, 'test-results', 'admission-v1');
const posix = (path) => path.split(sep).join('/');
const walk = (dir) =>
  readdirSync(dir).flatMap((name) => {
    const path = join(dir, name);
    return statSync(path).isDirectory() ? walk(path) : [path];
  });

// The evidence made after the first archive: the external review checks (s18–s20, with their
// runs before the change), the final check on the new code and the earlier final check that
// the first archive holds under other names.
const EV = join(RUN, 'evidence');
const evidence = readdirSync(EV).filter(
  (name) => /^(s18-|s19-|s20-|review2\.proxy\.log$|final\.console\.log$|final-f[12][abc]?\.|a11y-(waiting|waiting-confirm|admitted|finished|page)\.json$)/.test(name),
);
rmSync(join(RUN, 'archive', NAME), { recursive: true, force: true });
mkdirSync(join(stage, 'evidence'), { recursive: true });
for (const name of evidence) cpSync(join(EV, name), join(stage, 'evidence', name), { recursive: true });
cpSync(join(EV, 'final-02ee7e0'), join(stage, 'evidence', 'final-02ee7e0'), { recursive: true });

const traces = walk(join(stage, 'evidence')).filter((file) => file.endsWith('.trace.json')).sort();
mkdirSync(join(stage, 'logs'));
writeFileSync(
  join(stage, 'logs', 'summaries.txt'),
  traces
    .map((file) => `=== ${posix(relative(stage, file))}\n${spawnSync(process.execPath, [join(RUN, 'summary.mjs'), file], { encoding: 'utf8' }).stdout}`)
    .join(''),
);
for (const name of readdirSync(join(RUN, 'logs')).filter((n) => /^(red-8-external|green-8-external|mutation-4|external-unit|ext-)/.test(n)))
  cpSync(join(RUN, 'logs', name), join(stage, 'logs', name));
mkdirSync(join(stage, 'scripts'));
for (const name of ['review2.sh', 'proxy.mjs', 'helpers.sh', 'lib.sh', 'final.sh', 'mutate.mjs', 'summary.mjs', 'applog.mjs', 'app.sh', 'archive-review.mjs'])
  cpSync(join(RUN, name), join(stage, 'scripts', name));
writeFileSync(
  join(stage, 'README.txt'),
  [
    `Evidence of the external review follow-up of run peakpass-p6-20261003, code ${codeSha}.`,
    'The first archive, p6-final-20261003.zip, holds the evidence up to code 02ee7e0.',
    '',
    'evidence/  s18-* quantity after a recovered purchase, s19-* a join whose answer was lost, s20-* a reservation',
    '           read answered after the event changed. *-before.* ran on ba39f2a before the change, the others',
    '           after it; s19-join-key-run1.* ran before a redundant line was removed, s19-join-key.* on the commit.',
    '           final.console.log, final-f*, a11y-*.json: the final check on the new code. final-02ee7e0/: the',
    '           final check on the previous code (also in the first archive, under other names).',
    'logs/      RED and GREEN of the join-key tests, the mutation check and the regression on the new code.',
    'scripts/   the scripts used for these runs; not part of the source tree; no env file.',
    '',
  ].join('\n'),
);

const suspicious = [
  /eyJ[A-Za-z0-9_-]{10,}/,
  /Bearer [A-Za-z0-9._-]{12,}/,
  /:\/\/[^/\s:@]+:[^@\s/]+@/,
  /(JWT_SECRET|DB_PASSWORD|POSTGRES_PASSWORD|REDIS_PASSWORD)=[A-Za-z0-9_\-+/]{8,}/,
];
const staged = walk(stage).sort();
const hits = staged.filter((file) => suspicious.some((pattern) => pattern.test(readFileSync(file, 'utf8'))));
if (hits.length) throw new Error(`credential-like text in: ${hits.map((file) => relative(stage, file)).join(', ')}`);
const sha = (buffer) => createHash('sha256').update(buffer).digest('hex');
const files = staged.map((file) => {
  const data = readFileSync(file);
  return { name: posix(relative(stage, file)), bytes: data.length, sha256: sha(data) };
});
const zip = join(out, `${NAME}.zip`);
rmSync(zip, { force: true });
execFileSync('powershell.exe', ['-NoProfile', '-Command', `Compress-Archive -Path '${stage}\\*' -DestinationPath '${zip}' -CompressionLevel Optimal`], { stdio: 'inherit' });

const events = traces.map((file) => JSON.parse(readFileSync(file, 'utf8')).events);
let overlapping = 0;
for (const list of events) {
  const spans = list.filter((e) => ['poll', 'join', 'cancel', 'purchase'].includes(e.type)).sort((a, b) => a.tSend - b.tSend);
  for (let i = 1; i < spans.length; i += 1) if (spans[i].tSend < spans[i - 1].tRecv) overlapping += 1;
}
const extracts = walk(join(stage, 'evidence')).filter((file) => /\.applog[^/\\]*\.json$/.test(file)).map((file) => JSON.parse(readFileSync(file, 'utf8')));
const recognitions = events.flat().filter((e) => e.type === 'recognition');

const manifest = {
  runId: 'peakpass-p6-20261003',
  part: 'external review follow-up',
  codeSha,
  previous: { archive: 'p6-final-20261003.zip', codeSha: '02ee7e025b31b5de39f942d4cfec1fc3e9432e74', head: 'ba39f2a68216036bb856a9976000c9fd7a18ac90' },
  baseSha: '2d67cc3c10a1d04bebe0a7a81f9575ea39e63363',
  contract: { revision: 'admission-v1', sha256: 'e22be4df9910811eba552f630b43170ba0cf0c8d953a54dc5a3cea34c0dcf3d1' },
  archive: `${NAME}.zip`,
  archiveSha256: sha(readFileSync(zip)),
  externalReview: {
    reviewer: 'a Codex session with four independent subagents, relayed by the maintainer; the relayed result states no model, version or effort',
    target: '2d67cc3c10a1d04bebe0a7a81f9575ea39e63363..ba39f2a68216036bb856a9976000c9fd7a18ac90',
    mode: 'static, plus the polling unit file (60/60) and three in-memory reproductions; no browser, HTTP or database run',
    findings: 'P0 0, P1 0, P2 3: quantity and tier not restored after a recovered purchase; the key of a join whose answer was lost reused after its entry finished; a reservation read answered after a context change applied to the new context',
    fixedIn: codeSha,
    reReview: 'pending',
  },
  results: {
    build: 'pass',
    typecheck: 'pass',
    lintErrors: 0,
    lintWarnings: 11,
    unitPassed: 223,
    unitSuites: 23,
    pollingTests: 63,
    integrationPassed: 346,
    integrationSkipped: 15,
    integrationSuitesPassed: 30,
    integrationSuitesSkipped: 2,
    harnessPassed: 29,
    callbackHarness: 'pass',
    mutationsKilled: 49,
    mutationsTotal: 49,
    checkPageTask21: '10/10',
    checkPageTask22CasesPassed: 4,
    servedFilesEqualCommittedBlobs: 10,
    pageTraces: traces.length,
    overlappingRequestsInPageTraces: overlapping,
    serverLogExtractsOfTheBrowser: extracts.filter((j) => j.agents === 'browser').length,
    overlappingRequestsInServerLogExtracts: extracts.filter((j) => j.agents === 'browser').reduce((sum, j) => sum + j.overlapping, 0),
    recognitionRecords: recognitions.length,
    finalSql: 'available + active reservation quantity + pending/paid/delivered order quantity = total (90 + 0 + 10 = 100); consumed results that do not match their target: 0',
  },
  scenarios: {
    s18: 'quantity 1, answers lost, reload, same request repeated: before the change the form kept quantity 2 and the checkout answered 409; after it the form shows 1 and the checkout answered 201',
    s19: 'join answer lost (and its browser repeat), entry read, cancelled, joined again: before the change the old key replayed the cancelled entry; after it a new entry was created',
    s20: 'reservation read held back 10 s at the proxy, event changed meanwhile: before the change the late answer put the reservation, tier and quantity of the first event on the second; after it nothing changed',
  },
  note: 'No credentials, env file, token or raw HAR are archived; the raw application logs are not archived.',
  files,
};
writeFileSync(join(out, `${NAME}.json`), `${JSON.stringify(manifest, null, 2)}\n`);
console.log(JSON.stringify({ files: files.length, zipBytes: statSync(zip).size, zipSha256: manifest.archiveSha256, traces: traces.length, overlapping, extracts: manifest.results.serverLogExtractsOfTheBrowser, recognitions: recognitions.length }, null, 1));
