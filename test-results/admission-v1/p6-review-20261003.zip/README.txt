Evidence of the external review follow-up of run peakpass-p6-20261003, code b9656ab317d344f2bedff3b49ecfb9638c77f7bb.
The first archive, p6-final-20261003.zip, holds the evidence up to code 02ee7e0.

evidence/  s18-* quantity after a recovered purchase, s19-* a join whose answer was lost, s20-* a reservation
           read answered after the event changed. *-before.* ran on ba39f2a before the change, the others
           after it; s19-join-key-run1.* ran before a redundant line was removed, s19-join-key.* on the commit.
           final.console.log, final-f*, a11y-*.json: the final check on the new code. final-02ee7e0/: the
           final check on the previous code (also in the first archive, under other names).
logs/      RED and GREEN of the join-key tests, the mutation check and the regression on the new code.
scripts/   the scripts used for these runs; not part of the source tree; no env file.
