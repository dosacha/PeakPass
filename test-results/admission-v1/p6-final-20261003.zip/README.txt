Evidence of run peakpass-p6-20261003, code 02ee7e025b31b5de39f942d4cfec1fc3e9432e74.
See docs/ISSUE_15_VALIDATION.md of the repository for what each scenario shows.

evidence/  page traces (*.trace.json), request lists without headers (*.requests.txt), extracts of the
           application's request log (*.applog*.json), proxy logs, audit results (a11y-*.json), console
           output of the final check (final.console.log) and of the review checks (s14–s17 *.console.log).
           final-d6a09c8/ and final-7c1d191/ are the final check on earlier commits; final-02ee7e0-run1/ is
           its first run on the final commit, before the pointer was moved away for the audits.
           s3d-* and final-d6a09c8/ were made with a recognition marker keyed by run, which was withdrawn:
           they contain one duplicate recognition and two false misses. *-before.* are runs made before a fix.
           *-run1.* are earlier runs of the same scenario.
logs/      baseline, RED and GREEN outputs of the unit test, mutation checks, the final regression,
           summaries.txt (every trace as text). The raw application logs are not included.
scripts/   the scripts of the run. They are not part of the source tree. No env file is included.
review/    the internal reviewer's probes of the polling script.
