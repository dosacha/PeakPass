// A local pass-through proxy that can lose one answer after the server produced it
// (run peakpass-p6-20261003). Not part of the source tree. It stands between the browser and
// the application for the "response lost after the commit" check: when the flag file exists,
// the next POST /reservations is forwarded, its complete upstream answer is read, and then the
// browser's socket is destroyed instead of answering. Everything else passes unchanged,
// including the CORS preflights. The flag file holds how many answers to lose (default 1):
// Chrome repeats a request once by itself when a reused connection closes without an answer,
// so losing two answers is what makes the page's own code see the loss.
//
// While the optional stall file exists, a status request (GET …/admissions/me) is held: it is
// not forwarded and never answered, which is a server that accepted the connection and then
// says nothing. The log records when the browser gave up on it.
//
// Usage: node proxy.mjs <listenPort> <targetPort> <flagFile> <logFile> [stallFile]
// The log holds time, method, path, upstream status and, for a reservation, its id. No header
// is logged.
import http from 'node:http';
import { appendFileSync, existsSync, readFileSync, unlinkSync, writeFileSync } from 'node:fs';

const [listen, target, flag, log, stall] = process.argv.slice(2);
const record = (entry) => appendFileSync(log, `${JSON.stringify({ at: new Date().toISOString(), ...entry })}\n`);

http
  .createServer((request, response) => {
    const chunks = [];
    request.on('data', (chunk) => chunks.push(chunk));
    request.on('end', () => {
      if (stall && request.method === 'GET' && request.url.endsWith('/admissions/me') && existsSync(stall)) {
        const held = Date.now();
        request.socket.once('close', () =>
          record({ method: 'GET', path: request.url, held: true, closedByBrowserAfterMs: Date.now() - held }),
        );
        return;
      }
      const lose = request.method === 'POST' && request.url === '/reservations' && existsSync(flag);
      if (lose) {
        const left = (Number(readFileSync(flag, 'utf8').trim()) || 1) - 1;
        if (left > 0) writeFileSync(flag, String(left));
        else unlinkSync(flag);
      }
      const upstream = http.request(
        { host: '127.0.0.1', port: target, method: request.method, path: request.url, headers: request.headers },
        (answer) => {
          const parts = [];
          answer.on('data', (part) => parts.push(part));
          answer.on('end', () => {
            const body = Buffer.concat(parts);
            let reservationId = null;
            if (request.url === '/reservations') {
              try {
                reservationId = JSON.parse(body.toString('utf8')).id ?? null;
              } catch {
                reservationId = null;
              }
            }
            record({
              method: request.method,
              path: request.url,
              upstreamStatus: answer.statusCode,
              answerLost: lose,
              ...(request.url === '/reservations' && request.method === 'POST' ? { reservationId } : {}),
            });
            if (lose) {
              request.socket.destroy();
              return;
            }
            response.writeHead(answer.statusCode, answer.headers);
            response.end(body);
          });
        },
      );
      upstream.on('error', () => {
        record({ method: request.method, path: request.url, upstreamStatus: null, answerLost: false });
        response.writeHead(502);
        response.end();
      });
      upstream.end(Buffer.concat(chunks));
    });
  })
  .listen(Number(listen), '127.0.0.1', () => record({ listening: Number(listen), target: Number(target) }));
