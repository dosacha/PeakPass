// Owned resources of the P6 task (run peakpass-p6-20261003). Not part of the source tree.
// Creates one PostgreSQL 16 container with two databases and two Redis 7 containers
// (AOF/RDB off, noeviction), all on Docker-chosen loopback ports and labelled for this task,
// and writes the env files next to this script. Nothing secret is printed.
import { execFileSync } from 'node:child_process';
import { randomBytes } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

const here = (name) => fileURLToPath(new URL(name, import.meta.url));
const label = 'peakpass.task=peakpass-p6-20261003';
const docker = (...args) => execFileSync('docker', args, { encoding: 'utf8' }).trim();
const exists = (name) => docker('ps', '-a', '--filter', `name=^${name}$`, '--format', '{{.Names}}') === name;
const pause = (ms) => Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
const port = (name, inner) => docker('port', name, `${inner}/tcp`).split('\n')[0].split(':').pop();

if (!existsSync(here('pg.env'))) {
  writeFileSync(
    here('pg.env'),
    `POSTGRES_USER=peakpass\nPOSTGRES_PASSWORD=${randomBytes(18).toString('base64url')}\nPOSTGRES_DB=peakpass_test\n`,
  );
}
const pgEnv = Object.fromEntries(
  readFileSync(here('pg.env'), 'utf8').trim().split('\n').map((line) => line.split(/=(.*)/s).slice(0, 2)),
);

if (!exists('peakpass-p6-pg')) {
  docker('run', '-d', '--name', 'peakpass-p6-pg', '--label', label, '--env-file', here('pg.env'),
    '-p', '127.0.0.1::5432', 'postgres:16-alpine');
}
for (const name of ['peakpass-p6-redis-test', 'peakpass-p6-redis-browser']) {
  if (!exists(name)) {
    docker('run', '-d', '--name', name, '--label', label, '-p', '127.0.0.1::6379', 'redis:7-alpine',
      'redis-server', '--save', '', '--appendonly', 'no', '--maxmemory', '256mb',
      '--maxmemory-policy', 'noeviction');
  }
}

for (let attempt = 0; ; attempt++) {
  try {
    docker('exec', 'peakpass-p6-pg', 'pg_isready', '-U', pgEnv.POSTGRES_USER, '-d', pgEnv.POSTGRES_DB);
    docker('exec', 'peakpass-p6-pg', 'psql', '-U', pgEnv.POSTGRES_USER, '-d', pgEnv.POSTGRES_DB, '-c', 'SELECT 1');
    break;
  } catch (error) {
    if (attempt > 60) throw new Error('PostgreSQL did not become ready');
    pause(500);
  }
}
const databases = docker('exec', 'peakpass-p6-pg', 'psql', '-U', pgEnv.POSTGRES_USER, '-d', pgEnv.POSTGRES_DB,
  '-Atc', 'SELECT datname FROM pg_database');
if (!databases.split('\n').includes('peakpass_browser')) {
  docker('exec', 'peakpass-p6-pg', 'psql', '-U', pgEnv.POSTGRES_USER, '-d', pgEnv.POSTGRES_DB,
    '-c', 'CREATE DATABASE peakpass_browser');
}

const common = [
  'DB_HOST=127.0.0.1',
  `DB_PORT=${port('peakpass-p6-pg', 5432)}`,
  `DB_USER=${pgEnv.POSTGRES_USER}`,
  `DB_PASSWORD=${pgEnv.POSTGRES_PASSWORD}`,
  'REDIS_HOST=127.0.0.1',
];
writeFileSync(here('test.env'), [
  ...common, 'DB_NAME=peakpass_test', `REDIS_PORT=${port('peakpass-p6-redis-test', 6379)}`, 'NODE_ENV=test', '',
].join('\n'));
const previous = existsSync(here('browser.env')) ? readFileSync(here('browser.env'), 'utf8') : '';
const secret = /^JWT_SECRET=(.+)$/m.exec(previous)?.[1] ?? randomBytes(36).toString('base64url');
writeFileSync(here('browser.env'), [
  ...common, 'DB_NAME=peakpass_browser', `REDIS_PORT=${port('peakpass-p6-redis-browser', 6379)}`,
  'NODE_ENV=development', 'LOG_LEVEL=info', `JWT_SECRET=${secret}`,
  'ENABLE_ADMISSION=true', 'ENABLE_DEMO_SESSION=true', '',
].join('\n'));

for (const name of ['peakpass-p6-redis-test', 'peakpass-p6-redis-browser']) {
  const config = ['save', 'appendonly', 'maxmemory-policy']
    .map((key) => docker('exec', name, 'redis-cli', 'CONFIG', 'GET', key).split('\n').join('='))
    .join(' ');
  console.log(`${name}: port ${port(name, 6379)} ${docker('exec', name, 'redis-cli', 'INFO', 'server').match(/redis_version:\S+/)[0]} ${config}`);
}
console.log(`peakpass-p6-pg: port ${port('peakpass-p6-pg', 5432)} ${docker('exec', 'peakpass-p6-pg', 'psql', '-U', pgEnv.POSTGRES_USER, '-d', pgEnv.POSTGRES_DB, '-Atc', 'SHOW server_version')}`);
