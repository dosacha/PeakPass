// Review scratch: scans the saved evidence for the numeric claims of docs/ISSUE_15_VALIDATION.md.
import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';

const EV = 'C:/Users/dosac/.claude/worktrees/peakpass-issue15/run/evidence';
const files = readdirSync(EV).filter((f) => f.endsWith('.trace.json')).sort();
const recs = [];
const missed = [];
let overlapsTotal = 0;
for (const f of files) {
  const trace = JSON.parse(readFileSync(join(EV, f), 'utf8'));
  const spans = trace.events
    .filter((e) => ['poll', 'join', 'cancel', 'purchase'].includes(e.type))
    .sort((a, b) => a.tSend - b.tSend);
  let overlaps = 0;
  for (let i = 1; i < spans.length; i += 1) if (spans[i].tSend < spans[i - 1].tRecv) overlaps += 1;
  overlapsTotal += overlaps;
  for (const e of trace.events) {
    if (e.type === 'recognition')
      recs.push({ f, run: trace.meta.runId, id: e.admissionId.slice(0, 8), layer: e.layer, lo: Math.round(e.lowerMs), hi: Math.round(e.upperMs), viaRecover: e.viaRecover, failuresBefore: e.failuresBefore });
    if (e.type === 'recognition-missed') missed.push({ f, id: e.admissionId.slice(0, 8), state: e.state, delta: e.serverDeltaMs });
  }
  if (overlaps) console.log(`OVERLAP ${f}: ${overlaps}`);
}
console.log(`trace files: ${files.length}, overlapping spans total: ${overlapsTotal}`);
console.log('recognitions:', recs.length);
for (const r of recs) console.log(`  ${r.f} run=${r.run} ${r.id} ${r.layer} [${r.lo}, ${r.hi}] viaRecover=${r.viaRecover} failuresBefore=${r.failuresBefore}`);
const fg = recs.filter((r) => r.layer === 'foreground');
console.log(`foreground: ${fg.length}, hidden: ${recs.filter((r) => r.layer === 'hidden').length}, reconnect: ${recs.filter((r) => r.layer === 'reconnect').length}`);
if (fg.length) {
  const min = fg.reduce((a, b) => (b.lo < a.lo ? b : a));
  const max = fg.reduce((a, b) => (b.hi > a.hi ? b : a));
  console.log(`foreground min [${min.lo}, ${min.hi}] (${min.f}), max [${max.lo}, ${max.hi}] (${max.f})`);
}
console.log('missed:', JSON.stringify(missed));

// F2: how long the page saw the entry admitted.
for (const name of ['final-f2.trace.json', 'run1-final-f2.trace.json']) {
  const trace = JSON.parse(readFileSync(join(EV, name), 'utf8'));
  const polls = trace.events.filter((e) => e.type === 'poll' && e.status === 200);
  const firstAdmitted = polls.find((p) => p.state === 'admitted');
  const lastAdmitted = [...polls].reverse().find((p) => p.state === 'admitted');
  const firstExpired = polls.find((p) => p.state === 'expired' && p.tSend > (firstAdmitted?.tSend ?? 0));
  const before = [...polls].reverse().find((p) => p.tSend < firstAdmitted.tSend);
  if (firstAdmitted && firstExpired)
    console.log(
      `${name}: admitted first seen tSend=${Math.round(firstAdmitted.tSend)} tRecv=${Math.round(firstAdmitted.tRecv)} (previous poll state=${before?.state} tRecv=${Math.round(before?.tRecv)}), ` +
        `last admitted tRecv=${Math.round(lastAdmitted.tRecv)}, expired tSend=${Math.round(firstExpired.tSend)} tRecv=${Math.round(firstExpired.tRecv)}; ` +
        `seen-admitted span lower=${((lastAdmitted.tSend - firstAdmitted.tRecv) / 1000).toFixed(1)} s upper=${((firstExpired.tRecv - before.tRecv) / 1000).toFixed(1)} s; ` +
        `firstAdmitted.tRecv..firstExpired.tRecv=${((firstExpired.tRecv - firstAdmitted.tRecv) / 1000).toFixed(1)} s; lastAdmitted.tSend..firstAdmitted.tSend=${((lastAdmitted.tSend - firstAdmitted.tSend) / 1000).toFixed(1)} s`,
    );
  const rec = trace.events.find((e) => e.type === 'recognition');
  if (rec) console.log(`  recognition serverDelta=${rec.serverDeltaMs} → promotion at local ≈ ${Math.round(rec.tSend - rec.serverDeltaMs)}..${Math.round(rec.tRecv - rec.serverDeltaMs)}; promotion..expired tRecv = ${((firstExpired.tRecv - (rec.tRecv - rec.serverDeltaMs)) / 1000).toFixed(1)}..${((firstExpired.tRecv - (rec.tSend - rec.serverDeltaMs)) / 1000).toFixed(1)} s`);
  const polls2 = trace.events.filter((e) => e.type === 'poll');
  const afterExpired = polls2.filter((p) => p.tSend > firstExpired.tSend);
  console.log(`  polls after the expired answer: ${afterExpired.length}; total polls ${polls2.length}; joins ${trace.events.filter((e) => e.type === 'join').length}`);
}

// S2 HAR
const har = JSON.parse(readFileSync(join(EV, 's2-fixed.har-reduced.json'), 'utf8'));
const { entries, ...harSummary } = har;
console.log('s2 har:', JSON.stringify(harSummary));

// S13: gaps between purchase attempts
const s13 = JSON.parse(readFileSync(join(EV, 's13-unconfirmed.trace.json'), 'utf8'));
const att = s13.events.filter((e) => e.type === 'purchase');
console.log('s13 purchase tSend:', att.map((a) => Math.round(a.tSend)).join(' '), 'gaps:', att.slice(1).map((a, i) => Math.round(a.tSend - att[i].tSend)).join(' '));
console.log('s13 unconfirmed → manual repeat:', Math.round(att[5].tSend - att[4].tRecv), 'ms');

// S5a: same entry before/after offline
const s5 = JSON.parse(readFileSync(join(EV, 's5a-offline.trace.json'), 'utf8'));
console.log('s5a poll admissionIds (trace has none; state only):', [...new Set(s5.events.filter((e) => e.type === 'poll').map((e) => e.state))].join(','));
