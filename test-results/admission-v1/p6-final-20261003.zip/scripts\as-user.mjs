// Queue requests of a seed user sent outside the browser (run peakpass-p6-20261003): another
// tab or device of the same user, as far as the server can tell. Not part of the source tree.
// The JWT is signed with the secret of the owned environment and never printed.
//
// Usage, from the worktree root with the browser environment exported:
//   node ../run/as-user.mjs <baseUrl> <email> status <eventId> [times]
//   node ../run/as-user.mjs <baseUrl> <email> cancel <eventId> <admissionId> <epoch>
import { createRequire } from 'node:module';

const require = createRequire(`${process.cwd()}/package.json`);
const { Client } = require('pg');
const jwt = require('jsonwebtoken');

const [base, email, action, eventId, a, b] = process.argv.slice(2);
const db = new Client({
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT),
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
});
await db.connect();
const userId = (await db.query('SELECT id FROM users WHERE email=$1', [email])).rows[0]?.id;
await db.end();
if (!userId) throw new Error(`no user ${email}`);
const headers = {
  Authorization: `Bearer ${jwt.sign({ sub: userId }, process.env.JWT_SECRET, { expiresIn: '5m' })}`,
  'Content-Type': 'application/json',
};
const path = `${base}/events/${eventId}/admissions`;

if (action === 'status') {
  const times = Number(a ?? 1);
  const answers = await Promise.all(
    Array.from({ length: times }, () => fetch(`${path}/me`, { headers }).then((r) => r.status)),
  );
  const tally = {};
  for (const status of answers) tally[status] = (tally[status] ?? 0) + 1;
  console.log(JSON.stringify({ at: new Date().toISOString(), user: userId.slice(0, 8), action, times, tally }));
} else if (action === 'cancel') {
  const response = await fetch(`${path}/${a}`, { method: 'DELETE', headers, body: JSON.stringify({ epoch: b }) });
  const body = await response.json().catch(() => null);
  console.log(
    JSON.stringify({
      at: new Date().toISOString(),
      user: userId.slice(0, 8),
      action,
      admissionId: a,
      status: response.status,
      code: body?.error?.code ?? null,
      state: body?.admission?.state ?? null,
    }),
  );
} else {
  throw new Error('unknown action');
}
