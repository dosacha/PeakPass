// Activation and release of a protected event for the P6 browser checks (run peakpass-p6-20261003).
// Not part of the source tree. It performs the contract's explicit transition, the same one the
// P5 fixture `setProtected` performs: in one transaction take the exclusive event gate through
// the repository's own `readAdmissionPolicy(client, eventId, 'exclusive')`, then UPDATE
// admission_events. An instance with the feature on converges within a tick.
//
// Usage, from the worktree root with the browser environment exported:
//   npx tsx ../run/protect.ts <eventId> true|false
import { loadConfig } from '../PeakPass/src/infra/config';
import { initLogger } from '../PeakPass/src/infra/logger';
import {
  closePostgresPool,
  initPostgresPool,
  serializableTransactionWithRetry,
} from '../PeakPass/src/infra/postgres/client';
import { readAdmissionPolicy } from '../PeakPass/src/infra/postgres/admission-policy';

async function main() {
  const [eventId, value] = process.argv.slice(2);
  if (!/^[0-9a-f-]{36}$/.test(eventId ?? '') || !['true', 'false'].includes(value)) {
    throw new Error('usage: protect.ts <eventId> true|false');
  }
  loadConfig();
  initLogger();
  await initPostgresPool();
  const policy = await serializableTransactionWithRetry(async (client) => {
    await readAdmissionPolicy(client, eventId, 'exclusive');
    const updated = await client.query(
      `UPDATE admission_events SET protected=$2 WHERE event_id=$1
       RETURNING protected, generation::text, epoch::text, phase`,
      [eventId, value === 'true'],
    );
    return updated.rows[0];
  });
  console.log(JSON.stringify({ eventId, ...policy }));
  await closePostgresPool();
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
