// Review scratch: does anything observe a purchase re-sent by a disposed controller?
// Runs the real script (control) and an in-memory mutant without the purchase-timer clearing in
// dispose(). The source file on disk is not touched.
const vm = require('node:vm');
const fs = require('node:fs');
const SRC = fs.readFileSync('C:/Users/dosac/.claude/worktrees/peakpass-issue15/PeakPass/frontend/admission-polling.js', 'utf8');
const LINE = '      if (purchase && purchase.timer !== null) clearTimer(purchase.timer);\n';
if (!SRC.includes(LINE)) throw new Error('mutation target not found');

function load(source) {
  const ctx = vm.createContext({});
  vm.runInContext(source, ctx, { filename: 'admission-polling.js' });
  return ctx.PeakPassAdmission;
}
const EVENT = 'eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee';
const USER = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
const EPOCH = '11111111-1111-4111-8111-111111111111';
const T0 = Date.UTC(2026, 9, 3);
const iso = (ms) => new Date(ms).toISOString();

async function run(api, label) {
  let now = 0, seq = 0;
  const timers = new Map();
  const purchases = [], results = [], views = [];
  const admitted = { admissionId: 'a0000000-0000-4000-8000-000000000001', epoch: EPOCH, state: 'admitted', phase: 'idle', sequence: '1', position: null, joinedAt: iso(T0), admittedAt: iso(T0), expiresAt: iso(T0 + 30000), reason: null, outcome: null };
  const controller = api.createController({
    userId: USER, eventId: EVENT, mode: 'fixed',
    transport: () => Promise.resolve({ status: 200, data: { contractRevision: 'admission-v1', serverTime: iso(T0 + now), queue: { eventId: EVENT, epoch: EPOCH, mode: 'open' }, admission: admitted, nextPollAfterMs: 1000 } }),
    sendPurchase(body) { purchases.push({ at: now, body }); return Promise.resolve(purchases.length === 1 ? { status: 0 } : { status: 201, data: { id: 'r-1' } }); },
    onPurchaseResult: (r) => results.push({ at: now, ...r }),
    onChange: (v) => views.push(v), onTrace: () => {},
    now: () => now, setTimer(run, ms) { timers.set(++seq, { at: now + ms, run }); return seq; }, clearTimer: (id) => timers.delete(id),
    random: () => 0.5, uuid: () => 'k', AbortController,
    visibility: { hidden: () => false, subscribe: () => () => {} },
  });
  const flush = () => new Promise((r) => setImmediate(r));
  const advance = async (ms) => { const end = now + ms; await flush(); for (;;) { const due = [...timers.entries()].filter(([, t]) => t.at <= end).sort((a, b) => a[1].at - b[1].at)[0]; if (!due) break; timers.delete(due[0]); now = due[1].at; due[1].run(); await flush(); } now = end; };
  controller.start(); await flush();
  controller.purchase({ eventId: EVENT, userId: USER, quantity: 1, tierId: 'g', admissionId: admitted.admissionId, admissionEpoch: EPOCH });
  await advance(200); // attempt 1 failed at once; retry timer due at 1000
  controller.dispose();
  const viewsAtDispose = views.length;
  await advance(5000);
  console.log(`${label}: purchases after dispose = ${purchases.filter((p) => p.at > 200).length}, onPurchaseResult calls after dispose = ${results.filter((r) => r.at > 200).length}, onChange calls after dispose = ${views.length - viewsAtDispose}, timers left = ${timers.size}`);
}

(async () => {
  await run(load(SRC), 'control (real file)');
  await run(load(SRC.replace(LINE, '')), 'mutant (dispose keeps the purchase timer)');
})();
