// Review scratch: drives frontend/admission-polling.js with a fake clock/transport through
// sequences the unit test does not cover, and prints what happens. No assertions: read the output.
// Loaded through vm exactly like the unit test (the package is ESM, so require() gives an empty namespace).
const vm = require('node:vm');
const fs = require('node:fs');
const ctx = vm.createContext({});
vm.runInContext(fs.readFileSync('C:/Users/dosac/.claude/worktrees/peakpass-issue15/PeakPass/frontend/admission-polling.js', 'utf8'), ctx, { filename: 'admission-polling.js' });
const api = ctx.PeakPassAdmission;

const EVENT = 'eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee';
const USER = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
const EPOCH = '11111111-1111-4111-8111-111111111111';
const T0 = Date.UTC(2026, 9, 3);
const iso = (ms) => new Date(ms).toISOString();

function tab(overrides = {}) {
  let now = 0, seq = 0, hidden = false, keys = 0;
  const timers = new Map();
  const listeners = new Set();
  const calls = [], purchases = [], traces = [], views = [], results = [];
  let respond = () => ({ status: 0 });
  let respondPurchase = () => ({ status: 0 });
  const pending = overrides.pending || (() => { const m = new Map(); return { get: (k) => m.get(k) ?? null, set: (k, v) => m.set(k, v), remove: (k) => m.delete(k), size: () => m.size }; })();
  const controller = api.createController({
    userId: USER, eventId: EVENT, mode: 'fixed',
    transport(req) { const c = { ...req, at: now }; calls.push(c); return Promise.resolve(respond(c)); },
    sendPurchase(body, signal) { const p = { body, signal, at: now }; purchases.push(p); return Promise.resolve(respondPurchase(p)); },
    onPurchaseResult: (r) => results.push(r),
    pending, seen: overrides.seen,
    onChange: (v) => views.push(v), onTrace: (e) => traces.push(e),
    wall: () => T0 + now, now: () => now,
    setTimer(run, ms) { timers.set(++seq, { at: now + ms, run }); return seq; },
    clearTimer: (id) => timers.delete(id),
    random: () => 0.5, uuid: () => `key-${++keys}`, AbortController,
    visibility: { hidden: () => hidden, subscribe(l) { listeners.add(l); return () => listeners.delete(l); } },
    ...overrides.options,
  });
  const flush = () => new Promise((r) => setImmediate(r));
  return {
    controller, calls, purchases, traces, views, results, pending, flush,
    now: () => now,
    onRequest: (h) => { respond = h; },
    onPurchase: (h) => { respondPurchase = h; },
    ok(admission, nextPollAfterMs, epoch = EPOCH) {
      return { status: 200, data: { contractRevision: 'admission-v1', serverTime: iso(T0 + now), queue: { eventId: EVENT, epoch, mode: 'open' }, admission, nextPollAfterMs } };
    },
    setHidden(v) { hidden = v; for (const l of [...listeners]) l(); },
    async advance(ms) {
      const end = now + ms; await flush();
      for (;;) {
        const due = [...timers.entries()].filter(([, t]) => t.at <= end).sort((a, b) => a[1].at - b[1].at || a[0] - b[0])[0];
        if (!due) break;
        timers.delete(due[0]); now = Math.max(now, due[1].at); due[1].run(); await flush();
      }
      now = end;
    },
    times: () => calls.map((c) => `${c.method}@${c.at}`),
    traced: (type) => traces.filter((e) => e.type === type),
  };
}
const entry = (state, patch = {}) => ({ admissionId: 'a0000000-0000-4000-8000-000000000001', epoch: EPOCH, state, phase: 'idle', sequence: '21', position: state === 'waiting' ? 21 : null, joinedAt: iso(T0), admittedAt: null, expiresAt: null, reason: null, outcome: null, ...patch });
const failure = (status, code, nextPollAfterMs = null) => ({ status, data: { error: { code, message: code }, nextPollAfterMs } });

(async () => {
  // P1: failure while hidden stretches the retry to 15 s, but notBefore keeps the short backoff:
  // a return before the stretched due sends one request.
  {
    const t = tab();
    t.onRequest(() => (t.calls.length === 2 ? { status: 0 } : t.ok(entry('waiting'), 5000)));
    t.controller.start(); await t.advance(1000); // poll#2 at 1000 fails → notBefore 2000, retry at 2000
    t.setHidden(true); await t.advance(1500); // hidden at 1000 → retry stretched to 16000
    t.setHidden(false); await t.advance(10);
    console.log('P1 times', t.times(), 'notBefore passed → return poll at', t.calls[2]?.at, 'problem', JSON.stringify(t.controller.view().problem));
  }
  // P2: join answered 429 QUEUE_FULL with wait 1000
  {
    const t = tab();
    let posts = 0;
    t.onRequest((c) => (c.method === 'POST' ? (posts += 1, failure(429, 'ADMISSION_QUEUE_FULL', 1000)) : t.ok(null, null)));
    t.controller.start(); await t.flush();
    console.log('P2 join', t.controller.join()); await t.flush();
    console.log('P2 view', JSON.stringify({ phase: t.controller.view().phase, notice: t.controller.view().notice, problem: t.controller.view().problem }));
    await t.advance(1000);
    console.log('P2 times', t.times(), 'join again', t.controller.join()); await t.flush();
    console.log('P2 keys', t.calls.filter((c) => c.method === 'POST').map((c) => c.body.joinRequestId));
  }
  // P3: first sight of a consumed entry with admittedAt → recognition-missed with state consumed
  {
    const t = tab();
    t.onRequest(() => t.ok(entry('consumed', { admittedAt: iso(T0 - 5000), outcome: { kind: 'reservation', resourceId: 'r', code: null } }), null));
    t.controller.start(); await t.flush();
    console.log('P3 missed', JSON.stringify(t.traced('recognition-missed').map((e) => ({ state: e.state, delta: e.serverDeltaMs }))));
  }
  // P4: restored pending purchase, entry admitted: what is allowed
  {
    const first = tab();
    first.onRequest(() => first.ok(entry('admitted', { admittedAt: iso(T0), expiresAt: iso(T0 + 30000) }), 1000));
    first.onPurchase(() => new Promise(() => {}));
    first.controller.start(); await first.flush();
    first.controller.purchase({ eventId: EVENT, userId: USER, quantity: 1, tierId: 'g', admissionId: 'a0000000-0000-4000-8000-000000000001', admissionEpoch: EPOCH });
    await first.flush(); first.controller.dispose();
    const t = tab({ pending: first.pending });
    t.onRequest(() => t.ok(entry('admitted', { admittedAt: iso(T0), expiresAt: iso(T0 + 30000) }), 1000));
    t.controller.start(); await t.flush();
    console.log('P4 restored', JSON.stringify(t.controller.view().purchase), 'join', t.controller.join(), 'cancel', t.controller.cancel(), 'purchase', t.controller.purchase({ x: 1 }), 'retry', t.controller.retryPurchase());
    await t.flush(); console.log('P4 sent body', JSON.stringify(t.purchases[0]?.body));
  }
  // P5: a status 401 → polling stops; a return sends one request each time
  {
    const t = tab();
    t.onRequest(() => failure(401, 'UNAUTHENTICATED'));
    t.controller.start(); await t.advance(1000);
    t.setHidden(true); t.setHidden(false); await t.advance(1000);
    t.setHidden(true); t.setHidden(false); await t.advance(1000);
    console.log('P5 times', t.times(), 'problem', t.controller.view().problem?.kind, 'phase', t.controller.view().phase);
  }
  // P6: a 400 invalid → same
  {
    const t = tab();
    t.onRequest(() => failure(400, 'ADMISSION_INVALID_INPUT'));
    t.controller.start(); await t.advance(1000);
    t.setHidden(true); t.setHidden(false); await t.advance(1000);
    console.log('P6 times', t.times());
  }
  // P7: purchase result arrives during a status backoff while hidden → refresh scheduled at notBefore (< 15 s)
  {
    const t = tab();
    const answer = { resolve: null, promise: null }; answer.promise = new Promise((r) => (answer.resolve = r));
    t.onRequest(() => (t.calls.length === 2 ? failure(503, 'ADMISSION_UNAVAILABLE', 1000) : t.ok(entry('admitted', { admittedAt: iso(T0), expiresAt: iso(T0 + 30000) }), 1000)));
    t.onPurchase(() => answer.promise);
    t.controller.start(); await t.advance(1000); // poll #2 → 503 → notBefore 2000
    console.log('P7 purchase', t.controller.purchase({ a: 1 })); await t.advance(200);
    t.setHidden(true); answer.resolve({ status: 201, data: { id: 'r' } }); await t.advance(0);
    console.log('P7 after result at', t.now(), 'times', t.times());
    await t.advance(1000); console.log('P7 after +1000 (hidden)', t.times());
  }
  // P8: a GET answered with a new epoch while this tab is admitted (not waiting)
  {
    const t = tab();
    t.onRequest(() => (t.calls.length === 1 ? t.ok(entry('admitted', { admittedAt: iso(T0), expiresAt: iso(T0 + 30000) }), 1000) : t.ok(null, null, '22222222-2222-4222-8222-222222222222')));
    t.controller.start(); await t.advance(1000);
    console.log('P8 phase', t.controller.view().phase, 'deadlineAt', t.controller.view().deadlineAt, 'joinable', t.controller.join());
  }
  // P9: the trace is volatile, the marker durable: recognition in page 1, page 2 (same marker) records nothing
  {
    const seen = (() => { const s = new Set(); return { has: (k) => s.has(k), add: (k) => s.add(k) }; })();
    const a = tab({ seen });
    a.onRequest(() => a.ok(entry('admitted', { admittedAt: iso(T0), expiresAt: iso(T0 + 30000) }), 1000));
    a.controller.start(); await a.flush(); a.controller.dispose();
    const b = tab({ seen });
    b.onRequest(() => b.ok(entry('admitted', { admittedAt: iso(T0), expiresAt: iso(T0 + 30000) }), 1000));
    b.controller.start(); await b.flush();
    console.log('P9 page1 recognitions', a.traced('recognition').length, 'page2 recognitions', b.traced('recognition').length, 'missed', b.traced('recognition-missed').length);
  }
  // P10: hidden tab, timer poll fails once with 429 asking 2000 ms → notBefore uses hidden 15 s?
  {
    const t = tab();
    t.onRequest(() => (t.calls.length === 2 ? failure(429, 'ADMISSION_RATE_LIMITED', 2000) : t.ok(entry('waiting'), 1000)));
    t.controller.start(); await t.advance(500); t.setHidden(true); await t.advance(14500);
    console.log('P10 after hidden poll at', t.calls[1]?.at, 'problem.retryAt', t.controller.view().problem?.retryAt);
    t.setHidden(false); await t.advance(0); console.log('P10 return at 15000 → times', t.times());
    await t.advance(15000); console.log('P10 +15 s', t.times());
  }
  // P11: cancel of an admitted entry; the answer is for the same id → accepted
  {
    const t = tab();
    t.onRequest((c) => (c.method === 'DELETE' ? t.ok(entry('cancelled', { reason: 'ADMISSION_CANCELLED' }), null) : t.ok(entry('admitted', { admittedAt: iso(T0), expiresAt: iso(T0 + 30000) }), 1000)));
    t.controller.start(); await t.flush();
    console.log('P11 cancel', t.controller.cancel()); await t.flush();
    console.log('P11 phase', t.controller.view().phase, 'recognitions', t.traced('recognition').length, 'missed', t.traced('recognition-missed').length);
  }
  // P12: deadline + recognition when serverTime is older than admittedAt (clock skew between app processes)
  {
    const t = tab();
    t.onRequest(() => ({ status: 200, data: { contractRevision: 'admission-v1', serverTime: iso(T0 + 100), queue: { eventId: EVENT, epoch: EPOCH, mode: 'open' }, admission: entry('admitted', { admittedAt: iso(T0 + 400), expiresAt: iso(T0 + 30400) }), nextPollAfterMs: 1000 } }));
    t.controller.start(); await t.flush();
    const r = t.traced('recognition')[0];
    console.log('P12 serverDelta', r?.serverDeltaMs, 'lower', r?.lowerMs, 'upper', r?.upperMs, 'deadlineAt', t.controller.view().deadlineAt);
  }
})();
