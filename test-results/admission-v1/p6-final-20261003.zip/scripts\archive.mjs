// Builds the evidence archive and its manifest of the P6 run (peakpass-p6-20261003). Not part of
// the source tree. Run from the run directory: node archive.mjs <codeSha>
// It stages the files, refuses anything that looks like a credential, zips the stage with
// PowerShell and writes the manifest and the ZIP into the worktree's test-results folder.
import { createHash } from 'node:crypto';
import { cpSync, existsSync, mkdirSync, readFileSync, readdirSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { execFileSync, spawnSync } from 'node:child_process';
import { join, relative, sep } from 'node:path';

const codeSha = process.argv[2];
if (!/^[0-9a-f]{40}$/.test(codeSha ?? '')) throw new Error('usage: node archive.mjs <codeSha>');
const RUN = process.cwd();
const REPO = join(RUN, '..', 'PeakPass');
const NAME = 'p6-final-20261003';
const stage = join(RUN, 'archive', NAME);
const out = join(REPO, 'test-results', 'admission-v1');

const walk = (dir) =>
  readdirSync(dir).flatMap((name) => {
    const path = join(dir, name);
    return statSync(path).isDirectory() ? walk(path) : [path];
  });
const posix = (path) => path.split(sep).join('/');

// What every page trace shows, as text.
const traces = walk(join(RUN, 'evidence')).filter((file) => file.endsWith('.trace.json')).sort();
const summaries = traces
  .map((file) => {
    const run = spawnSync(process.execPath, [join(RUN, 'summary.mjs'), file], { encoding: 'utf8' });
    return `=== ${posix(relative(RUN, file))}\n${run.stdout}`;
  })
  .join('');
writeFileSync(join(RUN, 'logs', 'summaries.txt'), summaries);

rmSync(join(RUN, 'archive'), { recursive: true, force: true });
mkdirSync(stage, { recursive: true });
cpSync(join(RUN, 'evidence'), join(stage, 'evidence'), { recursive: true });
mkdirSync(join(stage, 'logs'));
const logs = readdirSync(join(RUN, 'logs')).filter((name) =>
  /^(baseline-|red-|green-|mutation-|final-|task5-unit|task6-unit|review-unit|summaries|browser-migrate|browser-seed|test-migrate|fillers-ui|app-a-off)/.test(name),
);
for (const name of logs) cpSync(join(RUN, 'logs', name), join(stage, 'logs', name));
mkdirSync(join(stage, 'scripts'));
for (const name of ['setup.mjs', 'protect.ts', 'fillers.mjs', 'as-user.mjs', 'lib.sh', 'helpers.sh', 'final.sh', 'review-fix.sh', 'summary.mjs', 'applog.mjs', 'har-check.mjs', 'app.sh', 'proxy.mjs', 'mutate.mjs', 'archive.mjs'])
  cpSync(join(RUN, name), join(stage, 'scripts', name));
cpSync(join(RUN, 'review-scratch'), join(stage, 'review'), { recursive: true });
writeFileSync(
  join(stage, 'README.txt'),
  [
    `Evidence of run peakpass-p6-20261003, code ${codeSha}.`,
    'See docs/ISSUE_15_VALIDATION.md of the repository for what each scenario shows.',
    '',
    'evidence/  page traces (*.trace.json), request lists without headers (*.requests.txt), extracts of the',
    "           application's request log (*.applog*.json), proxy logs, audit results (a11y-*.json), console",
    '           output of the final check (final.console.log) and of the review checks (s14–s17 *.console.log).',
    '           final-d6a09c8/ and final-7c1d191/ are the final check on earlier commits; final-02ee7e0-run1/ is',
    '           its first run on the final commit, before the pointer was moved away for the audits.',
    '           s3d-* and final-d6a09c8/ were made with a recognition marker keyed by run, which was withdrawn:',
    '           they contain one duplicate recognition and two false misses. *-before.* are runs made before a fix.',
    '           *-run1.* are earlier runs of the same scenario.',
    'logs/      baseline, RED and GREEN outputs of the unit test, mutation checks, the final regression,',
    '           summaries.txt (every trace as text). The raw application logs are not included.',
    'scripts/   the scripts of the run. They are not part of the source tree. No env file is included.',
    "review/    the internal reviewer's probes of the polling script.",
    '',
  ].join('\n'),
);

// Nothing that looks like a credential may be archived.
const suspicious = [
  /eyJ[A-Za-z0-9_-]{10,}/,
  /Bearer [A-Za-z0-9._-]{12,}/,
  /:\/\/[^/\s:@]+:[^@\s/]+@/,
  /(JWT_SECRET|DB_PASSWORD|POSTGRES_PASSWORD|REDIS_PASSWORD)=[A-Za-z0-9_\-+/]{8,}/,
];
const staged = walk(stage).sort();
const hits = staged.filter((file) => {
  if (/\.(png|zip)$/.test(file)) return false;
  const text = readFileSync(file, 'utf8');
  return suspicious.some((pattern) => pattern.test(text));
});
if (hits.length) throw new Error(`credential-like text in: ${hits.map((file) => relative(stage, file)).join(', ')}`);
if (staged.some((file) => /\.env$|\.har$/.test(file))) throw new Error('an env file or a raw HAR is staged');

const sha = (buffer) => createHash('sha256').update(buffer).digest('hex');
const files = staged.map((file) => {
  const data = readFileSync(file);
  return { name: posix(relative(stage, file)), bytes: data.length, sha256: sha(data) };
});

mkdirSync(out, { recursive: true });
const zip = join(out, `${NAME}.zip`);
rmSync(zip, { force: true });
execFileSync('powershell.exe', ['-NoProfile', '-Command', `Compress-Archive -Path '${stage}\\*' -DestinationPath '${zip}' -CompressionLevel Optimal`], { stdio: 'inherit' });

// Figures taken from the files themselves.
const events = traces.map((file) => JSON.parse(readFileSync(file, 'utf8')).events);
let overlapping = 0;
for (const list of events) {
  const spans = list.filter((e) => ['poll', 'join', 'cancel', 'purchase'].includes(e.type)).sort((a, b) => a.tSend - b.tSend);
  for (let i = 1; i < spans.length; i += 1) if (spans[i].tSend < spans[i - 1].tRecv) overlapping += 1;
}
const recognitions = events.flat().filter((e) => e.type === 'recognition');
const layer = (name) => recognitions.filter((e) => e.layer === name).map((e) => [Math.round(e.lowerMs), Math.round(e.upperMs)]).sort((a, b) => a[0] - b[0]);
const extracts = walk(join(RUN, 'evidence')).filter((file) => /\.applog[^/\\]*\.json$/.test(file));
const browserExtracts = extracts.map((file) => JSON.parse(readFileSync(file, 'utf8'))).filter((j) => j.agents === 'browser');
const p5 = JSON.parse(readFileSync(join(out, 'p5-final-20261002.json'), 'utf8'));

const manifest = {
  runId: 'peakpass-p6-20261003',
  codeSha,
  baseSha: '2d67cc3c10a1d04bebe0a7a81f9575ea39e63363',
  contract: { revision: 'admission-v1', sha256: 'e22be4df9910811eba552f630b43170ba0cf0c8d953a54dc5a3cea34c0dcf3d1' },
  archive: `${NAME}.zip`,
  archiveSha256: sha(readFileSync(zip)),
  environment: {
    host: 'Windows, Node 24.15.0',
    postgres: '16.12',
    redis: '7.4.8, save "", appendonly no, noeviction, 256MiB; one instance for the integration suite and one for the browser checks',
    browser: 'headless Chrome 154 driven by agent-browser 0.38.2; frontend served by python -m http.server, cross-origin to the API',
    label: 'peakpass.task=peakpass-p6-20261003',
  },
  results: {
    build: 'pass',
    typecheck: 'pass',
    lintErrors: 0,
    lintWarnings: 11,
    unitPassed: 220,
    unitSuites: 23,
    unitNewTests: 60,
    integrationPassed: 346,
    integrationSkipped: 15,
    integrationSuitesPassed: 30,
    integrationSuitesSkipped: 2,
    integrationRunsAtCodeSha: 2,
    harnessPassed: 29,
    callbackHarness: 'pass',
    mutationsKilled: 48,
    mutationsTotal: 48,
    checkPageTask21: '10/10',
    checkPageTask22CasesPassed: 4,
    servedFilesEqualCommittedBlobs: 10,
    pageTraces: traces.length,
    overlappingRequestsInPageTraces: overlapping,
    serverLogExtractsOfTheBrowser: browserExtracts.length,
    overlappingRequestsInServerLogExtracts: browserExtracts.reduce((sum, j) => sum + j.overlapping, 0),
    finalSql: 'available + active reservation quantity + pending/paid/delivered order quantity = total; consumed results that do not match their target: 0',
  },
  recognitionRecords: {
    note: 'single observations of local runs; not a recognition-delay result. s3d-* and final-d6a09c8/ contain artefacts of a withdrawn marker key: one duplicate under reconnect and two false misses',
    foreground: { count: layer('foreground').length, lowest: layer('foreground')[0], highest: layer('foreground').at(-1) },
    hidden: layer('hidden'),
    reconnect: layer('reconnect'),
    missed: events.flat().filter((e) => e.type === 'recognition-missed').map((e) => ({ state: e.state, serverDeltaMs: e.serverDeltaMs })),
  },
  baseline: { sha: '2d67cc3c10a1d04bebe0a7a81f9575ea39e63363', build: 'pass', typecheck: 'pass', lintErrors: 0, lintWarnings: 11, unitPassed: 160, unitSuites: 22 },
  accessibility: {
    engine: 'axe-core 4.12.1, WCAG 2 A and AA rules, light theme',
    cardStates: {
      waiting: ['.field-label 4.38:1'],
      confirmationOpen: ['.field-label 4.38:1', '.btn-danger 3.88:1'],
      admitted: ['.field-label 4.38:1'],
      finished: ['.field-label 4.38:1', '.btn-accent 4.24:1'],
    },
    step3UnconfirmedLabel: 'no violation (info pill); the existing warn pill measured 4.43:1 and is not used by the new labels',
    note: 'all findings are colour contrast on classes and colours of the existing stylesheet; no screen reader was run',
  },
  review: {
    kind: 'internal, not independent',
    reviewer: 'read-only subagent of the implementing session; the identifiers of reviewer and implementer are in the hand-off report, not in this repository',
    mode: 'read-only static, plus the polling unit file and its own probes of the script from a scratch directory outside the repository; it also compared the validation document with the saved evidence',
    target: '2d67cc3c10a1d04bebe0a7a81f9575ea39e63363..545f3f5',
    findings: 'five, graded Minor by the reviewer; two regraded Important by effect (a failure in a hidden tab held back the request on return; step 3 stayed running after the event was changed during an unanswered purchase)',
    fixedIn: codeSha,
    deferred: 'the recognition marker is durable while the trace is in memory: a recognition whose page is reloaded before the trace was read is lost (documented as a precondition for P8)',
    notReviewed: codeSha,
    independentTestExecution: false,
  },
  skippedTests: p5.skippedTests.map((name) => name.replace(/ \(passed separately[^)]*\)/, '')),
  skippedTestsNote:
    "the verbose run names three of them; the other twelve are the tests of the two suites skipped as a whole (redis-recovery, order-sweeper-docker). The names are those of the stored P5 manifest. The Docker cases and the production image checks were not run in P6: the image takes nothing from frontend/ and the build excludes test files",
  note: 'Evidence kinds: real is headless Chrome against a listening application with owned PostgreSQL and Redis; runnable check is the unit test with an injected clock, transport and visibility; synthetic stimulus is something done to the real system from outside the page (waiting users over HTTP, a status flood, a deleted Redis control key, an instance swap, offline emulation, a proxy that holds a request or loses an answer). No credentials, env file, token or raw HAR are archived; the raw application logs are not archived.',
  files,
};
writeFileSync(join(out, `${NAME}.json`), `${JSON.stringify(manifest, null, 2)}\n`);
console.log(JSON.stringify({ files: files.length, zipBytes: statSync(zip).size, zipSha256: manifest.archiveSha256, traces: traces.length, overlapping, browserExtracts: browserExtracts.length, recognition: manifest.recognitionRecords }, null, 1));
