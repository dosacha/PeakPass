// Mutation check of the P6 polling script: each branch is changed in turn and the named test
// must fail. Run from the worktree root. The source is restored after every mutation and
// compared with the original at the end. Not part of the source tree.
import { readFileSync, writeFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';

const target = 'frontend/admission-polling.js';
const test = 'src/tests/unit/admission-polling.test.ts';
const original = readFileSync(target, 'utf8');
const only = process.argv[2];

// [name, find, replace, test name, replace every occurrence?]
const all = [
  ['late response guard', '      const finish = (response) => {\n        if (flight !== entry) return;\n', '      const finish = (response) => {\n', 'ignores that request when it answers late'],
  ['one request in flight', 'flight || ', '', 'sends no second request when the tab returns while one is in flight', true],
  // The check in poll() and the check on a visibility return each cover the other, so removing
  // one alone changes nothing. The mutation disables both through the predicate they share.
  ['polling paused during a purchase', 'const purchasing = () => purchase !== null && purchase.status !== "unconfirmed";', 'const purchasing = () => false;', 'sends no status request while a purchase is open'],
  ['error wait kept on return', '      if (notBefore > now()) {\n        if (pollTimer !== null && pollDue > notBefore) {', '      if (false) {\n        if (pollTimer !== null && pollDue > notBefore) {', 'sends nothing inside a wait the server asked for'],
  ['wait of a failure excludes the hidden interval', 'const wait = failureDelay(Object.assign({ hidden: false }, asked));', 'const wait = failureDelay(Object.assign({ hidden: visibility.hidden() }, asked));', 'sends the one request on return after a hidden poll failed'],
  ['hidden retry keeps the hidden interval', 'const delay = failureDelay(Object.assign({ hidden: visibility.hidden() }, asked));', 'const delay = wait;', 'retries a failed hidden poll no sooner than 15 s'],
  ['retry moves back to the end of the wait on return', '          schedule(notBefore - now(), pollReason, plan);\n', '', 'retries at the end of the wait, not after the hidden interval'],
  ['planned delay of the moved retry', 'const plan = pollPlan && Object.assign({}, pollPlan, { delayMs: Math.round(notBefore - lastDone) });', 'const plan = pollPlan;', 'retries at the end of the wait, not after the hidden interval'],
  ['dispose ends the purchase retries', '      if (purchase && purchase.timer !== null) clearTimer(purchase.timer);\n', '', 'disposed between two attempts of a purchase'],
  ['no probe of an event without a queue', ' || phase === "not-enabled"', '', 'never probes an event without a queue'],
  ['hidden interval', '    if (hidden) return POLICY.hiddenMs;\n', '', 'a hidden tab waits 15000 ms'],
  ['fixed interval', '    if (mode === "fixed") return POLICY.fixedMs;\n', '', 'fixed mode waits 1000 ms'],
  ['adaptive clamp', 'Math.round(Math.min(POLICY.maxMs, Math.max(POLICY.minMs, jittered(base, u))))', 'Math.round(jittered(base, u))', 'adaptive mode applies'],
  ['server minimum', 'positive(serverMinMs), ', '', 'the server minimum and Retry-After win'],
  ['Retry-After', ', positive(retryAfterMs)),', '),', 'the server minimum and Retry-After win'],
  ['backoff cap', 'const backoff = Math.min(POLICY.backoffCapMs, jittered(step, u));', 'const backoff = jittered(step, u);', 'failures back off 1, 2, 4, 8 and 15 s'],
  ['failures reset by a success', '      failures = 0;\n      notBefore = 0;', '      notBefore = 0;', 'escalates consecutive failures to 15 s and starts over'],
  ['timeout aborts', '        abort.abort();\n        finish(TIMED_OUT);', '        finish(TIMED_OUT);', 'aborts a request without an answer after 5 s'],
  ['404 ends polling', '      else if (status === 404) unqueued();\n', '', 'stops polling an event without a queue'],
  ['admission of the queue epoch', '(typeof admission === "object" && admission.epoch === queue.epoch)', 'typeof admission === "object"', 'not of the queue epoch'],
  ['hidden stretches a pending poll', 'const due = Math.max(pollDue, lastDone + POLICY.hiddenMs);', 'const due = pollDue;', 'polls a hidden tab every 15 s'],
  ['hidden delay recorded', 'const plan = pollPlan && Object.assign({}, pollPlan, { delayMs: Math.round(due - lastDone) });', 'const plan = pollPlan;', 'moved out to the hidden interval'],
  ['planned delay recorded', 'schedule(delayMs, "timer", { baseMs, u, delayMs });', 'schedule(delayMs, "timer", { baseMs, u, delayMs: 0 });', 'which delay was planned'],
  ['server minimum of a failure recorded', 'serverMinMs: body || !response.data ? null : positive(response.data.nextPollAfterMs) || null,', 'serverMinMs: null,', 'waits at least Retry-After on 429'],
  ['server minimum only for a failure', 'serverMinMs: body || !response.data ? null :', 'serverMinMs: !response.data ? null :', 'which delay was planned'],
  ['Retry-After of a failure recorded', 'retryAfterMs: positive(response.retryAfterMs) || null,', 'retryAfterMs: null,', 'waits at least Retry-After on 429'],
  ['dispose aborts', '      disposed = true;\n      drop();\n', '      disposed = true;\n', 'dispose aborts the request in flight'],
  ['reset reported', '          resetPending = true;\n', '', 'reports a new epoch as a reset'],
  ['join key reused for the same attempt', 'if (!intent || intent.epoch !== epoch) intent = { epoch, joinRequestId: uuid() };', 'intent = { epoch, joinRequestId: uuid() };', 'repeats a join whose answer was lost with the same key'],
  ['new join key after a success', '          intent = null;\n          accept(data, timing);', '          accept(data, timing);', 'uses a new join key for a new attempt'],
  ['join only without an active entry', ' || !JOINABLE.includes(phase)', '', 'refuses a join while loading, while an entry is active'],
  ['join and cancel respect the error wait', 'const ready = () => idle() && notBefore <= now();', 'const ready = () => idle();', 'repeats a join whose answer was lost with the same key'],
  ['cancel answer of another entry', 'if (same && data.admission.admissionId === target) accept(data, timing);', 'if (same) accept(data, timing);', 'does not apply a cancel answer that is about another entry'],
  ['open purchase blocks join and cancel', 'const idle = () => started && !disposed && !busy && !purchase;', 'const idle = () => started && !disposed && !busy;', 'repeats an unknown purchase with the identical body'],
  ['automatic retries end', 'if (purchase.auto >= POLICY.purchaseAutoRetries) {', 'if (false) {', 'stops after four automatic retries'],
  ['ADMISSION_IN_PROGRESS is retried', 'if (undecided(status) || codeOf(response) === "ADMISSION_IN_PROGRESS") {', 'if (undecided(status)) {', 'retries only what a later attempt can outlive'],
  ['purchase body unchanged', '(signal) => sendPurchase(purchase.body, signal),', '(signal) => sendPurchase(Object.assign({}, purchase.body, { quantity: 1 }), signal),', 'repeats an unknown purchase with the identical body'],
  ['refresh keeps the error wait', '      if (notBefore > now()) schedule(notBefore - now(), "retry");\n      else poll("refresh");', '      poll("refresh");', 'keeps a wait of the status API'],
  ['purchase not held back by a backoff', '      if (!idle() || phase !== "admitted") return false;', '      if (!ready() || phase !== "admitted") return false;', 'does not hold a purchase back'],
  ['pending purchase restored', '      restorePurchase();\n', '', 'restores an unresolved purchase after a reload'],
  ['pending purchase removed', '          if (pending) pending.remove(pendingKey);\n', '', 'sends the purchase once with the body it was given'],
  ['recognition once', '      if (seen.has(key)) return;\n', '', 'records the first admitted application once'],
  ['missed recognition', '      if (entry.state !== "admitted") {', '      if (false) {', 'ended before this page saw it admitted'],
  ['reconnect layer', 'const reconnect = viaRecover || failuresBefore > 0 || visibleAtPromotion === null;', 'const reconnect = viaRecover || visibleAtPromotion === null;', 'follows failed requests under reconnect'],
  ['hidden layer', 'const hidden = hiddenBetween || hiddenAtApply || visibleAtPromotion === false;', 'const hidden = false;', 'made in a hidden tab under hidden'],
  ['recognition upper bound', 'upperMs: serverDeltaMs + (tApply - timing.tSend),', 'upperMs: serverDeltaMs + (tApply - timing.tRecv),', 'bounded by the server delta and the round trip'],
  ['aborted poll is not an answered poll', '      if (flight.pollSeq) trace("poll-aborted", { seq: flight.pollSeq, tSend: flight.tSend });\n', '', 'pre-empted as aborted'],
  ['trace limit', '        if (events.length > limit) {', '        if (false) {', 'keeps the newest events up to the limit'],
];

const mutations = only ? all.filter((m) => m[0] === only) : all;
const results = [];
try {
  for (const [name, find, replace, testName, every] of mutations) {
    if (!original.includes(find)) {
      results.push([name, 'MUTATION TARGET NOT FOUND']);
      continue;
    }
    writeFileSync(target, every ? original.split(find).join(replace) : original.replace(find, replace));
    const run = spawnSync(
      process.execPath,
      ['node_modules/jest/bin/jest.js', test, '-t', testName],
      { encoding: 'utf8', env: process.env },
    );
    const summary = /Tests:.*$/m.exec(run.stderr + run.stdout)?.[0] ?? 'no summary';
    const ran = /(\d+) (passed|failed)/.test(summary);
    results.push([name, !ran ? 'NO TEST RAN' : run.status === 0 ? 'SURVIVED (test did not fail)' : 'killed', summary]);
    writeFileSync(target, original);
  }
} finally {
  writeFileSync(target, original);
}
for (const r of results) console.log(r.join(' | '));
const killed = results.filter((r) => r[1] === 'killed').length;
console.log(`killed ${killed}/${results.length}`);
console.log('restored:', readFileSync(target, 'utf8') === original);
