// Reduces a HAR recorded by the browser to what the checks need and drops everything else
// (run peakpass-p6-20261003). Not part of the source tree. A HAR holds request headers, so the
// raw file contains the Authorization header; this script writes only time, duration, method,
// path and status, and the caller deletes the raw file.
//
// Usage: node har-check.mjs <raw.har> <reduced.json>
import { readFileSync, writeFileSync } from 'node:fs';

const [input, output] = process.argv.slice(2);
const har = JSON.parse(readFileSync(input, 'utf8'));
const entries = har.log.entries
  .filter((entry) => /^http:\/\/127\.0\.0\.1:310\d\//.test(entry.request.url))
  .map((entry) => ({
    started: Date.parse(entry.startedDateTime),
    ms: Math.round(entry.time * 10) / 10,
    method: entry.request.method,
    path: new URL(entry.request.url).pathname,
    port: new URL(entry.request.url).port,
    status: entry.response.status,
  }))
  .sort((a, b) => a.started - b.started);
// The requests of the queue and the purchase, without the browser's own preflights.
const own = entries.filter(
  (entry) => entry.method !== 'OPTIONS' && (entry.path.includes('/admissions') || entry.path === '/reservations'),
);
let overlapping = 0;
for (let i = 1; i < own.length; i += 1) if (own[i].started < own[i - 1].started + own[i - 1].ms) overlapping += 1;
const status = own.filter((entry) => entry.method === 'GET' && entry.path.endsWith('/admissions/me'));
const gaps = status.slice(1).map((entry, i) => entry.started - status[i].started);
const result = {
  source: 'browser HAR, reduced: headers and bodies removed',
  requests: entries.length,
  preflights: entries.filter((entry) => entry.method === 'OPTIONS').length,
  queueAndPurchase: own.length,
  overlapping,
  statusGet: status.length,
  statusGapMs: gaps.length ? { min: Math.min(...gaps), max: Math.max(...gaps) } : null,
  entries,
};
writeFileSync(output, `${JSON.stringify(result, null, 1)}\n`);
const { entries: _omitted, ...summary } = result;
console.log(JSON.stringify(summary));
