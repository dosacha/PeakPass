#!/usr/bin/env bash
# Real-browser checks for the second GitHub Codex auto-review of PR #28 (run
# peakpass-p6-20261003). Not part of the source tree.
#   bash review5.sh s25|s26 [label]      label is appended to the evidence names
. /c/Users/dosac/.claude/worktrees/peakpass-issue15/run/lib.sh
REPO=/c/Users/dosac/.claude/worktrees/peakpass-issue15/PeakPass
cd "$REPO" || exit 1
. "$RUN/helpers.sh"
L=${2:+-$2}
NOTES='[...document.querySelectorAll(".queue-note")].map(n => n.innerText.replace(/\s+/g," ")).join(" / ")'
FORM='(() => { const r = Object.fromEntries([...document.querySelectorAll(".insp-row")].map(x => [x.querySelector(".k").innerText, x.querySelector(".v").innerText])); return JSON.stringify({ quantity: r.quantity, reservation: r.reservationId === "—" ? "—" : r.reservationId.slice(0, 8), queue: r["queue.phase"] }); })()'
STEP3='(() => { const s = [...document.querySelectorAll(".step")].find(s => s.querySelector(".step-head").innerText.includes("Reservation Hold")); return "step 3 header: " + s.querySelector(".step-head").innerText.replace(/\s+/g, " ").slice(0, 60); })()'
OUTCOME='document.querySelector(".qb-sub")?.innerText'
LOAD_BUTTON='[...document.querySelectorAll("button.btn")].some(b => b.innerText.includes("예약 불러오기")) ? "shown" : "not shown"'
PENDING='Object.keys(sessionStorage).filter(k => k.startsWith("pp_pending_purchase")).join(", ") || "none"'
proxylog() { grep -c . "$EV/review5.proxy.log" 2>/dev/null || echo 0; }
since() { tail -n +"$(( $1 + 1 ))" "$EV/review5.proxy.log" | grep -v '"OPTIONS"'; }
quantity() { open_step "tier"; js "(() => { const i = document.querySelector('input.input.small[type=number]'); Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(i, '$1'); i.dispatchEvent(new Event('input', { bubbles: true })); return 'quantity $1'; })()" > /dev/null; pause 300; }

# Reset while a purchase has no answer yet; the page's own retry would be answered.
s25() {
  settled; drained; local from; from=$(now); local mark; mark=$(proxylog)
  open_page "s25-reset-purchase$L" fixed "$PROXY"
  press "등록"; wait_pill "입장" 40 && echo "admitted: redis=$(redis_entry)" || echo "NOT ADMITTED: $(js "$PILL")"
  local admitted; admitted=$(field "$(redis_entry)" admissionId)
  echo 2 > "$RUN/drop.flag"
  echo "purchase: $(press 'POST /reservations')"; pause 300
  echo "stored request: $(js "$PENDING")"
  echo "reset: $(press 'Reset')"; pause 4000
  rm -f "$RUN/drop.flag"
  echo "4 s after Reset: card=$(js "$PILL") notes=$(js "$NOTES") form=$(js "$FORM") $(js "$STEP3")"
  echo "proxy after the click:"; since "$mark" | grep 'POST","path":"/reservations"'
  local repeat; repeat=$(press '같은 요청으로 다시 확인'); echo "explicit repeat: $repeat"; pause 2500
  echo "after it: card=$(js "$PILL") notes=$(js "$NOTES") form=$(js "$FORM") $(js "$STEP3")"
  psqlb "SELECT 'reservations of this admission: '||COUNT(*)||', result '||MAX(COALESCE(left(a.reservation_id::text,8),'-')) FROM admission_results a WHERE a.admission_id='$admitted'"
  save_trace "s25-reset-purchase$L" | grep -E "purchase|summary"
  save_requests "s25-reset-purchase$L"
  applog "s25-reset-purchase$L" "$from" "$(now)"
}

# The page holds a reservation; a second tab of the same profile joins again and buys a newer
# one. Back in the first tab the card shows the newer reservation as the outcome.
s26() {
  settled; drained; local from; from=$(now); local mark; mark=$(proxylog)
  open_page "s26-newer$L" fixed "$PROXY"
  press "등록"; wait_pill "입장" 40 && echo "first admission: redis=$(redis_entry)" || echo "NOT ADMITTED: $(js "$PILL")"
  echo "first purchase: $(press 'POST /reservations')"; pause 2000
  echo "first tab holds: form=$(js "$FORM") outcome=$(js "$OUTCOME")"
  AB tab new "$FRONT/index.html?run=s26-newer-second$L&poll=fixed" > /dev/null; pause 3500
  echo "tabs: $(AB tab list | tr '\n' ' ' | cut -c1-200)"
  echo "second tab: card=$(js "$PILL") $(press '다시 등록')"; wait_pill "입장" 40 && echo "second admission: redis=$(redis_entry)" || echo "NOT ADMITTED: $(js "$PILL")"
  quantity 1
  echo "second purchase: $(press 'POST /reservations')"; pause 2000
  echo "second tab holds: form=$(js "$FORM") outcome=$(js "$OUTCOME")"
  AB tab t1 > /dev/null; pause 3000
  echo "first tab after return: card=$(js "$PILL") outcome=$(js "$OUTCOME") form=$(js "$FORM") load button: $(js "$LOAD_BUTTON")"
  local load; load=$(press '예약 불러오기'); echo "load: $load"; pause 2000
  echo "first tab after the load: form=$(js "$FORM")"
  save_trace "s26-newer$L" | grep -E "join|purchase|summary"
  save_requests "s26-newer$L"
  # Every tab but the first goes, so no tab of this run keeps polling into the next one.
  for t in $(AB tab list | grep -oE '\[t[0-9]+\]' | tr -d '[]' | grep -v '^t1$'); do AB tab close "$t" > /dev/null 2>&1; done
  AB tab t1 > /dev/null 2>&1; echo "tabs left: $(AB tab list | grep -oE '\[t[0-9]+\]' | tr '\n' ' ')"
  applog "s26-newer$L" "$from" "$(now)"
}

"$1"
