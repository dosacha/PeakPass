// Reads an F2 trace of the final check (run peakpass-p6-20261003) and prints the bounds of how
// long the page saw the second entry admitted, and the quiet time between the cancel and the next
// join. Not part of the source tree.
//   node f2-window.mjs <final-f2.trace.json>
import { readFileSync } from 'node:fs';

const events = JSON.parse(readFileSync(process.argv[2], 'utf8')).events;
const polls = events.filter((e) => e.type === 'poll' && e.status === 200);
const joins = events.filter((e) => e.type === 'join');
const cancel = events.find((e) => e.type === 'cancel');
const second = joins.at(-1);
const after = polls.filter((p) => p.tSend > second.tRecv);
const lastWaiting = after.filter((p) => p.state === 'waiting').at(-1);
const admitted = after.filter((p) => p.state === 'admitted');
const firstExpired = after.find((p) => p.state === 'expired');
const s = (ms) => (ms / 1000).toFixed(1);
// The entry turned admitted after the last waiting answer was sent and before the first admitted
// answer came back; it turned expired after the last admitted request was sent and before the
// first expired answer came back.
console.log(`admitted for between ${s(admitted.at(-1).tSend - admitted[0].tRecv)} and ${s(firstExpired.tRecv - lastWaiting.tSend)} s`);
const quiet = polls.filter((p) => p.tSend > cancel.tRecv && p.tSend < second.tSend);
console.log(`status requests between the cancel answer and the next join: ${quiet.length}; ${s(second.tSend - cancel.tRecv)} s`);
const late = events.filter((e) => ['poll', 'join', 'cancel', 'purchase'].includes(e.type) && e.tSend > firstExpired.tRecv);
console.log(`requests after the expired answer: ${late.length}`);
