#!/usr/bin/env bash
# Real-browser checks made for the findings of the internal review (run peakpass-p6-20261003).
# Not part of the source tree. The page talks to the application through the local proxy, which
# can hold a status request without answering it and lose answers of POST /reservations.
#   bash review-fix.sh s14|s15|s16|s17 [label]      label is appended to the evidence names
. /c/Users/dosac/.claude/worktrees/peakpass-issue15/run/lib.sh
REPO=/c/Users/dosac/.claude/worktrees/peakpass-issue15/PeakPass
cd "$REPO" || exit 1
. "$RUN/helpers.sh"
L=${2:+-$2}
POLLS='window.PeakPassAdmissionTrace.snapshot().events.filter(e => e.type === "poll").length'
NOTES='[...document.querySelectorAll(".queue-note")].map(n => n.innerText.replace(/\s+/g," ")).join(" / ")'
# The page's own request log: method, path, status, elapsed.
LOG='[...document.querySelectorAll(".le-head")].map(h => [h.querySelector(".method").innerText, h.querySelector(".url").innerText.replace(/[0-9a-f-]{36}/g, "<id>"), h.querySelector(".status").innerText, h.querySelector(".elapsed").innerText].join(" ")).join(" | ")'
STEP3='(() => { const b = [...document.querySelectorAll("button.btn")].find(b => b.innerText.includes("POST /reservations")); const s = [...document.querySelectorAll(".step")].find(s => s.querySelector(".step-head").innerText.includes("Reservation Hold")); return "step 3 button: " + (b ? (b.disabled ? "disabled" : "enabled") : "not shown") + ", header: " + s.querySelector(".step-head").innerText.replace(/\s+/g," ").slice(0, 70); })()'
proxylog() { grep -c . "${PROXYLOG:-$EV/review-fix.proxy.log}" 2>/dev/null || echo 0; }
since() { tail -n +"$(( $1 + 1 ))" "${PROXYLOG:-$EV/review-fix.proxy.log}" | grep -v '"OPTIONS"'; }

# A status request that the server accepts and never answers: the 5 s timeout of contract §7.
s14() {
  settled; local from; from=$(now); local mark; mark=$(proxylog)
  fillers 14 80 120 "s14-timeout$L"; pause 2500
  open_page "s14-timeout$L" fixed "$PROXY"
  press "등록"; pause 3500
  echo "before the stall: card=$(js "$PILL") polls=$(js "$POLLS")"
  touch "$RUN/stall.flag"; echo "stall on at $(now)"
  pause 14000
  echo "during the stall: card=$(js "$PILL") notes=$(js "$NOTES")"
  rm -f "$RUN/stall.flag"; echo "stall off at $(now)"
  pause 12000
  echo "after the stall: card=$(js "$PILL") notes=$(js "$NOTES")"
  save_trace "s14-timeout$L" | grep -E " timeout | retry |summary"
  echo "request log of the page: $(js "$LOG")"
  echo "held by the proxy:"; since "$mark" | grep '"held":true'
  save_requests "s14-timeout$L"
  applog "s14-timeout$L" "$from" "$(now)"
}

# A status poll that fails while the tab is hidden, then a return to the tab.
s15() {
  settled; local from; from=$(now); local mark; mark=$(proxylog)
  fillers 14 90 140 "s15-hidden-failure$L"; pause 2500
  open_page "s15-hidden-failure$L" fixed "$PROXY"
  press "등록"; pause 3000
  echo "before hiding: card=$(js "$PILL") polls=$(js "$POLLS")"
  AB tab t2 > /dev/null; echo "hidden at $(now)"
  pause 1000; touch "$RUN/stall.flag"
  # The hidden poll is due 15 s after the last answer and is given up after 5 s more.
  pause 20500
  rm -f "$RUN/stall.flag"
  pause 2500
  AB tab t1 > /dev/null; echo "returned at $(now)"
  pause 3000
  echo "after the return: card=$(js "$PILL") notes=$(js "$NOTES")"
  save_trace "s15-hidden-failure$L" | grep -E "visibility|hidden| timeout | return | retry |summary" | tail -12
  echo "held by the proxy:"; since "$mark" | grep '"held":true'
  save_requests "s15-hidden-failure$L"
  applog "s15-hidden-failure$L" "$from" "$(now)"
}

# The event is changed while a purchase has no answer yet; then back to the first event.
s16() {
  settled; drained; local from; from=$(now); local mark; mark=$(proxylog)
  echo "seats before: $(seats)"
  open_page "s16-event-switch$L" fixed "$PROXY"
  press "등록"; wait_pill "입장" 40 && echo "admitted: redis=$(redis_entry)" || echo "NOT ADMITTED: $(js "$PILL")"
  local admitted; admitted=$(field "$(redis_entry)" admissionId)
  echo 9 > "$RUN/drop.flag"
  echo "step 3: $(press 'POST /reservations')"; pause 1800
  echo "purchase without an answer: card=$(js "$PILL") notes=$(js "$NOTES")"
  echo "$(js "$STEP3")"
  js '[...document.querySelectorAll(".event-card")].find(c => c.innerText.includes("Advanced GraphQL")).click(); "selected: Advanced GraphQL"'
  pause 1500
  open_step "tier"; js 'document.querySelector(".tier-card").click(); "tier selected"' > /dev/null; pause 500
  open_step "Reservation Hold"
  echo "on the other event: card=$(js "$PILL")"
  echo "$(js "$STEP3")"
  rm -f "$RUN/drop.flag"
  js '[...document.querySelectorAll(".event-card")].find(c => c.innerText.includes("Node.js Workshop")).click(); "selected: Node.js Workshop"'
  pause 2500
  echo "back on the first event: card=$(js "$PILL") notes=$(js "$NOTES") redis=$(redis_entry)"
  echo "$(js "$STEP3")"
  echo "repeat the same request: $(press '같은 요청으로 다시 확인')"; pause 2500
  echo "after the repeat: card=$(js "$PILL") banner=$(js "$BANNER") notes=$(js "$NOTES")"
  echo "$(js "$STEP3")"
  save_trace "s16-event-switch$L" | grep -E "purchase|poll-aborted|join|RECOGNITION|summary"
  echo "proxy:"; since "$mark" | grep reservations
  echo "seats after: $(seats)"
  psqlb "SELECT 'result: outcome='||a.outcome||' reservation='||COALESCE(left(a.reservation_id::text,8),'-') FROM admission_results a WHERE a.admission_id='$admitted'"
  save_requests "s16-event-switch$L"
  applog "s16-event-switch$L" "$from" "$(now)"
}

# A reload while a purchase has no answer yet: the request is restored from the tab's storage.
s17() {
  settled; drained; local from; from=$(now); local mark; mark=$(proxylog)
  echo "seats before: $(seats)"
  open_page "s17-reload-unconfirmed$L" fixed "$PROXY"
  press "등록"; wait_pill "입장" 40 && echo "admitted: redis=$(redis_entry)" || echo "NOT ADMITTED: $(js "$PILL")"
  local admitted; admitted=$(field "$(redis_entry)" admissionId)
  echo 9 > "$RUN/drop.flag"
  echo "step 3: $(press 'POST /reservations')"; pause 1800
  echo "purchase without an answer: notes=$(js "$NOTES")"
  save_trace "s17-reload-unconfirmed-a$L" | grep -E "purchase|summary"
  AB open "$FRONT/index.html?run=s17-reload-unconfirmed$L&poll=fixed" > /dev/null; pause 2500
  rm -f "$RUN/drop.flag"
  echo "after the reload: card=$(js "$PILL") notes=$(js "$NOTES") redis=$(redis_entry)"
  echo "$(js "$STEP3")"
  echo "stored request template: $(js '(() => { const k = Object.keys(sessionStorage).find(k => k.startsWith("pp_pending_purchase:")); if (!k) return "none"; const v = sessionStorage.getItem(k); return "fields " + Object.keys(JSON.parse(v).body).join(",") + "; token-like text: " + (/eyJ|bearer|token|authorization/i.test(v) ? "YES" : "no"); })()')"
  AB a11y --tags wcag2a,wcag2aa --selector ".step:has(.status-pill.info):not(:has(.queue-lead))" --json > "$EV/a11y-step3-unconfirmed$L.json"
  node -e 'const d=JSON.parse(require("fs").readFileSync(process.argv[1],"utf8")).data; const f=(k)=>d[k].map(v=>v.id+" "+v.nodeCount+": "+v.nodes.map(n=>n.target.join(" ")+" ("+((n.failureSummary||"").match(/contrast of ([0-9.]+)/)||[,"-"])[1]+")").join(", ")).join("; "); console.log("audit of step 3 while unconfirmed | violations: "+(f("violations")||"none")+" | incomplete: "+(f("incomplete")||"none"))' "$EV/a11y-step3-unconfirmed$L.json"
  echo "repeat the same request: $(press '같은 요청으로 다시 확인')"; pause 3000
  echo "after the repeat: card=$(js "$PILL") banner=$(js "$BANNER") notes=$(js "$NOTES")"
  echo "$(js "$STEP3")"
  save_trace "s17-reload-unconfirmed-b$L" | grep -E "purchase|summary"
  echo "proxy:"; since "$mark" | grep reservations
  echo "seats after: $(seats)"
  psqlb "SELECT 'result: outcome='||a.outcome||' reservation='||COALESCE(left(a.reservation_id::text,8),'-') FROM admission_results a WHERE a.admission_id='$admitted'"
  save_requests "s17-reload-unconfirmed$L"
  applog "s17-reload-unconfirmed$L" "$from" "$(now)"
}

"$1"
