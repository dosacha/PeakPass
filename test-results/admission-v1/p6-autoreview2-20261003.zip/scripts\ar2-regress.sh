#!/usr/bin/env bash
# Regression of the second auto-review round of PR #28 on the committed fix (run
# peakpass-p6-20261003). Not part of the source tree. The scenarios of this round and those whose
# code paths the round touched run again, a minute apart so that the purchase limit of the demo
# user (5 per minute) is free for each, then the final check.
#   bash ar2-regress.sh <label>      the label names the evidence, e.g. the short commit
# A first version ran s16, s17 and s23 with the label ar2 on 0b1c3b5 before the final check of
# that commit was stopped.
RUN=/c/Users/dosac/.claude/worktrees/peakpass-issue15/run
cd "$RUN" || exit 1
L=$1
export PROXYLOG=$RUN/evidence/review5.proxy.log
echo "start $(date -u +%H:%M:%S) at $(git -C ../PeakPass rev-parse --short HEAD)"
bash review5.sh s25 "$L" > "evidence/s25-reset-purchase-$L.console.log" 2>&1; echo "s25 done $(date -u +%H:%M:%S)"
sleep 65
bash review5.sh s26 "$L" > "evidence/s26-newer-$L.console.log" 2>&1; echo "s26 done $(date -u +%H:%M:%S)"
sleep 65
bash review-fix.sh s16 "$L" > "evidence/s16-event-switch-$L.console.log" 2>&1; echo "s16 done $(date -u +%H:%M:%S)"
sleep 65
bash review-fix.sh s17 "$L" > "evidence/s17-reload-unconfirmed-$L.console.log" 2>&1; echo "s17 done $(date -u +%H:%M:%S)"
sleep 65
bash review4.sh s23 "$L" > "evidence/s23-reset-$L.console.log" 2>&1; echo "s23 done $(date -u +%H:%M:%S)"
sleep 65
bash final.sh > evidence/final.console.log 2>&1; echo "final done $(date -u +%H:%M:%S)"
