#!/usr/bin/env bash
# Runs the final SQL of the final check again, after browser checks that followed it (run
# peakpass-p6-20261003). Not part of the source tree. The statements are read from final.sh, so
# they are the same.
#   bash final-sql.sh
. /c/Users/dosac/.claude/worktrees/peakpass-issue15/run/lib.sh
REPO=/c/Users/dosac/.claude/worktrees/peakpass-issue15/PeakPass
cd "$REPO" || exit 1
. "$RUN/helpers.sh"
echo "== at $(now), commit $(git rev-parse HEAD)"
eval "$(sed -n '/== final SQL of contract/,/reservations by status/p' "$RUN/final.sh")"
