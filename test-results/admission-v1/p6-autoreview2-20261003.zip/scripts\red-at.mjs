// Runs named tests of the polling file against the polling script of an earlier commit and
// restores the working file afterwards (run peakpass-p6-20261003). Not part of the source tree.
// Run from the worktree:  node ../run/red-at.mjs <commit> <test name pattern>
import { execFileSync, spawnSync } from 'node:child_process';
import { readFileSync, writeFileSync } from 'node:fs';

const [commit, pattern] = process.argv.slice(2);
const target = 'frontend/admission-polling.js';
const current = readFileSync(target);
const earlier = execFileSync('git', ['show', `${commit}:${target}`]);
try {
  writeFileSync(target, earlier);
  const run = spawnSync(process.execPath, ['node_modules/jest/bin/jest.js', 'src/tests/unit/admission-polling.test.ts', '-t', pattern], { encoding: 'utf8' });
  console.log(`polling script of ${commit}, tests matching "${pattern}", exit ${run.status}`);
  console.log(run.stdout + run.stderr);
} finally {
  writeFileSync(target, current);
}
console.log('restored:', readFileSync(target).equals(current));
