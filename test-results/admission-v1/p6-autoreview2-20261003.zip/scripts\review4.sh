#!/usr/bin/env bash
# Real-browser checks for the findings of the GitHub Codex auto-review of PR #28 (run
# peakpass-p6-20261003). Not part of the source tree. The page talks to the application through
# the local proxy, which can hold back a reservation read and make a status request carry an
# invalid token.
#   bash review4.sh s23|s24 [label]      label is appended to the evidence names
. /c/Users/dosac/.claude/worktrees/peakpass-issue15/run/lib.sh
REPO=/c/Users/dosac/.claude/worktrees/peakpass-issue15/PeakPass
cd "$REPO" || exit 1
. "$RUN/helpers.sh"
L=${2:+-$2}
FORM='(() => { const r = Object.fromEntries([...document.querySelectorAll(".insp-row")].map(x => [x.querySelector(".k").innerText, x.querySelector(".v").innerText])); return JSON.stringify({ tier: r.selectedTier, quantity: r.quantity, reservation: r.reservationId === "—" ? "—" : r.reservationId.slice(0, 8), queue: r["queue.phase"] }); })()'
STEP3='(() => { const s = [...document.querySelectorAll(".step")].find(s => s.querySelector(".step-head").innerText.includes("Reservation Hold")); return "step 3 header: " + s.querySelector(".step-head").innerText.replace(/\s+/g, " ").slice(0, 60); })()'
LOG_AUTH='[...document.querySelectorAll(".le-head")].map(h => [h.querySelector(".method").innerText, h.querySelector(".url").innerText.replace(/[0-9a-f-]{36}/g, "<id>"), h.querySelector(".status").innerText].join(" ")).filter(l => l.includes("admissions/me") || l.includes(" 401")).join(" | ")'
AUTH_EVENTS='JSON.stringify(window.PeakPassAdmissionTrace.snapshot().events.filter(e => e.type === "auth-retry").map(e => ({ method: e.method, status: e.status, code: e.code })))'
proxylog() { grep -c . "${PROXYLOG:-$EV/review4.proxy.log}" 2>/dev/null || echo 0; }
since() { tail -n +"$(( $1 + 1 ))" "${PROXYLOG:-$EV/review4.proxy.log}" | grep -v '"OPTIONS"'; }

# A reservation read held back while Reset is clicked.
s23() {
  settled; drained; local from; from=$(now); local mark; mark=$(proxylog)
  open_page "s23-reset$L" fixed "$PROXY"
  press "등록"; wait_pill "입장" 40 && echo "admitted: redis=$(redis_entry)" || echo "NOT ADMITTED: $(js "$PILL")"
  echo "purchase: $(press 'POST /reservations')"; pause 2000
  AB open "$FRONT/index.html?run=s23-reset$L&poll=fixed" > /dev/null; pause 2500
  echo "after the reload: card=$(js "$PILL") form=$(js "$FORM") $(js "$STEP3")"
  echo 8000 > "$RUN/delay.flag"
  echo "load: $(press '예약 불러오기')"; pause 400
  rm -f "$RUN/delay.flag"
  echo "reset: $(press 'Reset')"; pause 600
  echo "after Reset: form=$(js "$FORM") $(js "$STEP3")"
  pause 9000
  echo "after the held answer arrived: form=$(js "$FORM") $(js "$STEP3")"
  echo "proxy:"; since "$mark" | grep 'GET","path":"/reservations/'
  save_trace "s23-reset$L" | grep -E "summary"
  save_requests "s23-reset$L"
  applog "s23-reset$L" "$from" "$(now)"
}

# One status request reaches the application with an invalid token; the page repeats it with a
# new session. Both attempts should be on record.
s24() {
  settled; drained; local from; from=$(now); local mark; mark=$(proxylog)
  open_page "s24-auth-retry$L" fixed "$PROXY"
  press "등록"; wait_pill "입장" 40 && echo "admitted: redis=$(redis_entry)" || echo "NOT ADMITTED: $(js "$PILL")"
  echo 1 > "$RUN/unauth.flag"; pause 3500
  rm -f "$RUN/unauth.flag"
  echo "trace records of a rejected attempt: $(js "$AUTH_EVENTS")"
  echo "request log (status and 401 lines): $(js "$LOG_AUTH")"
  echo "proxy:"; since "$mark" | grep -E 'tokenReplaced|/demo/session'
  save_trace "s24-auth-retry$L" | grep -E "auth-retry|summary"
  save_requests "s24-auth-retry$L"
  applog "s24-auth-retry$L" "$from" "$(now)"
}

"$1"
