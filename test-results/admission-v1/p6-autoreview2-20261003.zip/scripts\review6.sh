#!/usr/bin/env bash
# Real-browser check of the Reset finding of the second GitHub Codex auto-review of PR #28, made
# independent of click timing (run peakpass-p6-20261003). Not part of the source tree. Every
# answer of POST /reservations is lost at the proxy until Reset is clicked, so the purchase is
# still being sent at that moment; from then on answers come through, so a purchase attempt sent
# after Reset would be answered. The page's own time of the Reset click is recorded in the same
# script call that clicks, and the trace's purchase attempts are compared with it.
#   bash review6.sh s25b [label]      label is appended to the evidence names
. /c/Users/dosac/.claude/worktrees/peakpass-issue15/run/lib.sh
REPO=/c/Users/dosac/.claude/worktrees/peakpass-issue15/PeakPass
cd "$REPO" || exit 1
. "$RUN/helpers.sh"
L=${2:+-$2}
PLOG=$EV/review5.proxy.log
NOTES='[...document.querySelectorAll(".queue-note")].map(n => n.innerText.replace(/\s+/g," ")).join(" / ")'
FORM='(() => { const r = Object.fromEntries([...document.querySelectorAll(".insp-row")].map(x => [x.querySelector(".k").innerText, x.querySelector(".v").innerText])); return JSON.stringify({ quantity: r.quantity, reservation: r.reservationId === "—" ? "—" : r.reservationId.slice(0, 8), queue: r["queue.phase"] }); })()'
STEP3='(() => { const s = [...document.querySelectorAll(".step")].find(s => s.querySelector(".step-head").innerText.includes("Reservation Hold")); return "step 3 header: " + s.querySelector(".step-head").innerText.replace(/\s+/g, " ").slice(0, 60); })()'
RESET='(() => { const b = [...document.querySelectorAll("button.btn")].find(b => b.innerText.includes("Reset")); if (!b) return "no button: Reset"; window.__resetAt = performance.now(); b.click(); return "clicked: Reset at " + Math.round(window.__resetAt) + " ms"; })()'
AFTER='JSON.stringify(window.PeakPassAdmissionTrace.snapshot().events.filter(e => e.type === "purchase" && e.tSend > window.__resetAt).map(e => ({ attempt: e.attempt, tSend: Math.round(e.tSend), status: e.status })))'
BEFORE='JSON.stringify(window.PeakPassAdmissionTrace.snapshot().events.filter(e => e.type === "purchase" && e.tSend <= window.__resetAt).map(e => ({ attempt: e.attempt, tSend: Math.round(e.tSend), status: e.status })))'
proxylog() { grep -c . "$PLOG" 2>/dev/null || echo 0; }
since() { tail -n +"$(( $1 + 1 ))" "$PLOG" | grep -v '"OPTIONS"'; }

s25b() {
  settled; drained; local from; from=$(now)
  echo "frontend served: $(curl -s "$FRONT/admission-polling.js" | grep -c 'function stopPurchase') stopPurchase definition(s) in admission-polling.js"
  open_page "s25b-reset-purchase$L" fixed "$PROXY"
  press "등록"; wait_pill "입장" 40 && echo "admitted: redis=$(redis_entry)" || echo "NOT ADMITTED: $(js "$PILL")"
  local admitted; admitted=$(field "$(redis_entry)" admissionId)
  echo 20 > "$RUN/drop.flag"
  echo "purchase: $(press 'POST /reservations')"; pause 1500
  echo "before Reset: notes=$(js "$NOTES")"
  local mark; mark=$(proxylog)
  echo "$(js "$RESET")"
  rm -f "$RUN/drop.flag"
  pause 8000
  echo "8 s after Reset: card=$(js "$PILL") notes=$(js "$NOTES") form=$(js "$FORM") $(js "$STEP3")"
  echo "purchase attempts of the page that ended before Reset: $(js "$BEFORE")"
  echo "purchase attempts of the page sent after Reset: $(js "$AFTER")"
  echo "proxy, reservations after the Reset mark:"; since "$mark" | grep 'POST","path":"/reservations"'
  local repeat; repeat=$(press '같은 요청으로 다시 확인'); echo "explicit repeat: $repeat"; pause 2500
  echo "after it: card=$(js "$PILL") notes=$(js "$NOTES") form=$(js "$FORM") $(js "$STEP3")"
  psqlb "SELECT 'reservations of this admission: '||COUNT(*)||', result '||MAX(COALESCE(left(a.reservation_id::text,8),'-')) FROM admission_results a WHERE a.admission_id='$admitted'"
  save_trace "s25b-reset-purchase$L" | grep -E "purchase|summary"
  save_requests "s25b-reset-purchase$L"
  applog "s25b-reset-purchase$L" "$from" "$(now)"
}

"$1"
