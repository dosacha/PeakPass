Evidence of the second GitHub Codex auto-review of PR #28, run peakpass-p6-20261003, final code cfe72a53c9621694df32a486f86d29db3a769bf2.
The round has two code commits: 0b1c3b5 (the three fixes; Reset replaced the queue controller) and cfe72a5
(Reset stops only the purchase). p6-final-20261003.zip holds the evidence up to code 02ee7e0,
p6-review-20261003.zip and p6-review2-20261003.zip the two rounds of the external static review, and
p6-autoreview-20261003.zip the first auto-review (code a9954d8).

evidence/  s25-* Reset while a purchase has no answer: -before on d022ec7, -after on the working tree of
           0b1c3b5, -cfe72a5 on cfe72a5 (there the page's retry was answered before the click, so it shows
           only that Reset clears a finished purchase). s25b-* the same check independent of click timing:
           every answer is lost until Reset, -red-d022ec7 with the frontend of d022ec7, -cfe72a5 on cfe72a5.
           s26-* a newer reservation made in a second tab: -before on d022ec7; -after (the read got 429:
           five reservation requests of the user within the minute), -after2 (a tab of -after still open) and
           -after3 on the working tree of 0b1c3b5; -cfe72a5 on cfe72a5. s16-*, s17-*, s23-* the regression
           of paths the round touched: -ar2 on 0b1c3b5, -cfe72a5 on cfe72a5. review5.proxy.log: the proxy of
           these runs. red-autoreview2-*: the RED outputs of the new tests. mutation-autoreview2.txt: the
           mutation check on cfe72a5. final-0b1c3b5-stopped/: the final check of 0b1c3b5, stopped in F2 when
           the Reset fix was changed. final.console.log, final-f*, a11y-*.json: the final check on cfe72a5;
           final-sql-after-s25b.txt: its final SQL again after s25b, the last run.
logs/      build, typecheck, lint, unit, integration and harness on cfe72a5 (ar2-*) and on 0b1c3b5
           (ar2-0b1c3b5-*), the CI checks and review records of PR #28 as read from GitHub (pr28-*), and
           summaries.txt (every trace as text).
scripts/   the scripts used for these runs; not part of the source tree; no env file.
