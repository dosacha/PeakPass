// Builds the evidence archive of the second GitHub Codex auto-review of PR #28 (run
// peakpass-p6-20261003). Not part of the source tree. Run from the run directory:
//   node archive-autoreview2.mjs <codeSha>
// The earlier archives (p6-final, p6-review, p6-review2, p6-autoreview of 20261003) stay as they are.
import { createHash } from 'node:crypto';
import { cpSync, mkdirSync, readFileSync, readdirSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { execFileSync, spawnSync } from 'node:child_process';
import { join, relative, sep } from 'node:path';

const codeSha = process.argv[2];
if (!/^[0-9a-f]{40}$/.test(codeSha ?? '')) throw new Error('usage: node archive-autoreview2.mjs <codeSha>');
const RUN = process.cwd();
const REPO = join(RUN, '..', 'PeakPass');
const NAME = 'p6-autoreview2-20261003';
const stage = join(RUN, 'archive', NAME);
const out = join(REPO, 'test-results', 'admission-v1');
const posix = (path) => path.split(sep).join('/');
const walk = (dir) =>
  readdirSync(dir).flatMap((name) => {
    const path = join(dir, name);
    return statSync(path).isDirectory() ? walk(path) : [path];
  });

// The checks of this round (s25, s25b, s26 with their runs before the change), the regression
// on 0b1c3b5 (label ar2) and on the final commit (label cfe72a5), the stopped final check of
// 0b1c3b5, the final check on the final commit, the RED and mutation outputs, and the CI and
// review records of the PR.
const EV = join(RUN, 'evidence');
const evidence = readdirSync(EV).filter((name) =>
  /^(s25-|s25b-|s26-|s16-event-switch-(ar2|cfe72a5)\.|s17-reload-unconfirmed-(a-|b-)?(ar2|cfe72a5)\.|s23-reset-(ar2|cfe72a5)\.|a11y-step3-unconfirmed-(ar2|cfe72a5)\.json$|review5\.proxy\.log$|mutation-autoreview2\.txt$|red-autoreview2-|final-0b1c3b5-stopped$|final-sql-after-s25b\.txt$|final\.console\.log$|final-f[12][abc]?\.|a11y-(waiting|waiting-confirm|admitted|finished|page)\.json$)/.test(name),
);
rmSync(stage, { recursive: true, force: true });
mkdirSync(join(stage, 'evidence'), { recursive: true });
for (const name of evidence) cpSync(join(EV, name), join(stage, 'evidence', name), { recursive: true });

const traces = walk(join(stage, 'evidence')).filter((file) => file.endsWith('.trace.json')).sort();
mkdirSync(join(stage, 'logs'));
writeFileSync(
  join(stage, 'logs', 'summaries.txt'),
  traces
    .map((file) => `=== ${posix(relative(stage, file))}\n${spawnSync(process.execPath, [join(RUN, 'summary.mjs'), file], { encoding: 'utf8' }).stdout}`)
    .join(''),
);
const githubRecords = /^(ar2-|pr28-threads\.json$|pr28-[a-z-]+-2\.(json|md|log)$)/;
for (const name of readdirSync(join(RUN, 'logs')).filter((n) => githubRecords.test(n))) cpSync(join(RUN, 'logs', name), join(stage, 'logs', name));
mkdirSync(join(stage, 'scripts'));
for (const name of ['review5.sh', 'review6.sh', 'review-fix.sh', 'review4.sh', 'ar2-regress.sh', 'final-sql.sh', 'f2-window.mjs', 'red-at.mjs', 'mutate.mjs', 'proxy.mjs', 'helpers.sh', 'lib.sh', 'final.sh', 'summary.mjs', 'applog.mjs', 'app.sh', 'archive-autoreview2.mjs'])
  cpSync(join(RUN, name), join(stage, 'scripts', name));
writeFileSync(
  join(stage, 'README.txt'),
  [
    `Evidence of the second GitHub Codex auto-review of PR #28, run peakpass-p6-20261003, final code ${codeSha}.`,
    'The round has two code commits: 0b1c3b5 (the three fixes; Reset replaced the queue controller) and cfe72a5',
    '(Reset stops only the purchase). p6-final-20261003.zip holds the evidence up to code 02ee7e0,',
    'p6-review-20261003.zip and p6-review2-20261003.zip the two rounds of the external static review, and',
    'p6-autoreview-20261003.zip the first auto-review (code a9954d8).',
    '',
    'evidence/  s25-* Reset while a purchase has no answer: -before on d022ec7, -after on the working tree of',
    '           0b1c3b5, -cfe72a5 on cfe72a5 (there the page\'s retry was answered before the click, so it shows',
    '           only that Reset clears a finished purchase). s25b-* the same check independent of click timing:',
    '           every answer is lost until Reset, -red-d022ec7 with the frontend of d022ec7, -cfe72a5 on cfe72a5.',
    '           s26-* a newer reservation made in a second tab: -before on d022ec7; -after (the read got 429:',
    '           five reservation requests of the user within the minute), -after2 (a tab of -after still open) and',
    '           -after3 on the working tree of 0b1c3b5; -cfe72a5 on cfe72a5. s16-*, s17-*, s23-* the regression',
    '           of paths the round touched: -ar2 on 0b1c3b5, -cfe72a5 on cfe72a5. review5.proxy.log: the proxy of',
    '           these runs. red-autoreview2-*: the RED outputs of the new tests. mutation-autoreview2.txt: the',
    '           mutation check on cfe72a5. final-0b1c3b5-stopped/: the final check of 0b1c3b5, stopped in F2 when',
    '           the Reset fix was changed. final.console.log, final-f*, a11y-*.json: the final check on cfe72a5;',
    '           final-sql-after-s25b.txt: its final SQL again after s25b, the last run.',
    'logs/      build, typecheck, lint, unit, integration and harness on cfe72a5 (ar2-*) and on 0b1c3b5',
    '           (ar2-0b1c3b5-*), the CI checks and review records of PR #28 as read from GitHub (pr28-*), and',
    '           summaries.txt (every trace as text).',
    'scripts/   the scripts used for these runs; not part of the source tree; no env file.',
    '',
  ].join('\n'),
);

const suspicious = [
  /eyJ[A-Za-z0-9_-]{10,}/,
  /Bearer [A-Za-z0-9._-]{12,}/,
  /:\/\/[^/\s:@]+:[^@\s/]+@/,
  /(JWT_SECRET|DB_PASSWORD|POSTGRES_PASSWORD|REDIS_PASSWORD)=[A-Za-z0-9_\-+/]{8,}/,
];
const staged = walk(stage).sort();
// The proxy injects one deliberately invalid token; that literal is not a credential.
const hits = staged.filter((file) => {
  const text = readFileSync(file, 'utf8').replaceAll('Bearer invalid-for-the-check', '');
  return suspicious.some((pattern) => pattern.test(text));
});
if (hits.length) throw new Error(`credential-like text in: ${hits.map((file) => relative(stage, file)).join(', ')}`);
const sha = (buffer) => createHash('sha256').update(buffer).digest('hex');
const files = staged.map((file) => {
  const data = readFileSync(file);
  return { name: posix(relative(stage, file)), bytes: data.length, sha256: sha(data) };
});
const zip = join(out, `${NAME}.zip`);
rmSync(zip, { force: true });
execFileSync('powershell.exe', ['-NoProfile', '-Command', `Compress-Archive -Path '${stage}\\*' -DestinationPath '${zip}' -CompressionLevel Optimal`], { stdio: 'inherit' });

const events = traces.map((file) => JSON.parse(readFileSync(file, 'utf8')).events);
let overlapping = 0;
for (const list of events) {
  const spans = list.filter((e) => ['poll', 'join', 'cancel', 'purchase'].includes(e.type)).sort((a, b) => a.tSend - b.tSend);
  for (let i = 1; i < spans.length; i += 1) if (spans[i].tSend < spans[i - 1].tRecv) overlapping += 1;
}
const extracts = walk(join(stage, 'evidence')).filter((file) => /\.applog[^/\\]*\.json$/.test(file)).map((file) => JSON.parse(readFileSync(file, 'utf8')));

// The final SQL as the final check printed it on the final commit.
const finalConsole = readFileSync(join(EV, 'final.console.log'), 'utf8');
if (!finalConsole.startsWith(`== commit ${codeSha},`)) throw new Error('final.console.log is not the final check of this commit');
const seats = [...finalConsole.matchAll(/^seats: available=(\d+) total=(\d+) held=(\d+) ordered=(\d+) reservations=\d+ orders=\d+ results=(\d+)$/gm)].at(-1);
const mismatched = /^consumed results that do not match their target: (\d+)$/m.exec(finalConsole);
if (!seats || !mismatched || !/invariant available\+held\+ordered=total: true, 0<=available<=total: true/.test(finalConsole))
  throw new Error('final SQL lines not found or not holding');
const [, available, total, held, ordered, results] = seats;
// The same SQL once more after S25b, the last browser run of the round.
const later = readFileSync(join(EV, 'final-sql-after-s25b.txt'), 'utf8');
const laterSeats = /^seats: available=(\d+) total=(\d+) held=(\d+) ordered=(\d+) reservations=\d+ orders=\d+ results=(\d+)$/m.exec(later);
const laterMismatched = /^consumed results that do not match their target: (\d+)$/m.exec(later);
if (!laterSeats || !laterMismatched || !later.includes(`commit ${codeSha}`) || !/invariant available\+held\+ordered=total: true, 0<=available<=total: true/.test(later))
  throw new Error('final SQL after S25b not found or not holding');

const manifest = {
  runId: 'peakpass-p6-20261003',
  part: 'GitHub Codex auto-review of PR #28, second round',
  codeSha,
  codeCommitsOfThisRound: ['0b1c3b5e22bf5fd53c429b331c2350f9880f2051', codeSha],
  previous: [
    { archive: 'p6-final-20261003.zip', codeSha: '02ee7e025b31b5de39f942d4cfec1fc3e9432e74' },
    { archive: 'p6-review-20261003.zip', codeSha: 'b9656ab317d344f2bedff3b49ecfb9638c77f7bb' },
    { archive: 'p6-review2-20261003.zip', codeSha: 'fc0f4a8a665d385e52a3300882bd376eee4f24f8', head: '6645a2903fd2ab74071cd1f8f0121a2edcd67ca5' },
    { archive: 'p6-autoreview-20261003.zip', codeSha: 'a9954d86c3705d45a763f6bfe1a1fde164231442', head: 'd022ec773c4c08ce2c1e884f99c31da4fbf2ce63' },
  ],
  baseSha: '2d67cc3c10a1d04bebe0a7a81f9575ea39e63363',
  contract: { revision: 'admission-v1', sha256: 'e22be4df9910811eba552f630b43170ba0cf0c8d953a54dc5a3cea34c0dcf3d1' },
  archive: `${NAME}.zip`,
  archiveSha256: sha(readFileSync(zip)),
  pullRequest: { number: 28, head: 'd022ec773c4c08ce2c1e884f99c31da4fbf2ce63', ci: 'install-lint-test passed on 6645a29 and d022ec7' },
  autoReview: {
    reviewer: 'chatgpt-codex-connector[bot] on PR #28',
    target: 'd022ec773c4c08ce2c1e884f99c31da4fbf2ce63',
    findings: 'three P2: a stored purchase not namespaced by API base (fixed in 0b1c3b5); purchase callbacks of a retry landing after Reset (fixed in 0b1c3b5 by replacing the controller, then in cfe72a5 by stopping only the purchase); a newer consumed reservation of another tab not loadable (fixed in 0b1c3b5)',
    fixedIn: codeSha,
    nextReview: 'starts with the next push',
  },
  results: {
    build: 'pass',
    typecheck: 'pass',
    lintErrors: 0,
    lintWarnings: 11,
    unitPassed: 227,
    unitSuites: 23,
    integrationPassed: 346,
    integrationSkipped: 15,
    integrationSuitesPassed: 30,
    integrationSuitesSkipped: 2,
    harnessPassed: 29,
    callbackHarness: 'pass',
    mutations: '56/56 at cfe72a5 (49 of them also at b9656ab)',
    checkPageTask21: '10/10',
    checkPageTask22CasesPassed: 4,
    servedFilesEqualCommittedBlobs: 10,
    pageTraces: traces.length,
    overlappingRequestsInPageTraces: overlapping,
    serverLogExtractsOfTheBrowser: extracts.filter((j) => j.agents === 'browser').length,
    overlappingRequestsInServerLogExtracts: extracts.filter((j) => j.agents === 'browser').reduce((sum, j) => sum + j.overlapping, 0),
    finalSql: `available + active reservation quantity + pending/paid/delivered order quantity = total (${available} + ${held} + ${ordered} = ${total}); consumed results ${results}, of which do not match their target: ${mismatched[1]}`,
    finalSqlAfterS25b: `(${laterSeats[1]} + ${laterSeats[3]} + ${laterSeats[4]} = ${laterSeats[2]}); consumed results ${laterSeats[5]}, of which do not match their target: ${laterMismatched[1]}`,
  },
  scenarios: {
    s25: 'purchase answer and the browser repeat lost, Reset clicked: before the change the page retry was answered after Reset and the reservation and step 3 done came back; on the working tree of 0b1c3b5 no request followed Reset and the request was restored as unconfirmed; on cfe72a5 the retry happened to be answered before the click',
    s25b: 'every purchase answer lost until Reset, then answers pass: with the frontend of d022ec7 a purchase attempt sent after Reset was answered and adopted; on cfe72a5 no attempt followed Reset, the request waited as unconfirmed and its button returned the one reservation',
    s26: 'a second tab of the same profile joined again and bought: before the change the first tab could not load the newer reservation; after it the button loaded it with its quantity (three runs on 0b1c3b5, see README, and one on cfe72a5)',
    regression: 's16, s17 and s23 on 0b1c3b5 and on cfe72a5',
  },
  note: 'No credentials, env file, token or raw HAR are archived; the raw application logs are not archived.',
  files,
};
writeFileSync(join(out, `${NAME}.json`), `${JSON.stringify(manifest, null, 2)}\n`);
console.log(JSON.stringify({ files: files.length, zipBytes: statSync(zip).size, zipSha256: manifest.archiveSha256, traces: traces.length, overlapping, extracts: manifest.results.serverLogExtractsOfTheBrowser, finalSql: manifest.results.finalSql }, null, 1));
