#!/usr/bin/env bash
# Existing-database upgrade check for migration 013 (P5 / Issue #14).
# A fresh database is brought to migration 012 by the real P4 image, filled with rows, and then
# upgraded by the P5 image. Credentials come from the caller's environment and are never printed.
# Usage: upgrade-check.sh <p4-image> <p5-image>   (DB_*/REDIS_* exported, owned containers only)
set -euo pipefail
P4_IMAGE=$1; P5_IMAGE=$2
PG=peakpass-p5-20261002-pg
DB=peakpass_upgrade
sql() { docker exec -i "$PG" psql -U "$DB_USER" -d "$DB" -v ON_ERROR_STOP=1 -qAt "$@"; }
run_image() { # image, then the command
  local image=$1; shift
  docker run --rm --env DB_HOST=host.docker.internal --env DB_PORT --env DB_USER --env DB_PASSWORD \
    --env DB_NAME=$DB --env REDIS_HOST=host.docker.internal --env REDIS_PORT --env LOG_LEVEL=info \
    --env ENABLE_ADMISSION=false "$image" "$@"
}
counts() {
  sql -c "SELECT 'users='||(SELECT count(*) FROM users)||' events='||(SELECT count(*) FROM events)
    ||' reservations='||(SELECT count(*) FROM reservations)||' orders='||(SELECT count(*) FROM orders)
    ||' payment_records='||(SELECT count(*) FROM payment_records)
    ||' admission_events='||(SELECT count(*) FROM admission_events)
    ||' seats='||(SELECT string_agg(available_seats::text||'/'||total_seats::text, ',' ORDER BY name) FROM events)"
}

echo "== 1. fresh database, migrated by the P4 image ($P4_IMAGE)"
docker exec "$PG" psql -U "$DB_USER" -d postgres -v ON_ERROR_STOP=1 -qAt \
  -c "DROP DATABASE IF EXISTS $DB" -c "CREATE DATABASE $DB"
run_image "$P4_IMAGE" node dist/infra/migrations/runner.js up | grep -o 'All migrations complete. Total new: [0-9]*'
echo "versions: $(sql -c "SELECT string_agg(version::text, ',' ORDER BY version) FROM migrations")"
echo "admission_results before: $(sql -c "SELECT COALESCE(to_regclass('public.admission_results')::text, 'absent')")"

echo "== 2. rows written at the 012 level (direct SQL fixture)"
sql <<'SQL'
INSERT INTO users(id,email) VALUES ('11111111-1111-4111-8111-111111111111','upgrade@p5.test');
INSERT INTO events(id,name,starts_at,ends_at,total_seats,available_seats,pricing,status) VALUES
 ('22222222-2222-4222-8222-222222222222','upgrade with policy',NOW()+interval '1 hour',NOW()+interval '2 hours',10,7,
  '[{"id":"general","name":"General","price":50,"quantity":10}]','published'),
 ('33333333-3333-4333-8333-333333333333','upgrade without policy',NOW()+interval '1 hour',NOW()+interval '2 hours',5,5,
  '[{"id":"general","name":"General","price":50,"quantity":5}]','published');
INSERT INTO admission_events(event_id,redis_namespace)
 VALUES ('22222222-2222-4222-8222-222222222222','peakpass:admission:22222222-2222-4222-8222-222222222222:');
INSERT INTO reservations(id,user_id,event_id,quantity,tier_id,expires_at)
 VALUES ('44444444-4444-4444-8444-444444444444','11111111-1111-4111-8111-111111111111',
  '22222222-2222-4222-8222-222222222222',1,'general',NOW()+interval '5 minutes');
INSERT INTO orders(id,user_id,event_id,quantity,tier_id,unit_price,total_amount,idempotency_key,payment_deadline_at)
 VALUES ('55555555-5555-4555-8555-555555555555','11111111-1111-4111-8111-111111111111',
  '22222222-2222-4222-8222-222222222222',2,'general',50,100,'66666666-6666-4666-8666-666666666666',NOW()+interval '10 minutes');
INSERT INTO payment_records(id,order_id,status,idempotency_key)
 VALUES ('77777777-7777-4777-8777-777777777777','55555555-5555-4555-8555-555555555555','pending',
  '66666666-6666-4666-8666-666666666666');
SQL
BEFORE=$(counts); echo "before: $BEFORE"

echo "== 3. the P5 image refuses to serve the 012 database"
set +e
REFUSED=$(run_image "$P5_IMAGE" 2>&1); CODE=$?
set -e
echo "exit code: $CODE"
echo "$REFUSED" | grep -o 'admission_results is missing: apply migration 013 before serving purchases' | head -1
[ "$CODE" -ne 0 ]

echo "== 4. upgrade by the P5 image ($P5_IMAGE), then an unchanged rerun"
run_image "$P5_IMAGE" node dist/infra/migrations/runner.js up | grep -o 'All migrations complete. Total new: [0-9]*'
run_image "$P5_IMAGE" node dist/infra/migrations/runner.js up | grep -o 'All migrations complete. Total new: [0-9]*'
echo "versions: $(sql -c "SELECT string_agg(version::text, ',' ORDER BY version) FROM migrations")"
echo "admission_results after: $(sql -c "SELECT to_regclass('public.admission_results')::text||' rows='||(SELECT count(*) FROM admission_results)")"
AFTER=$(counts); echo "after:  $AFTER"
[ "$BEFORE" = "$AFTER" ]

echo "== 5. the P5 image serves the upgraded database: ready, an existing-reservation checkout and a new reservation"
CID=$(docker run --detach --rm --label peakpass.task=peakpass-p5-20261002 --publish 127.0.0.1::3000 \
  --env DB_HOST=host.docker.internal --env DB_PORT --env DB_USER --env DB_PASSWORD --env DB_NAME=$DB \
  --env REDIS_HOST=host.docker.internal --env REDIS_PORT --env LOG_LEVEL=error --env ENABLE_ADMISSION=false "$P5_IMAGE")
trap 'docker stop "$CID" >/dev/null 2>&1 || true' EXIT
PORT=$(docker port "$CID" 3000/tcp | sed 's/.*://')
BASE="http://127.0.0.1:$PORT" node --input-type=module <<'JS'
import jwt from 'jsonwebtoken';
const base = process.env.BASE, user = '11111111-1111-4111-8111-111111111111';
// The image runs with NODE_ENV unset, so it signs with the documented development secret.
const token = `Bearer ${jwt.sign({ sub: user }, 'dev-secret-change-in-production-32chars', { expiresIn: '5m' })}`;
let ready;
for (let i = 0; i < 60 && ready?.status !== 200; i++) {
  ready = await fetch(`${base}/ready`).catch(() => undefined);
  if (ready?.status !== 200) await new Promise((r) => setTimeout(r, 500));
}
console.log('ready:', ready?.status, JSON.stringify((await ready.json()).checks));
const post = async (path, body, headers = {}) => {
  const r = await fetch(base + path, { method: 'POST', body: JSON.stringify(body),
    headers: { 'content-type': 'application/json', authorization: token, ...headers } });
  return [r.status, await r.json()];
};
const purchase = { userId: user, tierId: 'general' };
const [converted, order] = await post('/checkouts', { ...purchase, quantity: 1,
  eventId: '22222222-2222-4222-8222-222222222222', reservationId: '44444444-4444-4444-8444-444444444444' },
  { 'idempotency-key': '88888888-8888-4888-8888-888888888888' });
console.log('existing reservation checkout:', converted, order.order?.status);
const [reserved, reservation] = await post('/reservations', { ...purchase, quantity: 1,
  eventId: '33333333-3333-4333-8333-333333333333' });
console.log('new reservation on the event without a policy row:', reserved, reservation.status);
if (ready?.status !== 200 || converted !== 201 || reserved !== 201) process.exit(1);
JS
echo "final:  $(counts)"
echo "admission_results rows: $(sql -c "SELECT count(*) FROM admission_results")"
echo "UPGRADE CHECK PASSED"
