// Mutation check: each branch is removed in turn and the named test must fail.
// Run from the worktree root with the test environment exported. The source is restored after
// every mutation and verified against the backup at the end.
import { readFileSync, writeFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';

const file = 'src/core/services/admission-consumption.ts';
const original = readFileSync(file, 'utf8');
const purchase = 'src/tests/integration/admission-purchase.test.ts';
const off = 'src/tests/integration/admission-purchase-off.test.ts';
const only = process.argv[2];
const all = [
  ['feature-off 503', "  if (!getConfig().ENABLE_ADMISSION) throw new AdmissionError('ADMISSION_UNAVAILABLE', 503, 1000);\n", '', off, 'answers 503 for a protected new occupation'],
  ['recovering 503', "  if (policy.phase !== 'open') throw new AdmissionError('ADMISSION_RECOVERING', 503, 1000);\n", '', purchase, 'answers 503 while recovering'],
  ['durable epoch 410', "  if (policy.epoch !== admission.epoch) throw new AdmissionError('ADMISSION_RESET', 410);\n", '', purchase, 'fences an old epoch by the durable policy alone'],
  ['unknown subject 401', "  if (!(await client.query('SELECT 1 FROM users WHERE id = $1', [command.userId])).rowCount)\n    throw new AdmissionError('UNAUTHENTICATED', 401);\n", '', purchase, 'rejects an unknown subject and an impossible tier'],
  ['tier bound 400', "  if (!admission || command.tierId.length > 50 || command.tierId.includes('\\u0000'))", '  if (!admission)', purchase, 'rejects an unknown subject and an impossible tier'],
  ['outage outside the work is 503', '    if (error === workError && !isTransient(error)) throw error;\n', '    if (!isTransient(error)) throw error;\n', purchase, 'answers 503 when an admission purchase cannot obtain a connection'],
  ['admission judged before the order replay', '  return { policy, prior: await readResult(client, admission.admissionId) };\n', '  const gate = { policy, prior: await readResult(client, admission.admissionId) };\n  ownResult(gate, command);\n  return gate;\n', purchase, 'consumes an admission for a direct checkout'],
  ['foreign result 404',"  if (prior.userId !== command.userId || prior.eventId !== command.eventId)\n    throw new AdmissionError('ADMISSION_NOT_FOUND', 404);\n", '', purchase, 'answers 404 when an admission consumed for another event'],
  ['stale-snapshot rerun', " ||\n  (error instanceof AdmissionError && error.code === 'ADMISSION_ALREADY_CONSUMED');", ';', purchase, 'replays the same request with the same reservation'],
  ['reclaimer epoch check', '        if (!policy.protected || policy.epoch !== entry.epoch) return null;\n', '', purchase, 'leaves a claim of an epoch that PostgreSQL has already left'],
  ['reclaimer try-lock', '        if (!(await lockAdmission(client, entry.admissionId, true))) return null;\n', '', purchase, 'does not reclaim while a consumer holds the admission lock'],
  ['5xx is not a business rejection', '    if (!(error instanceof AppError) || error.statusCode >= 500) throw error;\n', '    if (!(error instanceof AppError)) throw error;\n', purchase, 'retries one transient failure inside the request'],
];
const mutations = only ? all.filter((m) => m[0] === only) : all;
const results = [];
try {
  for (const [name, find, replace, testFile, testName] of mutations) {
    if (!original.includes(find)) {
      results.push([name, 'MUTATION TARGET NOT FOUND']);
      continue;
    }
    writeFileSync(file, original.replace(find, replace));
    const run = spawnSync(
      process.execPath,
      ['node_modules/jest/bin/jest.js', '--runInBand', '--config', 'jest.integration.cjs', testFile, '-t', testName],
      { encoding: 'utf8', env: process.env },
    );
    const summary = /Tests:.*$/m.exec(run.stderr + run.stdout)?.[0] ?? 'no summary (compile error?)';
    results.push([name, run.status === 0 ? 'SURVIVED (test did not fail)' : 'killed', summary]);
    writeFileSync(file, original);
  }
} finally {
  writeFileSync(file, original);
}
for (const r of results) console.log(r.join(' | '));
console.log('restored:', readFileSync(file, 'utf8') === original);
